---
tags: [indice, conversaciones-ai, inicio]
cssclasses: [dashboard]
---

# Conversaciones AI

> [!info] Punto de entrada
> Esta página organiza la bóveda por contexto. Las conversaciones originales conservan su nombre, ID y ubicación para no romper la exportación.

## Abrir por contexto

| Área | Para qué sirve | Entrada |
|---|---|---|
| Proyectos | Trabajo activo, documentación y entregables | [[01 - Proyectos/00 - Proyectos|Ver proyectos]] |
| Personal | Salud, relaciones, aprendizaje, rutinas y creatividad | [[02 - Personal/00 - Personal|Ver temas personales]] |
| Tecnología e IA | ChatGPT, Codex, Notion y herramientas | [[03 - Tecnología e IA/00 - Índice|Ver tecnología e IA]] |
| Archivo | Conversaciones cerradas o sin uso actual | [[99 - Archivadas/00 - Índice|Ver archivo]] |

## Proyectos activos

- [[01 - Proyectos/Logística SINBA/00 - Índice|Logística SINBA]] — operación, flota, datos, automatización y documentos.
- [[01 - Proyectos/Calculadora/00 - Índice|Calculadora]] — conversación principal y documentación técnica.
- [[01 - Proyectos/JARVIS/00 - Índice|JARVIS]] — desarrollo, recuperación y documentación técnica.
- [[01 - Proyectos/Center Fitt/00 - Índice|Center Fitt]] — diseño del gimnasio, marca y comunicación.
- [[01 - Proyectos/Check List/00 - Índice|Check List]] — aplicación móvil y alertas.
- [[01 - Proyectos/Mantenimientos/00 - Índice|Mantenimientos]] — integración de APIs.

## Accesos rápidos

- [[01 - Proyectos/Calculadora/Proyecto tecnico/00 - Centro de control|Centro de control de Calculadora]]
- [[01 - Proyectos/JARVIS/Proyecto técnico/00 - Centro de control|Centro de control de JARVIS]]
- [[01 - Proyectos/Logística SINBA/00 - Índice#Datos, mapas y automatización|Mapas y automatización de SINBA]]
- [[02 - Personal/00 - Personal#Salud y familia|Salud y familia]]
- [[03 - Tecnología e IA/00 - Índice#ChatGPT y Codex|ChatGPT y Codex]]

## Estado de la bóveda

- Conversaciones exportadas: **54**
- Notas Markdown totales: **103**
- Última reorganización: **2026-09-17**

> [!tip] Cómo usar esta bóveda
> Empieza siempre aquí o en el índice del proyecto. `04 - General` y `02 - Personal/Otros` quedan como ubicaciones de importación; sus contenidos útiles ya están ordenados en los mapas temáticos.
