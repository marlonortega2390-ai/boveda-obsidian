---
tags: [indice, proyectos, conversaciones-ai]
---

# Proyectos

## Operación y trabajo

- [[Logística SINBA/00 - Índice|Logística SINBA]] — 22 conversaciones sobre operación, equipo, flota y datos.
- [[Mantenimientos/00 - Índice|Mantenimientos]] — integraciones y mantenimiento técnico.

## Productos digitales

- [[Calculadora/00 - Índice|Calculadora]] — producto, operación y registro técnico.
- [[JARVIS/00 - Índice|JARVIS]] — asistente, recuperación y evolución técnica.
- [[Check List/00 - Índice|Check List]] — experiencia móvil y alertas.

## Marca y espacios

- [[Center Fitt/00 - Índice|Center Fitt]] — gimnasio, comunicación y piezas visuales.

[[../00 - Índice de conversaciones|← Volver al inicio]]

