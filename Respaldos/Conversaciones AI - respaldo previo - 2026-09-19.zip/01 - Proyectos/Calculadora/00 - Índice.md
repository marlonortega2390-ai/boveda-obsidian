---
tags: [indice, conversaciones-ai]
---

# Calculadora

- [[Ejecuta el proyecto--01a01b34-aead-7461-ab4b-f5c0a3adc62a|Ejecuta el proyecto]]

<!-- CALCULADORA-TECH-START -->
## Proyecto tecnico

- [[Proyecto tecnico/00 - Centro de control|Abrir centro de control del cotizador]]
<!-- CALCULADORA-TECH-END -->
