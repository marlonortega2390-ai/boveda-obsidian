---
title: "Calculadora SINBA - Centro de control"
synced_at: "2026-09-17T19:00:00.282Z"
tags: [calculadora, proyecto, indice]
---

# Cotizador Operativo SINBA — Centro de control

> [!summary] Estado
> Publicado en produccion. Dos modos: **normal** (comercial, ruta dedicada,
> sin desglose de costos) y **cientifica** (consola operativa completa).
> El motor de costeo es auditable y guarda snapshots inmutables.

## Ultimas actualizaciones

- [[03 - Actualizaciones/2026-09-17 - Camiones simples por operación en calculadora normal|2026-09-17 · Camiones simples por operación en calculadora normal]]
- [[03 - Actualizaciones/2026-09-12 - capa de tráfico en vivo en el mapa|2026-09-12 · capa de tráfico en vivo en el mapa]]
- [[03 - Actualizaciones/2026-09-11 - pruebas automatizadas que protegen la lógica de Costa Verde|2026-09-11 · pruebas automatizadas que protegen la lógica de Costa Verde]]
- [[03 - Actualizaciones/2026-09-11 - la ruta segura evita autopistas en vez de forzar un corredor fijo|2026-09-11 · la ruta segura evita autopistas en vez de forzar un corredor fijo]]
- [[03 - Actualizaciones/2026-09-11 - Zona roja de Costa Verde en el mapa y mensaje claro|2026-09-11 · Zona roja de Costa Verde en el mapa y mensaje claro]]

- [[03 - Actualizaciones/00 - Indice de actualizaciones|Ver todas las actualizaciones]]

## Fundamentos

- [[01 - Fundamentos/01 - README tecnico|Como ejecutar y probar]]
- [[01 - Fundamentos/02 - Motor de costos|Motor de costos auditable]]

## Operacion

- [[02 - Operacion/01 - Capacidad logistica 2026|Capacidad logistica 2026]]
- [[02 - Operacion/02 - Seguridad de la informacion|Seguridad de la informacion]]

## Referencia

- [[04 - Referencia/01 - Inventario del repositorio|Mapa del codigo]]
- [[03 - Actualizaciones/99 - Plantilla de actualizacion|Plantilla para nuevas actualizaciones]]

## Conversaciones relacionadas

- [[../00 - Índice|Indice de conversaciones de Calculadora]]
