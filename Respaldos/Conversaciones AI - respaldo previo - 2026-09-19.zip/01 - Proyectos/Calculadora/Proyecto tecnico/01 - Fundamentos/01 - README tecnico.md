---
title: "README tecnico"
source_file: "README.md"
synced_at: "2026-09-17T19:00:00.282Z"
tags: [calculadora, proyecto-tecnico, referencia]
---

# Cotizador Operativo SINBA

Primera migración web de la calculadora logística SINBA/Cubas.

## Incluye

- Rutas dedicadas y compartidas calculadas con Google Maps, además de carga masiva desde Excel/CSV.
- Distancia real, duración con tráfico, geocodificación, retorno a base y opción para evitar peajes.
- Mapa interactivo con zoom, desplazamiento, recorrido y paradas exactas.
- Flota y tarifas tomadas de `Calculadora de costo.xlsx`.
- Cálculo de carga, capacidad, turnos, personal, energía, mantenimiento y depreciación.
- Tarifas Sinba y Cubas, peajes, riesgo, overhead, margen y costos unitarios.
- Modo comercial, memoria de cálculo e historial local del navegador.
- Diseño adaptable para escritorio y móvil.

## Ejecutar

Requiere Node.js 22 o posterior.

```bash
npm install
npm run dev
```

En PowerShell con ejecucion de scripts restringida usa `npm.cmd run dev`.

Después abre `http://localhost:3000`.

### Arranque local estable

1. Mantén una sola terminal ejecutando el servidor y detén cualquier instancia anterior con `Ctrl+C`.
2. Ejecuta `npm.cmd run dev` y espera hasta ver `Local: http://localhost:3000`.
3. Abre una pestaña nueva o actualiza completamente la existente después de cada reinicio.
4. No reinicies el servidor mientras Google Maps está calculando una ruta.

El modo de desarrollo usa HMR de Vite. Una pestaña conectada a un proceso que ya fue detenido puede mostrar un error interno del cliente; una actualización completa la conecta a la instancia vigente.

## Configurar Google Maps

1. Habilita **Routes API** y **Maps JavaScript API** en Google Cloud.
2. Crea una clave privada restringida a Routes API y guárdala como `GOOGLE_MAPS_API_KEY`.
3. Crea otra clave restringida a sitios web y Maps JavaScript API y guárdala como `GOOGLE_MAPS_BROWSER_KEY`.
4. Para desarrollo, permite `http://localhost:3000/*` en la clave del navegador.
5. Reinicia la aplicación.

## Motor auditable

Las rutas aprobadas, configuraciones y cotizaciones se guardan como snapshots inmutables en D1. El detalle de formulas, hashes, Google Sheets y pruebas esta en [`docs/MOTOR_COSTOS.md`](docs/MOTOR_COSTOS.md).
