---
title: "Motor de costos"
source_file: "docs/MOTOR_COSTOS.md"
synced_at: "2026-09-17T19:00:00.282Z"
tags: [calculadora, proyecto-tecnico, motor-costos]
---

# Motor de costos Vinext

## Flujo del producto

1. `POST /api/route` consulta Google Routes con trafico y devuelve una ruta candidata.
2. La persona revisa el mapa y aprueba la ruta. La API congela orden, metros, segundos, trafico, peajes y geometria en `route_snapshots`.
3. `POST /api/quotes` recibe el identificador y hash de la ruta aprobada mas las entradas operativas.
4. El servidor carga una version publicada de configuracion, ejecuta `lib/costing/engine.ts` y guarda entradas, ruta, configuracion, resultado y comparacion.
5. Repetir la misma solicitud devuelve la cotizacion existente mediante su clave de idempotencia.

Generar una cotizacion no vuelve a consultar Google Maps. Los historicos auditados se abren desde su propio snapshot; los anteriores se conservan con estado `legacy`.

## Reglas principales

- Personal hasta 4 horas: `costo dia / 8 * horas pagadas`.
- Personal sobre 4 horas: costo dia completo.
- Turno diurno de lunes a viernes: 06:20-15:40, con 500 minutos pagados y una hora de refrigerio.
- Turno diurno del sabado: 06:20-13:40, con 380 minutos pagados y una hora de refrigerio.
- Turno nocturno: 21:00-06:00, con 480 minutos pagados y una hora de refrigerio.
- La salida de ruta puede usar el turno correspondiente o una hora personalizada.
- Extras: minutos de la operacion fuera del turno base; 25% las primeras 2 horas y 35% las siguientes.
- Si una ruta personalizada empieza a las 15:40 o despues, todos sus minutos pagados son horas extra.
- Jornada pagada: 500 minutos de lunes a viernes y 380 minutos el sabado.
- Domingo y feriado: resolucion automatica por fecha.
- Movilidad: S/ 30 si la descarga termina despues de 16:30; S/ 100 desde 21:00.
- Gestion: dos roles internos durante todos los minutos operativos, usando costo mensual / 208 horas. El cotizador publico los agrupa como `Gestion operativa`.
- Las incidencias posteriores a la salida de una ruta no se solicitan durante la cotizacion inicial.
- Gestion y desgaste: obligatorios para Sinba y Cubas.
- Cada componente se redondea y almacena en centimos antes de sumar.
- Capacidad util aproximada: BUY-730, CKL-934 y ALX-782 = 500 kg; Dongfeng = 1,300 kg; Cubas = 1,600 kg.
- Electricos BUY-730 y CKL-934: alerta preventiva desde 75 km y bloqueo sobre 80 km para conservar aproximadamente 20% de bateria al retornar.
- Tiempo operativo: conduccion con trafico y retorno + maniobras + descarga en planta + 30 minutos de tanqueo para combustion + tiempos muertos.

## Energia por unidad

Fuente: `Dashboard_Consumo_por_Unidad_SINBA_2025.xlsx`.

- CDD-935: S/ 0.625069 por km. El archivo advierte que los kilometros disponibles son parciales de abril a septiembre.
- CDD-700: S/ 0.502337 por km, con cobertura completa segun los registros disponibles.
- ALX-782: S/ 0.558061 por km para GLP y gasolina. El archivo excluye cuatro registros diesel pendientes de validacion.
- BUY-730: S/ 40.54 por dia de uso, derivado de S/ 283.81 semanales / 7.
- CKL-934: usa provisionalmente la referencia diaria de BUY-730 porque no hay una hoja propia en el archivo entregado.

## Contrato Cubas

Fuente: `CONTRATO LOGISTICA sinba - CUBAS SAC (act v.29.8.2025) (1).docx`.

- Kilometraje: S/ 2.15 normal y S/ 2.85 domingo o feriado.
- Contenedores: 360 L S/ 10/11; 240 L S/ 7/8; 180 L S/ 6/7; 120 L S/ 5/6; balde 20 L S/ 3/3.50.
- Cilindro de aceite: S/ 5 por unidad.
- Reciclaje: S/ 0.20 por kg y S/ 6 por descarga CIRC.
- Compost: S/ 0.03 por kg, con minimo de 1,000 kg.
- Los importes contractuales reciben IGV de 18%.
- El ajuste mensual por indice de petroleo queda pendiente de parametrizacion: el contrato no aclara si `Indice del mes - 91` se usa como puntos o como variacion porcentual.

## Google Sheets

La cuenta de servicio requiere acceso de lectura al documento. Variables de entorno:

```text
GOOGLE_SHEETS_ID
GOOGLE_SERVICE_ACCOUNT_EMAIL
GOOGLE_SERVICE_ACCOUNT_PRIVATE_KEY
```

La hoja `Configuracion` debe tener `clave` y `valor` en columnas A:B. Las claves son las propiedades numericas de `DEFAULT_COST_CONFIG` en `lib/costing/config.ts`. Los importes y porcentajes se escriben en unidades visibles, por ejemplo `66.67` y `20`; el backend los convierte a centimos y puntos base.

La hoja `Calendario_Feriados` contiene fechas `YYYY-MM-DD` o fechas recurrentes `MM-DD` en la columna A.

- `GET /api/settings/sync` valida y devuelve solo el hash, sin exponer ni publicar los parametros internos.
- `POST /api/settings/sync` vuelve a validar y publica una version inmutable.

Si falta una variable o el calendario esta vacio, la publicacion se bloquea e indica el campo afectado.

## Verificacion

```powershell
npm.cmd run test:unit
npx.cmd tsc --noEmit
npm.cmd run build
npm.cmd run dev
```

Se usa `npm.cmd` en PowerShell porque `npm.ps1` puede estar bloqueado por la politica de ejecucion de Windows.
