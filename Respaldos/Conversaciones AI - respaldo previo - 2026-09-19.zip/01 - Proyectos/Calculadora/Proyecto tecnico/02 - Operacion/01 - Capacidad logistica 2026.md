---
title: "Capacidad logistica 2026"
source_file: "docs/CAPACIDAD_LOGISTICA_2026.md"
synced_at: "2026-09-17T19:00:00.282Z"
tags: [calculadora, proyecto-tecnico, capacidad]
---

# Capacidad logística 2026

## Reglas vigentes en la calculadora

La capacidad se valida con dos magnitudes independientes:

- Reciclaje y PET: kilogramos declarados.
- Orgánico en contenedores: contenedores equivalentes de 180 L.

Equivalencias volumétricas usadas para orgánico:

- 360 L = 2 contenedores de 180 L.
- 240 L = 1.333 contenedores de 180 L.
- 180 L = 1 contenedor de 180 L.
- 120 L = 0.667 contenedores de 180 L.

Para estimar el peso operativo se usan 95 kg por contenedor de 180 L y 60 kg por contenedor de 120 L. El peso estimado sirve para indicadores económicos; no sustituye el control por cantidad de contenedores.

## Capacidades por unidad

| Unidad | Reciclaje/PET | Orgánico (equiv. 180 L) | Fuente |
| --- | ---: | ---: | --- |
| CDD-935 | 1,300 kg | 30 | Capacidad de camiones 2026 |
| CDD-700 | 1,300 kg | 30 | Capacidad de camiones 2026 |
| BUY-730 | 500 kg | 15 | Capacidad operativa informada |
| CKL-934 | 500 kg | 15 | Capacidad operativa informada |
| ALX-782 | 500 kg | 8 | Límite conservador provisional |
| D9L-942 | 1,300 kg | 32 | Capacidad de camiones 2026 |
| AUX-943 | 1,600 kg | 35 | Capacidad de camiones 2026 |
| D4X-827 | 1,600 kg | 35 | Capacidad de camiones 2026 |
| C3H-785 | 1,300 kg | 30 | Capacidad de camiones 2026 |

## Trazabilidad de fichas técnicas

- Contenedor 180 L: peso del recipiente aproximado de 12 kg y carga nominal máxima de 90 kg.
- Contenedor 120 L: peso del recipiente aproximado de 8 kg y carga nominal máxima de 60 kg.
- La referencia operativa comunicada para los contenedores de 180 L fluctúa entre 80 y 110 kg. La calculadora usa 95 kg como promedio para estimación y conserva la capacidad por contenedores como restricción principal.

## Catálogo de rutas

La hoja `RUTA COMPLETA` fue extraída a `data/route-clients-2026.json` como referencia no integrada. Contiene 833 registros de programación y 232 nombres normalizados preliminarmente. No se utilizará para geocodificación o sugerencias de cercanía hasta validar direcciones y unificar alias de clientes.
