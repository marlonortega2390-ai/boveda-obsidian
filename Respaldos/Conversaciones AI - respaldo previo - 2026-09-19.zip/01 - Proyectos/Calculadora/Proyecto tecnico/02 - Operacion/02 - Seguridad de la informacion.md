---
title: "Seguridad de la informacion"
source_file: "docs/SEGURIDAD_INFORMACION.md"
synced_at: "2026-09-17T19:00:00.282Z"
tags: [calculadora, proyecto-tecnico, seguridad]
---

# Política práctica de seguridad de la calculadora SINBA

Fecha de revisión: 2026-09-08

## 1. Clasificación de la información

### Pública

- Nombre y colores de SINBA.
- Explicación general de la calculadora.
- Campos vacíos y ejemplos ficticios.

### Interna

- Clientes, rutas, horarios, placas y direcciones operativas.
- Costos de personal, mantenimiento, energía y proveedores.
- Overhead, margen, ganancia, historial y cotizaciones.
- Documentos de actualización y pruebas con datos reales.

Esta información solo debe estar disponible para usuarios autorizados de SINBA.

### Secreta

- Claves de Google Maps y Gemini.
- URL y token de Turso.
- Tokens de Vercel, códigos temporales de autorización y credenciales.

Nunca debe copiarse en Markdown, capturas, conversaciones públicas, repositorios ni código fuente.

## 2. Controles obligatorios

1. Mantener secretos exclusivamente en variables de entorno.
2. Marcar como sensibles en Vercel los tokens y claves del servidor.
3. Restringir la clave web de Google Maps por dominios autorizados y únicamente a las API necesarias.
4. Usar una clave diferente para el navegador y otra para las llamadas realizadas desde el servidor.
5. Incorporar inicio de sesión y roles antes de compartir la calculadora fuera del equipo.
6. Limitar el historial y los resultados económicos a usuarios autorizados.
7. Mantener `.env*` y `.vercel/` fuera de Git.
8. Rotar inmediatamente cualquier clave que aparezca en una captura, registro compartido o repositorio.
9. Revisar cada Markdown antes de publicarlo: no debe contener datos personales, IP, enlaces de autorización ni valores de variables.
10. Mantener copias de respaldo de la base de datos y registrar quién cambia configuraciones económicas.

## 3. Regla para los Markdown de actualización

- Describir el cambio y la regla de negocio, no copiar bases de datos ni credenciales.
- Usar ejemplos ficticios o importes aprobados para documentación interna.
- Reemplazar cualquier valor sensible por `[REDACTADO]`.
- Indicar si el documento es público, interno o confidencial.

## 4. Prioridad recomendada

Antes de entregar el enlace a personas externas, implementar autenticación. La URL de producción no debe considerarse una barrera de seguridad por sí sola.

Después, configurar roles mínimos:

- Operaciones: crear rutas y ver costos operativos.
- Comercial: ver precio, overhead y margen.
- Administrador: modificar parámetros, usuarios y configuraciones.

## 5. Respuesta ante una posible filtración

1. Desactivar o rotar la credencial afectada.
2. Actualizar la variable sensible en Vercel y el proveedor correspondiente.
3. Publicar nuevamente la aplicación.
4. Revisar registros de uso y accesos.
5. Documentar el incidente sin volver a copiar la credencial.

Clasificación: documento interno.
