---
title: "Indice de actualizaciones"
source_file: "docs/actualizaciones"
synced_at: "2026-09-17T19:00:00.282Z"
tags: [calculadora, proyecto-tecnico, indice]
---


# Actualizaciones del cotizador

Registradas: **19**


## 2026-09-17

- [[2026-09-17 - Camiones simples por operación en calculadora normal|Camiones simples por operación en calculadora normal]] — _Publicada_

## 2026-09-12

- [[2026-09-12 - capa de tráfico en vivo en el mapa|capa de tráfico en vivo en el mapa]] — _Publicada en producción; verificada por build y pruebas, pendiente confirmación visual_

## 2026-09-11

- [[2026-09-11 - pruebas automatizadas que protegen la lógica de Costa Verde|pruebas automatizadas que protegen la lógica de Costa Verde]] — _Publicada (solo pruebas/herramientas de desarrollo, no cambia producción)_
- [[2026-09-11 - la ruta segura evita autopistas en vez de forzar un corredor fijo|la ruta segura evita autopistas en vez de forzar un corredor fijo]] — _Publicada en producción; verificada contra el API real de Google, pendiente confirmación visual_
- [[2026-09-11 - Zona roja de Costa Verde en el mapa y mensaje claro|Zona roja de Costa Verde en el mapa y mensaje claro]] — _Publicada en producción; verificada la lógica, pendiente confirmación visual_
- [[2026-09-11 - Revierte la deduplicación del corredor de Costa Verde|Revierte la deduplicación del corredor de Costa Verde]] — _Publicada en producción y verificada contra el API de Google_
- [[2026-09-11 - Corrige el zigzag en el desvío por Costa Verde|Corrige el zigzag en el desvío por Costa Verde]] — _Publicada en producción y verificada contra el API de Google_

## 2026-09-10

- [[2026-09-10 - Exportación de la documentación a Obsidian|Exportación de la documentación a Obsidian]] — _Ejecutada y verificada_
- [[2026-09-10 - Mapa más grande y mayor presencia de morado y lila|Mapa más grande y mayor presencia de morado y lila]] — _Publicada en producción; pendiente de revisión visual de Marlon_
- [[2026-09-10 - Paleta oficial SINBA y ancho del modo Normal|Paleta oficial SINBA y ancho del modo Normal]] — _Publicada en producción; pendiente de revisión visual de Marlon_
- [[2026-09-10 - Rediseño minimalista completo del modo Normal|Rediseño minimalista completo del modo Normal]] — _Publicada en producción; pendiente de revisión visual de Marlon_
- [[2026-09-10 - Marca y textos del mockup en el modo Normal|Marca y textos del mockup en el modo Normal]] — _Publicada en producción y verificada_
- [[2026-09-10 - Clientes cercanos y tarjetas faltantes del mockup|Clientes cercanos y tarjetas faltantes del mockup]] — _Publicada en producción y verificada_
- [[2026-09-10 - Rediseño completo del modo Normal (layout + tarjeta hero)|Rediseño completo del modo Normal (layout + tarjeta hero)]] — _Publicada en producción y verificada_
- [[2026-09-10 - Tipografía y precio final destacado en el modo Normal|Tipografía y precio final destacado en el modo Normal]] — _Publicada en producción y verificada_
- [[2026-09-10 - Estado de cotización en vivo en el modo Normal|Estado de cotización en vivo en el modo Normal]] — _Publicada en producción y verificada_
- [[2026-09-10 - Modos normal y científico|Modos normal y científico]] — _Publicada en producción y verificada_

## 2026-09-08

- [[2026-09-08 - Punto de recuperación y verificación funcional v4-estable|Punto de recuperación y verificación funcional v4-estable]] — _Publicada en producción y verificada_
- [[2026-09-08 - Frecuencia, modalidades y resultado económico|Frecuencia, modalidades y resultado económico]] — _Validada localmente; publicación pendiente de autorización de Vercel_
