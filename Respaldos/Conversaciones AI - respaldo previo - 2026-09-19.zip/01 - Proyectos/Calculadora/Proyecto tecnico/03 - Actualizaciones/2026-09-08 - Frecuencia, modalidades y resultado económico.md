---
title: "Frecuencia, modalidades y resultado económico"
source_file: "docs/actualizaciones/2026-09-08-frecuencia-modalidades-y-resultado-economico.md"
synced_at: "2026-09-17T19:00:00.282Z"
tags: [calculadora, proyecto-tecnico, actualizacion, fecha-2026-09-08]
---

# Actualización: Frecuencia, modalidades y resultado económico

Fecha: 2026-09-08  
Estado: Validada localmente; publicación pendiente de autorización de Vercel

## Objetivo

Simplificar la selección del servicio, corregir la exigencia de fecha según la frecuencia y hacer transparente la composición del precio sugerido.

## Reglas de negocio

- Una ruta recurrente puede cotizarse sin fecha específica.
- La frecuencia de tres veces por semana se identifica como interdiaria.
- Un evento único o recojo eventual exige fecha para considerar jornada, tráfico, domingos y feriados.
- Si una ruta recurrente no tiene fecha, se usa la fecha del día únicamente como referencia técnica para el cálculo.
- El precio final se presenta como: costo operativo neto + overhead + ganancia estimada.
- Ejemplo revisado: S/ 423.44 + S/ 84.91 + S/ 76.00 = S/ 584.35.

## Cambios realizados

- Se reemplazó el selector único por cuatro bloques visibles: ruta compartida, bolsas o paquetes de instalación, ruta dedicada y ruteo masivo.
- La fecha se movió junto a la frecuencia y cambia entre opcional u obligatoria según el tipo de recurrencia.
- Se añadió la etiqueta “interdiaria” a la frecuencia de tres veces por semana.
- El resumen económico ahora muestra el overhead en una tarjeta propia.
- La memoria de cálculo muestra la ecuación completa del precio final.
- Se actualizaron las pruebas relacionadas con frecuencia, modalidades y presentación económica.

## Validación

- 80 pruebas automatizadas aprobadas.
- Compilación de producción de Next.js aprobada, incluido TypeScript.
- Revisión visual local aprobada para las cuatro modalidades.
- Se comprobó el cambio dinámico entre “Fecha del recojo eventual (obligatoria)” y “Fecha del primer recojo (opcional)”.

## Publicación

- Proyecto de destino: calculadora logística SINBA en Vercel.
- La sesión local de Vercel venció y debe autorizarse nuevamente antes del despliegue.
- Este documento no contiene códigos de autorización, claves, tokens ni direcciones privadas.

## Pendientes

- Completar la autorización del dispositivo en Vercel.
- Publicar en producción y verificar la URL pública.
- Revisar los avisos técnicos preexistentes del análisis estático en una mejora separada.

## Clasificación de la información

Documento interno de desarrollo. Puede compartirse con el equipo técnico de SINBA; no debe utilizarse para almacenar credenciales ni información personal.
