---
title: "Punto de recuperación y verificación funcional v4-estable"
source_file: "docs/actualizaciones/2026-09-08-punto-recuperacion-y-verificacion-v4-estable.md"
synced_at: "2026-09-17T19:00:00.282Z"
tags: [calculadora, proyecto-tecnico, actualizacion, fecha-2026-09-08]
---

# Actualización: Punto de recuperación y verificación funcional v4-estable

Fecha: 2026-09-08
Estado: Publicada en producción y verificada

## Objetivo

Asegurar la versión actual antes de tocar código: dejar un punto de
recuperación en git y confirmar que las funciones críticas (rutas, costos,
frecuencia, impresión, clientes cercanos) funcionan de extremo a extremo.

## Reglas de negocio

- No se modificó ninguna regla de negocio ni el motor de costeo en esta
  actualización — es solo verificación y respaldo.

## Cambios realizados

- `.gitignore`: se agregaron `/tmp/`, `/.tmp/`, `/.pnpm-store/`, `/.agents/`,
  `.codex-dev*.log`, `vinext-restart.log` (carpetas de scratch/herramientas
  locales que no son código de la app; `tmp/` y `.tmp/` traían incluso
  `node_modules` de scripts de análisis, ~6.8 MB).
- Se creó el commit `f3e4737` con todo el trabajo que estaba sin
  commitear desde hace tiempo (motor de costeo, catálogo de clientes,
  ruteo masivo/compartido, asistente Manito, docs) — 76 archivos.
- Se creó el tag anotado `v4-estable` sobre ese commit.
- Se configuró identidad de git local al repositorio (no global):
  Marlon Ortega / marlon@sinba.pe, con su confirmación explícita.

## Validación

- `npm run build`: compilación limpia, TypeScript sin errores, 14 rutas
  generadas correctamente.
- `npx tsx --test tests/costing.test.ts`: 80/80 pruebas aprobadas.
- Verificación visual en navegador (servidor local limpio, puerto 3000):
  - Ruta dedicada calculada con Google Maps: 38.9 km, tráfico en vivo,
    peajes S/ 0.00.
  - Panel de clientes cercanos: cargó lista real desde el catálogo KML.
  - Frecuencia "3 veces/semana · interdiaria": la fecha pasó de
    obligatoria a opcional automáticamente, con referencia a la fecha
    del día.
  - Evento único (frecuencia por defecto): fecha marcada como
    obligatoria, tal como se espera.
  - Cotización generada: costo operativo S/ 284.18, overhead S/ 56.84,
    ganancia S/ 51.15, precio final S/ 392.17, proyección mensual
    S/ 5,094.29, con memoria de cálculo detallada.
  - Hoja de impresión: se confirmó que la sección `Cotización imprimible`
    se genera en el DOM tras aprobar y cotizar.

## Hallazgo durante la verificación

Al probar por primera vez, la app devolvía "No se pudo conectar con Google
Maps" en todos los intentos. La causa no fue un bug de código: había un
proceso `next dev` de una sesión anterior (aparentemente de Codex) corriendo
hace más de una hora en el puerto 3000, cuyas llamadas de red a Google Routes
fallaban. Se confirmó la API key válida probándola directamente por curl
(200 OK). Se terminó ese proceso viejo y, con un servidor recién levantado,
todo funcionó a la primera. Vale la pena revisar por qué ese proceso no se
cerró solo entre sesiones, para que no se repita.

## Publicación

- Se publicó a producción con `vercel deploy --prod` (confirmación
  explícita de Marlon). Proyecto `calculadora-logistica-sinba`, URL
  pública: `https://calculadora-logistica-sinba.vercel.app`.
- **Primer despliegue salió con estilos rotos**: el CSS compilado por
  Vercel no incluía un bloque completo de reglas (`.service-type-grid`,
  `.field-label`, `.service-date-row`, `.service-date-help`,
  `.economic-equation` y sus hijos, `.shared-segment-summary
  .incremental`, `.shared-sequence>div.start`, `.shared-timeline em
  small`) — exactamente las clases de las funciones agregadas en la
  actualización de "Frecuencia, modalidades y resultado económico" del
  mismo día. Diagnóstico: dos builds locales limpios (`rm -rf .next &&
  npm run build`) fueron deterministas y sí incluyeron esas reglas
  (mismo hash de archivo en ambos), por lo que el problema no es
  Turbopack ni el código — todo apunta a que Vercel reutilizó una
  **caché de build vieja**, de antes de esa actualización.
- Se corrigió con `vercel deploy --prod --force` (fuerza build sin
  caché). Se verificó por curl que el CSS servido ahora sí contiene
  esas reglas, y se repitió el flujo completo (ruta, vehículo,
  frecuencia interdiaria, cotización) directamente contra la URL de
  producción: mismos resultados que en local — costo operativo
  S/ 284.18, overhead S/ 56.84, ganancia S/ 51.15, precio final
  S/ 392.17, proyección mensual S/ 5,094.29 — con los estilos
  correctos.
- Este documento no contiene códigos de autorización, claves, tokens ni
  direcciones privadas.

## Pendientes

- **Importante para Codex**: si una futura publicación se ve con estilos
  rotos (grids sin aplicar, tarjetas sin bordes), sospechar primero de
  caché de build stale en Vercel y probar `vercel deploy --prod --force`
  antes de asumir un bug de código. Vale la pena reportarlo a soporte de
  Vercel o revisar la configuración de "Build Cache" del proyecto si se
  repite.
- Activar la protección de acceso (contraseña nativa de Vercel u otro
  mecanismo) — la URL de producción quedó pública sin autenticación.
- No hay remoto de git configurado (`git remote -v` vacío): el punto de
  recuperación `v4-estable` solo existe en este disco. Evaluar subirlo a
  un remoto (GitHub u otro) como respaldo real.
- Seguir con las limpiezas chicas acordadas (regex, catálogo de
  vehículos, accesibilidad) una por una, cada una con su propio MD.

## Clasificación de la información

Documento interno de desarrollo. Puede compartirse con el equipo técnico
de SINBA; no debe utilizarse para almacenar credenciales ni información
personal.
