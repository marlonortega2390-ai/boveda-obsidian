---
title: "Clientes cercanos y tarjetas faltantes del mockup"
source_file: "docs/actualizaciones/2026-09-10-clientes-cercanos-y-tarjetas-faltantes-modo-normal.md"
synced_at: "2026-09-17T19:00:00.282Z"
tags: [calculadora, proyecto-tecnico, actualizacion, fecha-2026-09-10]
---

# Actualización: Clientes cercanos y tarjetas faltantes del mockup

Fecha: 2026-09-10
Estado: Publicada en producción y verificada

## Objetivo

Marlon comparó la app en vivo contra el mockup aprobado y señaló brechas
reales: faltaba la tarjeta "Capacidad de la unidad" con barras de progreso,
el resumen de ruta no era una tarjeta flotante sobre el mapa, y además
notó que "clientes cercanos" había desaparecido del modo Normal al calcular
una ruta.

## Reglas de negocio

- **Clientes cercanos vuelve a estar disponible en el modo Normal.** Esto
  revierte una decisión de diseño del 2026-09-08 (donde se pidió
  explícitamente ocultarlo del área comercial). Marlon confirmó en esta
  conversación que debe quedar visible en ambos modos.
- El pegado de enlaces de Google Maps en origen/destino (`resolvePastedMapLink`)
  nunca se tocó en ninguna de las pasadas anteriores — se verificó que sigue
  intacto en el código; la percepción de que se había perdido no correspondía
  a un cambio real.
- No se modificó el motor de costeo.

## Cambios realizados

- `app/page.tsx`:
  - Se quitó la condición `isScientific &&` que ocultaba el panel de
    "Clientes cercanos" y la carga de datos cercanos — ahora depende solo
    de `nearbyEnabled` (el flag de configuración), igual en ambos modos.
  - Se agregó una tarjeta `normal-map-summary` flotante sobre el mapa
    (modo Normal) mostrando distancia y tiempo de ruta, igual que en el
    mockup.
  - Se agregó la tarjeta `normal-capacity-card` en el sidebar (modo Normal)
    con dos barras de progreso: reciclaje declarado vs. capacidad del
    vehículo, y contenedores orgánicos vs. capacidad — usa los mismos datos
    (`capacityUsage`, `vehicle`) que ya existían en el resto de la app.
- `app/globals.css`:
  - Border-radius de las tarjetas del modo Normal subido de 12px a 16px
    para calzar con los valores exactos del mockup aprobado.
  - Nuevos estilos para `.normal-map-summary` y `.normal-capacity-card`
    con sus barras de progreso.

## Validación

- 81/81 pruebas automatizadas aprobadas.
- `npm run build`: compilación de producción y TypeScript aprobados.
- ESLint: mismos 38 problemas preexistentes, cero regresiones nuevas.
- Revisión visual completa en local y en producción:
  - Modo Normal: "Clientes cercanos" aparece con la lista real y el botón
    "Evaluar desvío" tras calcular una ruta; el mapa muestra la tarjeta
    "RESUMEN DE RUTA" flotante (38.9 km · 1.3 h con tráfico); el sidebar
    muestra "CAPACIDAD DE LA UNIDAD" con las dos barras de progreso.
  - Modo Científico: verificado sin cambios — mismo layout, mismos
    resultados.

## Publicación

- Publicado a producción con `vercel deploy --prod --force`.
- URL pública: `https://calculadora-logistica-sinba.vercel.app`.
- Verificado por curl que el CSS de producción incluye las clases nuevas
  (`normal-capacity-card`, `normal-map-summary`).

## Pendientes

- Confirmar con Marlon si el diseño ya refleja fielmente lo aprobado o si
  quedan más brechas puntuales por comparar contra el mockup.
- Seguir con las limpiezas chicas pendientes (regex, catálogo de
  vehículos, accesibilidad).

## Clasificación de la información

Documento interno de desarrollo. Puede compartirse con el equipo técnico
de SINBA; no debe utilizarse para almacenar credenciales ni información
personal.
