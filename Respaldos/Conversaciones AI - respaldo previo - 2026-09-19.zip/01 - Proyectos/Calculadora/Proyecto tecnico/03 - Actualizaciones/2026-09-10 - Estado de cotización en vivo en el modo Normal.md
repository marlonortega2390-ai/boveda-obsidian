---
title: "Estado de cotización en vivo en el modo Normal"
source_file: "docs/actualizaciones/2026-09-10-rediseno-estado-en-vivo-modo-normal.md"
synced_at: "2026-09-17T19:00:00.282Z"
tags: [calculadora, proyecto-tecnico, actualizacion, fecha-2026-09-10]
---

# Actualización: Estado de cotización en vivo en el modo Normal

Fecha: 2026-09-10
Estado: Publicada en producción y verificada

## Objetivo

El área comercial reportó que la calculadora se veía desordenada. Se diseñó
una propuesta visual (aprobada por Marlon) para el modo Normal, y de esa
propuesta se implementó el primer cambio concreto: que el estado de la
cotización (pendiente / calculada / lista, con el precio final) sea visible
desde el primer momento, sin necesidad de bajar hasta el final de la
pantalla.

## Reglas de negocio

- No se modificó ninguna regla de negocio, cálculo ni el motor de costeo.
- El cambio es puramente de presentación en el modo Normal; el modo
  Científico no se tocó.

## Cambios realizados

- `app/page.tsx`: se movió el bloque `simple-result-panel` (el que muestra
  "Completa la ruta" / "Ruta calculada" / "Cotización comercial lista") de
  su posición original (debajo del mapa y las 5 tarjetas de resultado) al
  **inicio del panel derecho, antes del mapa** — visible sin scroll en
  cualquier punto del flujo.
- Se agregó el precio final (`S/ {result.price}`) directamente en esa
  tarjeta cuando la cotización ya está lista, en vez de solo el texto de
  estado.
- `app/globals.css`: se rediseñó `.simple-result-panel` para que se vea como
  tarjeta de estado (borde morado y sombra cuando `result` existe, precio en
  tipografía grande Bebas Neue) en vez de una línea de texto plana.
- El diseño se validó primero como mockup (Claude Design) con datos reales
  de una cotización ya generada, antes de tocar código.

## Validación

- 81/81 pruebas automatizadas aprobadas (sin cambios en el archivo de
  tests — este cambio no toca lógica de negocio).
- `npm run build`: compilación de producción y TypeScript aprobados.
- ESLint: mismos 38 problemas preexistentes (34 errores de accesibilidad +
  4 warnings), cero regresiones nuevas.
- Revisión visual local en ambos modos:
  - Modo Normal: la tarjeta de estado aparece arriba del mapa desde el
    inicio ("Completa la ruta para cotizar" sin datos, "Ruta calculada" tras
    calcular, "Cotización comercial lista" + precio tras generar la
    cotización). El precio coincide exactamente con la tarjeta "Precio
    final sugerido" de más abajo.
  - Modo Científico: sin cambios visuales — mapa primero, tarjeta de
    VIABILIDAD, memoria de cálculo completa. Se confirmó que el nuevo
    bloque no aparece ahí.

## Publicación

- Publicado a producción con `vercel deploy --prod --force`.
- URL pública: `https://calculadora-logistica-sinba.vercel.app`.

## Pendientes

- El resto de la propuesta visual (tipografía más grande en todo el modo
  Normal, menos tarjetas con borde morado repetidas, jerarquía del precio
  final) quedó solo en el mockup — se implementará en pasadas siguientes,
  una mejora a la vez, siguiendo el mismo criterio de "estabilidad primero"
  acordado con Codex.
- Seguir con las limpiezas chicas pendientes (regex, catálogo de vehículos,
  accesibilidad).

## Clasificación de la información

Documento interno de desarrollo. Puede compartirse con el equipo técnico
de SINBA; no debe utilizarse para almacenar credenciales ni información
personal.
