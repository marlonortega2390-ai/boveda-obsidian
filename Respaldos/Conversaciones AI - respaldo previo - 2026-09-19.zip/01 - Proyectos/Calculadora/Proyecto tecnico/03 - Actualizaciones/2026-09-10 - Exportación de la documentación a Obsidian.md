---
title: "Exportación de la documentación a Obsidian"
source_file: "docs/actualizaciones/2026-09-10-exportacion-a-obsidian.md"
synced_at: "2026-09-17T19:00:00.282Z"
tags: [calculadora, proyecto-tecnico, actualizacion, fecha-2026-09-10]
---

# Actualización: Exportación de la documentación a Obsidian

Fecha: 2026-09-10
Estado: Ejecutada y verificada

## Objetivo

Marlon pidió organizar la documentación del cotizador dentro de su bóveda
de Obsidian, en el proyecto correspondiente, y mantener el hábito de
guardar un Markdown por cada avance.

## Reglas de negocio

- No se modificó código de la aplicación ni reglas de negocio.
- La bóveda recibe copias de la documentación; el repositorio sigue siendo
  la fuente de verdad.

## Cómo funciona

Obsidian trabaja sobre carpetas de Markdown, así que la integración es
escribir en la bóveda. Se creó `scripts/export-docs-to-obsidian.mjs`
(Node, porque Python no está disponible en este entorno) siguiendo la
misma convención que ya usaba el proyecto JARVIS.

```bash
node scripts/export-docs-to-obsidian.mjs "C:/Users/marlo/OneDrive/Desktop/Marlon Ortega"
```

Es idempotente: se puede correr después de cada cambio y sobrescribe la
documentación sin duplicar nada ni tocar las conversaciones ya guardadas.

## Estructura creada

Dentro de `Conversaciones AI/01 - Proyectos/Calculadora/Proyecto tecnico/`:

- `00 - Centro de control.md` — panel con estado, últimas 5 actualizaciones
  y accesos a todo lo demás.
- `01 - Fundamentos/` — README técnico y motor de costos.
- `02 - Operacion/` — capacidad logística 2026 y seguridad de la información.
- `03 - Actualizaciones/` — las 11 actualizaciones, una por nota, con un
  índice propio agrupado por fecha, más la plantilla para nuevas entradas.
- `04 - Referencia/` — inventario del repositorio (mapa del código, generado
  automáticamente ignorando `node_modules`, `.next`, `dist` y similares).

Cada nota lleva frontmatter con `title`, `source_file`, `synced_at` y tags
(`calculadora`, `proyecto-tecnico` y la categoría), para que sean
filtrables desde Obsidian.

El índice del proyecto (`00 - Índice.md`) recibió un bloque gestionado
entre marcadores `CALCULADORA-TECH-START/END` que enlaza al centro de
control, preservando las conversaciones que ya estaban listadas.

## Errores detectados y corregidos durante la exportación

- **Enlace roto**: el centro de control apuntaba a `00 - Indice` cuando el
  archivo real se llama `00 - Índice.md` (con tilde). Corregido.
- **Orden incorrecto**: las "últimas actualizaciones" se ordenaban
  alfabéticamente, así que dentro del mismo día no reflejaban el orden real
  de trabajo. Ahora ordena por fecha del nombre y, dentro del mismo día,
  por fecha de modificación del archivo.

## Validación

- 16 documentos exportados (5 fijos + 11 actualizaciones), más índice,
  centro de control e inventario.
- Se verificaron los **26 enlaces internos** de la carpeta con un chequeo
  automático: 0 rotos.
- Se comprobó que las conversaciones previas del proyecto en Obsidian
  siguen intactas en el índice.

## Pendientes

- Correr el script después de cada actualización futura para mantener la
  bóveda sincronizada (o incorporarlo al cierre de cada cambio).
- Evaluar unificar este script con el de JARVIS
  (`tools/export_project_to_obsidian.py`), hoy son dos implementaciones
  paralelas en lenguajes distintos.

## Clasificación de la información

Documento interno de desarrollo. Puede compartirse con el equipo técnico
de SINBA; no debe utilizarse para almacenar credenciales ni información
personal.
