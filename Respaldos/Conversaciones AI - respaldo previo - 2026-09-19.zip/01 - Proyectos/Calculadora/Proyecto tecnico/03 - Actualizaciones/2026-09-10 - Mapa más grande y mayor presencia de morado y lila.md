---
title: "Mapa más grande y mayor presencia de morado y lila"
source_file: "docs/actualizaciones/2026-09-10-mapa-mas-grande-y-mas-morado-lila.md"
synced_at: "2026-09-17T19:00:00.282Z"
tags: [calculadora, proyecto-tecnico, actualizacion, fecha-2026-09-10]
---

# Actualización: Mapa más grande y mayor presencia de morado y lila

Fecha: 2026-09-10
Estado: Publicada en producción; pendiente de revisión visual de Marlon

## Objetivo

Tras aplicar la paleta oficial, Marlon pidió dos ajustes concretos sobre la
calculadora normal: agrandar el mapa y subir la presencia de morado y lila,
que habían quedado demasiado discretos en el rediseño minimalista.

## Reglas de negocio

- Ninguna regla de negocio, cálculo ni flujo fue modificado.
- Cambio exclusivamente visual (CSS). No se tocó `page.tsx`.
- Todo sigue acotado a `.calculator-normal`: el modo Científico no cambia.

## Cambios realizados

**Mapa**
- Altura de 240px a 400px, con borde en tono lila en vez de gris neutro.
- La etiqueta "Resumen de ruta" que flota sobre el mapa pasa a morado.

**Más morado y lila en el formulario**
- Encabezados de sección (`¿Dónde recogemos?`, `¿Quién y con qué
  frecuencia?`) ahora en morado, con una línea divisoria lila debajo y el
  número de paso un poco más grande.
- "Servicio activo · Ruta dedicada" vuelve a ser una tarjeta con fondo lila
  y barra morada a la izquierda (antes era solo texto sobre blanco).
- Tarjeta de capacidad del vehículo: fondo lila con texto en morado oscuro.
- Bloques de "Personal de la unidad" y "Viajes operativos": fondo lila muy
  suave con borde lila y cifras destacadas en morado.
- "Perfil de carga" y el simulador comercial: títulos en morado, líneas
  divisorias en lila.
- Botón "Añadir parada": de gris punteado a fondo lila con texto morado.
- Campos de formulario: fondo levemente lila, etiquetas en tono violáceo y
  foco con halo morado más visible; los campos deshabilitados usan lila.
- Clientes cercanos: tarjeta con barra morada a la izquierda y fondo lila
  muy suave.

**Barra lateral**
- La tarjeta de estado, al quedar lista la cotización, pasa a fondo lila
  con el precio en morado y más grande (28px).
- Título de "Capacidad de la unidad" en morado; barras de progreso sobre
  pista lila.

## Validación

- 81/81 pruebas automatizadas aprobadas.
- `npm run build`: compilación de producción y TypeScript aprobados.
- ESLint: mismos 38 problemas preexistentes, cero regresiones nuevas.
- Verificado sobre el CSS compilado en producción: el mapa a 400px y 12
  usos de lila y 17 de morado sobrevivieron a la minificación.
- **Sin revisión visual en navegador**: la herramienta de navegador siguió
  caída toda la sesión; la validación fue estructural sobre el CSS servido.

## Publicación

- Publicado a producción con `vercel deploy --prod --force`.
- URL pública: `https://calculadora-logistica-sinba.vercel.app`.

## Pendientes

- Revisión visual de Marlon: confirmar si el nivel de color ya es el
  buscado o conviene subirlo/bajarlo.
- El amarillo `#F5DB22` de la paleta sigue sin uso asignado.
- Seguir con las limpiezas chicas pendientes (regex, catálogo de
  vehículos, accesibilidad).

## Clasificación de la información

Documento interno de desarrollo. Puede compartirse con el equipo técnico
de SINBA; no debe utilizarse para almacenar credenciales ni información
personal.
