---
title: "Marca y textos del mockup en el modo Normal"
source_file: "docs/actualizaciones/2026-09-10-marca-y-copy-del-mockup-modo-normal.md"
synced_at: "2026-09-17T19:00:00.282Z"
tags: [calculadora, proyecto-tecnico, actualizacion, fecha-2026-09-10]
---

# Actualización: Marca y textos del mockup en el modo Normal

Fecha: 2026-09-10
Estado: Publicada en producción y verificada

## Objetivo

Marlon comparó una captura real de producción contra el mockup y señaló
algo concreto que las pasadas anteriores no habían tocado: el encabezado y
los títulos de sección seguían usando el texto y el logo original de la
calculadora científica, nunca se habían actualizado al copy y a la marca
"SINBA" simplificada del mockup aprobado. Todas las pasadas previas solo
habían cambiado estructura y CSS, no el contenido textual del header ni de
los encabezados de paso.

## Reglas de negocio

- No se modificó ninguna regla de negocio ni el motor de costeo.
- Cambio de contenido (copy) y marca, scoped a `!isScientific` para no
  afectar el modo Científico.

## Cambios realizados

- `app/page.tsx`:
  - El encabezado ahora muestra, en modo Normal: logo cuadrado morado con
    la letra "S" (`brand-mark`), título "SINBA" y subtítulo "Cotizador
    operativo" — en vez del título técnico "Calculadora Logística SINBA
    V4.0 · Plataforma de Cotización y TME Integral" (que se mantiene sin
    cambios en modo Científico).
  - El paso 1 pasa de "01 · Diseña la ruta" a "1 · ¿Dónde recogemos?" en
    modo Normal.
  - El paso 2 pasa de "02 · Define la operación" a "2 · ¿Quién y con qué
    frecuencia?" en modo Normal.
- `app/globals.css`: ajustes de tipografía y espaciado para que el logo,
  el título y el subtítulo del header se vean con el tamaño y color del
  mockup en modo Normal.

## Validación

- 81/81 pruebas automatizadas aprobadas (los tests que verifican texto
  literal en `page.tsx`, como "Diseña la ruta", siguen pasando porque ese
  texto sigue existiendo en el código, ahora dentro de la rama
  condicional de Científico).
- `npm run build`: compilación de producción y TypeScript aprobados.
- ESLint: mismos 38 problemas preexistentes, cero regresiones nuevas.
- Verificado por HTML crudo (`curl`) tanto en local como en producción que
  el marcado servido contiene `<h1>SINBA</h1>`, "Cotizador operativo" y
  "¿Dónde recogemos?" en la carga inicial del modo Normal.
- Se confirmó además, con una llamada directa a `/api/maps-link`, que el
  pegado de enlaces de Google Maps en origen/destino sigue funcionando de
  punta a punta (nunca se había tocado ese código en ninguna pasada
  anterior; la percepción de que se había perdido no correspondía a un
  cambio real).

## Publicación

- Publicado a producción con `vercel deploy --prod --force`.
- URL pública: `https://calculadora-logistica-sinba.vercel.app`.
- Verificado directamente en producción vía `curl` sobre el HTML servido.

## Pendientes

- Confirmar con Marlon, ahora con la marca y el copy también alineados,
  si el diseño ya refleja fielmente el mockup aprobado en su totalidad.
- Seguir con las limpiezas chicas pendientes (regex, catálogo de
  vehículos, accesibilidad).

## Clasificación de la información

Documento interno de desarrollo. Puede compartirse con el equipo técnico
de SINBA; no debe utilizarse para almacenar credenciales ni información
personal.
