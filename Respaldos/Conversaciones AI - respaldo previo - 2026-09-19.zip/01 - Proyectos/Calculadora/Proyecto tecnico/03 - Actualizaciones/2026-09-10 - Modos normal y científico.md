---
title: "Modos normal y científico"
source_file: "docs/actualizaciones/2026-09-10-modos-normal-y-cientifico.md"
synced_at: "2026-09-17T19:00:00.282Z"
tags: [calculadora, proyecto-tecnico, actualizacion, fecha-2026-09-10]
---

# Actualización: Modos normal y científico

Fecha: 2026-09-10  
Estado: Publicada en producción y verificada

Nota de continuidad: Codex diseñó e implementó la separación Normal/Científica
y se quedó sin cupo de uso antes de publicar. Claude retomó desde el commit
sin confirmar, verificó lo ya hecho, encontró una fuga de datos real (ver
"Corrección aplicada por Claude" abajo) y la cerró antes de continuar.

## Objetivo

Simplificar la cotización para el área comercial sin eliminar las funciones
operativas avanzadas de la calculadora.

## Reglas de negocio

- El modo normal utiliza únicamente ruta dedicada y el mismo motor de costos
  auditado que el modo científico.
- La frecuencia recurrente puede cotizarse sin fecha. La fecha solo se muestra
  como obligatoria para un evento único.
- El conductor se asigna automáticamente según la categoría del vehículo.
- En unidades SINBA se puede ajustar la cantidad de ayudantes.
- En unidades Cubas el personal se considera incluido en la tarifa contractual
  y no se suma nuevamente.
- La capacidad por peso, reciclaje y contenedores continúa bloqueando una
  cotización que exceda la unidad seleccionada.
- Al pasar del modo científico al normal se restablecen los ajustes técnicos
  ocultos para impedir costos invisibles.

## Cambios realizados

- Se añadió un selector entre `Calculadora normal` y `Calculadora científica`.
- El modo normal muestra ruta dedicada, responsable, frecuencia, vehículo,
  personal, viajes y perfil de carga.
- El modo normal oculta bolsas, clientes cercanos, peajes, fondo de riesgo,
  tiempos muertos, configuraciones de horario, historial y memoria detallada.
- El resultado comercial conserva costo operativo neto, overhead, ganancia,
  precio final sugerido y proyección mensual.
- El modo científico conserva las cuatro modalidades y todos los controles
  existentes.
- Se añadió una prueba de regresión para comprobar la separación de ambos modos.

## Validación

- Suite de negocio: 81 de 81 pruebas aprobadas.
- `npm run build`: compilación de producción y TypeScript aprobados.
- Revisión visual local:
  - el modo normal abre por defecto;
  - el modo científico recupera todas las opciones avanzadas;
  - una frecuencia interdiaria oculta la fecha en el modo normal;
  - una unidad eléctrica N1 selecciona automáticamente chofer A1;
  - el mapa carga sin errores de ejecución.
- ESLint mantiene 33 errores de asociación de etiquetas y una advertencia de
  dependencias de React que ya existían antes de esta actualización; no se
  añadieron errores nuevos.

## Corrección aplicada por Claude (2026-09-10)

Al verificar el trabajo de Codex se encontró que el modo Normal ocultaba la
memoria de cálculo detallada **solo con CSS** (`display:none`): el elemento
seguía existiendo en el DOM con el desglose completo (fórmulas, peajes,
costo de conductor), visible por DevTools/pestaña Red. Peor aún, el botón
"Imprimir cotización" — visible en el modo Normal — generaba un PDF con el
desglose completo sin ningún filtro, exponiendo esa información con un solo
clic, sin necesidad de conocimientos técnicos.

Causa raíz: el servidor (`/api/quotes`) devolvía la misma respuesta completa
sin importar el modo activo en pantalla; solo la interfaz escondía la vista.

Corrección (confirmada con Marlon, opción "ocultación real"):

- `lib/costing/public-result.ts`: nueva función `summaryCostResult()` que
  reduce el `CostResult` a los totales permitidos (costo operativo, overhead,
  margen, precio, proyección mensual) y vacía `lines`, `unitEconomics`,
  `perKmCents/perKgCents/perUnitCents`, `maxPurchaseCents` y el desglose de
  turno/horas extra.
- `app/api/quotes/route.ts`: el `POST` ahora recibe `view: "normal" |
  "scientific"` en el body y aplica `summaryCostResult()` en vez de
  `publicCostResult()` cuando `view === "normal"` (en la respuesta al
  cliente; el snapshot que se guarda en D1 para auditoría sigue completo).
  La comparación contra la cotización anterior tampoco se envía en modo
  Normal.
- `app/page.tsx`: `submitQuote()` manda `view: calculatorView` en cada
  petición. La hoja imprimible ya no muestra "Peajes incluidos" ni la sección
  de desglose de gastos cuando `result.lines` viene vacío (modo Normal); el
  título de la sección económica cambia a "Resultado comercial".
- Verificado por Network que la respuesta cruda del servidor en modo Normal
  trae `lines: []`, `unitEconomics: []`, `comparison: []` — no solo la
  pantalla, el dato ya no sale del servidor. Se confirmó también que el modo
  Científico sigue recibiendo las 14 líneas de detalle sin cambios.
- 81/81 pruebas, build de producción y ESLint (34 errores de accesibilidad
  preexistentes, cero nuevos) sin regresiones.

## Publicación

- Publicado a producción con `vercel deploy --prod --force` (fuerza build
  sin caché, por el problema de caché stale del 2026-09-08). Confirmación
  explícita de Marlon.
- URL pública: `https://calculadora-logistica-sinba.vercel.app`.
- Verificado directamente en producción (no solo en local): CSS completo,
  modo Normal por defecto, ruta dedicada calculada con Google Maps,
  frecuencia interdiaria sin fecha, cotización generada (S/ 386.07 precio
  final). Se confirmó por la respuesta cruda de red del `POST /api/quotes`
  en producción que `lines`, `unitEconomics` y `comparison` llegan vacíos —
  la ocultación real del desglose de costos funciona en el sitio público,
  no solo en el entorno local.

## Pendientes

- Confirmar visualmente el flujo comercial con un caso real antes de publicar.
- Definir si el modo científico será visible mediante selector o protegido por
  un rol interno cuando se incorpore autenticación.
- Corregir la accesibilidad en lotes pequeños sin mezclarla con reglas de costo.
- El historial (`GET /api/quotes`) sigue devolviendo el desglose completo de
  cotizaciones pasadas sin importar el modo activo; hoy no es explotable
  porque el botón de historial está oculto por completo en el modo Normal,
  pero si en el futuro se expone algo del historial al área comercial, esa
  respuesta necesita el mismo tratamiento de `summaryCostResult()`.

## Clasificación de la información

Documento interno. No contiene credenciales ni datos personales.
