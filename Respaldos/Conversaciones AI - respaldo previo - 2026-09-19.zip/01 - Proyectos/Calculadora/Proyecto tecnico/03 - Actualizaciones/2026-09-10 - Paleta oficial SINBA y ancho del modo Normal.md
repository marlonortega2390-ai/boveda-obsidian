---
title: "Paleta oficial SINBA y ancho del modo Normal"
source_file: "docs/actualizaciones/2026-09-10-paleta-oficial-y-ancho-modo-normal.md"
synced_at: "2026-09-17T19:00:00.282Z"
tags: [calculadora, proyecto-tecnico, actualizacion, fecha-2026-09-10]
---

# Actualización: Paleta oficial SINBA y ancho del modo Normal

Fecha: 2026-09-10
Estado: Publicada en producción; pendiente de revisión visual de Marlon

## Objetivo

Marlon aprobó el rediseño minimalista y pidió dos ajustes: aplicar la
paleta oficial de la marca (compartida en `Plantilla de Colorimetria.pptx`)
y corregir que la sección de calculadora normal se veía demasiado
centralizada, desaprovechando el ancho de pantalla.

## Paleta oficial incorporada

Extraída del PPT de colorimetría de la marca:

| Nombre   | Hex       | Uso en la interfaz                          |
|----------|-----------|---------------------------------------------|
| Morado   | `#5A1A9B` | Acento principal: logo, pasos, botones, precio |
| Lila     | `#EBE9FC` | Fondos suaves: selector de modo, tarjeta de resultado, barras |
| Verde    | `#419847` | Estados positivos: ruta calculada, aprobar ruta, capacidad orgánica |
| Rojo     | `#E05841` | Errores y alertas de capacidad excedida     |
| Naranja  | `#F2AC2C` | Avisos (tarifa especial por tipo de día)    |
| Amarillo | `#F5DB22` | Reservado, aún sin uso asignado             |

Los tres primeros ya coincidían parcialmente con los colores en uso; lila y
rojo se corrigieron a los valores exactos de marca (antes `#f0eafa` y
`#df4b43`).

## Cambios realizados

- `app/globals.css`:
  - Se declararon los seis colores de marca como variables CSS sobre
    `.calculator-normal`, y los neutros se re-derivaron con un matiz lila
    muy leve (fondo `#f7f6fb`, líneas `#e7e4f2`) para que la interfaz se
    sienta parte de la marca sin saturar.
  - **Ancho**: el contenedor pasa de `max-width:1180px` a `1560px`, con
    padding lateral de 48px y la barra lateral flexible entre 320 y 400px.
    Esa era la causa de que se viera "muy centralizada" en pantallas
    anchas.
  - Tarjeta de resultado: pasa de blanca a fondo lila con el precio en
    morado y el check en verde — es el único bloque con color de marca
    pleno, manteniendo el resto neutro.
  - Selector de modo, barras de capacidad, estados de error, avisos de tipo
    de día y botón de aprobar ruta ahora usan los colores exactos de marca.

## Validación

- 81/81 pruebas automatizadas aprobadas.
- `npm run build`: compilación de producción y TypeScript aprobados.
- ESLint: mismos 38 problemas preexistentes, cero regresiones nuevas.
- Verificado sobre el CSS compilado en producción que las variables de
  marca (`--n-purple`, `--n-lila`, `--n-green`, `--n-red`) y el nuevo
  `max-width:1560px` sobrevivieron a la minificación.
- **Sin revisión visual en navegador**: la herramienta de navegador siguió
  caída durante toda la sesión. La validación fue estructural sobre el CSS
  servido. Queda pendiente la confirmación de Marlon.

## Publicación

- Publicado a producción con `vercel deploy --prod --force`.
- URL pública: `https://calculadora-logistica-sinba.vercel.app`.

## Pendientes

- Revisión visual de Marlon: confirmar el nuevo ancho y el uso de color.
- Definir si el amarillo `#F5DB22` debe tener algún uso asignado.
- Evaluar si conviene llevar la paleta oficial también a las variables
  globales (`:root`), lo que afectaría al modo Científico — por ahora se
  mantuvo acotada a `.calculator-normal`.
- Seguir con las limpiezas chicas pendientes (regex, catálogo de
  vehículos, accesibilidad).

## Clasificación de la información

Documento interno de desarrollo. Puede compartirse con el equipo técnico
de SINBA; no debe utilizarse para almacenar credenciales ni información
personal.
