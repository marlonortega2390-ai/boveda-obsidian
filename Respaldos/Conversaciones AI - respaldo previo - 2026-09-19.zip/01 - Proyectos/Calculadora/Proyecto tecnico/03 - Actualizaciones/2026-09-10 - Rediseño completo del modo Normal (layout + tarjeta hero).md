---
title: "Rediseño completo del modo Normal (layout + tarjeta hero)"
source_file: "docs/actualizaciones/2026-09-10-rediseno-completo-modo-normal.md"
synced_at: "2026-09-17T19:00:00.282Z"
tags: [calculadora, proyecto-tecnico, actualizacion, fecha-2026-09-10]
---

# Actualización: Rediseño completo del modo Normal (layout + tarjeta hero)

Fecha: 2026-09-10
Estado: Publicada en producción y verificada

## Objetivo

Las dos pasadas anteriores (mover el estado arriba, subir tipografía) no
reflejaban de verdad el mockup aprobado — seguían usando la misma
estructura de panel fijo de 100vh que comparte con el modo Científico.
Marlon lo notó explícitamente ("sigues aferrado al mismo diseño"). Esta
actualización reconstruye la estructura real: página abierta de un solo
scroll, header combinado con el switch de modo, sidebar tranquilo con el
mapa chico, y la pieza que faltaba — la tarjeta de precio final gigante en
el flujo principal, no escondida en una tarjetita del costado.

## Reglas de negocio

- No se modificó ninguna regla de negocio ni el motor de costeo.
- Cambio estructural de layout, scoped completamente a `.calculator-normal`
  vía CSS Grid con `grid-template-areas`; el modo Científico no cambia una
  sola línea de su estructura.

## Cambios realizados

- `app/page.tsx`:
  - Nueva sección `.normal-hero` (solo modo Normal) insertada al final del
    flujo del formulario, después del simulador comercial y antes del botón
    de aprobar/cotizar: precio final en grande, 4 indicadores (costo,
    overhead, ganancia, proyección mensual) y los botones de imprimir/nueva
    cotización.
  - El `summary-strip` original (con VIABILIDAD y las 5 tarjetas chicas)
    ahora solo se renderiza en modo Científico — el modo Normal ya no lo
    usa, tiene su propia tarjeta hero.
  - La tarjeta de estado del costado (`simple-result-panel`) se simplificó:
    ya no lleva botones (viven en la tarjeta hero), solo el indicador
    rápido.
- `app/globals.css`:
  - `.calculator-normal.app-shell` pasa de un grid fijo de 100vh con
    paneles de scroll independiente a un grid con `grid-template-areas`
    (`header switch` / `main aside`) de una sola página que scrollea
    completa, centrada a 1280px máximo, con fondo `var(--ground)`.
  - El header y el switch de modo ahora comparten visualmente la misma
    fila (unidos por grid areas, sin cambiar el HTML).
  - El sidebar (`workspace-panel`) se volvió una columna angosta (360px),
    sticky, con el mapa reducido a 260px de alto en vez de ocupar toda la
    pantalla.
  - Nuevas clases `.normal-hero`, `.normal-hero-price`, `.normal-hero-stats`,
    `.normal-hero-actions`: gradiente morado, precio en Bebas Neue 60px,
    4 tarjetas translúcidas, calcado del mockup aprobado.
  - Se agregó un breakpoint (`max-width:1080px`) para que el layout de dos
    columnas pase a una sola columna en pantallas angostas.

## Validación

- 81/81 pruebas automatizadas aprobadas.
- `npm run build`: compilación de producción y TypeScript aprobados (se
  limpió `.next/` antes de construir por un archivo de tipos obsoleto de
  una sesión de desarrollo anterior, no relacionado con este cambio).
- ESLint: mismos 38 problemas preexistentes, cero regresiones nuevas.
- Revisión visual completa en local y en producción:
  - Modo Normal: header y switch combinados visualmente, tarjetas
    flotantes con sombra suave, sidebar con mapa chico y tarjeta de estado,
    y al generar la cotización aparece la tarjeta hero con el precio en
    grande (S/ 384.33) y las 4 tarjetas translúcidas — visualmente
    equivalente al mockup aprobado.
  - Modo Científico: verificado sin ningún cambio — misma estructura,
    misma densidad, mismos resultados.

## Publicación

- Publicado a producción con `vercel deploy --prod --force`.
- URL pública: `https://calculadora-logistica-sinba.vercel.app`.
- Verificado directamente en producción, no solo en local.

## Pendientes

- Revisar el comportamiento en móvil/tablet real (el breakpoint se agregó
  pero no se probó con dispositivo o viewport angosto en esta pasada).
- Evaluar si vale la pena agregar la tarjeta de "Capacidad de la unidad"
  (barras de progreso) al sidebar, como estaba en el mockup original —
  se dejó fuera de esta pasada para no ampliar más el alcance.
- Seguir con las limpiezas chicas pendientes (regex, catálogo de
  vehículos, accesibilidad).

## Clasificación de la información

Documento interno de desarrollo. Puede compartirse con el equipo técnico
de SINBA; no debe utilizarse para almacenar credenciales ni información
personal.
