---
title: "Rediseño minimalista completo del modo Normal"
source_file: "docs/actualizaciones/2026-09-10-rediseno-minimalista-modo-normal.md"
synced_at: "2026-09-17T19:00:00.282Z"
tags: [calculadora, proyecto-tecnico, actualizacion, fecha-2026-09-10]
---

# Actualización: Rediseño minimalista completo del modo Normal

Fecha: 2026-09-10
Estado: Publicada en producción; pendiente de revisión visual de Marlon

## Objetivo

Marlon pidió un rediseño total de la página: estilo minimalista, limpio a
la vista y entendible, manteniendo intactas todas las funciones actuales.
Las pasadas anteriores habían ido parchando el CSS heredado de la consola
compacta; esta reemplaza por completo el sistema visual del modo Normal
por uno propio y coherente.

## Reglas de negocio

- Ninguna regla de negocio, cálculo ni flujo fue modificado.
- Cambio exclusivamente visual (CSS). No se tocó `page.tsx` en esta pasada.
- Todo el sistema va prefijado con `.calculator-normal`: el modo Científico
  conserva su consola densa sin ningún cambio.

## Sistema visual aplicado

Se definió una paleta acotada como variables CSS sobre `.calculator-normal`:
fondo `#fafafa`, superficies blancas, líneas `#eceaef`, tinta `#1b1b1f`,
texto secundario `#78767f` y un único acento (morado SINBA `#5a1a9b`).

Principios del rediseño:

- **Sin sombras**: todas las tarjetas pasan a borde de 1px, sin elevación.
- **Sin cajas de color**: se eliminaron los bloques lila, verde, amarillo y
  el recuadro negro de estado. Ahora son texto tranquilo, líneas divisorias
  o tarjetas blancas con borde.
- **Acento con moderación**: el morado queda reservado para el logo, los
  números de paso, el botón de calcular ruta y el botón principal.
- **Botón de Google Maps**: de naranja/amarillo saturado a morado sólido.
- **Estado de ruta**: de recuadro negro a una línea de texto con un punto.
- **Tarjeta de resultado**: de gradiente morado con sombra fuerte a tarjeta
  blanca con borde; el precio (52px) es el elemento de mayor peso visual y
  los cuatro indicadores quedan separados por líneas verticales finas.
- **Tipografía**: pesos bajados (de 900 a 600/700), mayúsculas forzadas
  eliminadas, tamaños subidos (labels 12.5px, inputs 14.5px, títulos 18px).
- **Espaciado**: padding de tarjetas a 28px, separación entre secciones a
  20px, campos a 46px de alto.

## Riesgo detectado y corregido durante el trabajo

Al reemplazar el bloque CSS completo se perdieron las definiciones base de
varias clases propias (`display:flex`, `display:grid`, `position:absolute`,
`height:100%`), lo que habría roto la tarjeta de resultado, las barras de
capacidad y el resumen flotante del mapa. Se detectó antes de publicar
auditando clase por clase y se corrigió dejando esas reglas
autocontenidas, con valores de respaldo en cada `var()`.

## Validación

- 81/81 pruebas automatizadas aprobadas.
- `npm run build`: compilación de producción y TypeScript aprobados.
- ESLint: mismos 38 problemas preexistentes, cero regresiones nuevas.
- Se verificó sobre el CSS ya compilado (local y producción) que las reglas
  críticas sobrevivieron a la minificación, incluyendo
  `.normal-hero-stats{...display:grid}`, `.calculator-normal.app-shell` con
  su grid de áreas, y las variables de color.
- **No se pudo hacer revisión visual en navegador**: la herramienta de
  navegador estuvo caída durante toda la sesión (falla incluso contra
  sitios de prueba externos). La validación fue estructural sobre el CSS
  servido, no visual. Queda pendiente la confirmación de Marlon.

## Publicación

- Publicado a producción con `vercel deploy --prod --force`.
- URL pública: `https://calculadora-logistica-sinba.vercel.app`.

## Pendientes

- Revisión visual de Marlon y ajuste fino de lo que no convenza.
- Evaluar si el modo Científico debería recibir también una pasada de
  limpieza, o si conviene mantener su densidad operativa actual.
- Seguir con las limpiezas chicas pendientes (regex, catálogo de
  vehículos, accesibilidad).

## Clasificación de la información

Documento interno de desarrollo. Puede compartirse con el equipo técnico
de SINBA; no debe utilizarse para almacenar credenciales ni información
personal.
