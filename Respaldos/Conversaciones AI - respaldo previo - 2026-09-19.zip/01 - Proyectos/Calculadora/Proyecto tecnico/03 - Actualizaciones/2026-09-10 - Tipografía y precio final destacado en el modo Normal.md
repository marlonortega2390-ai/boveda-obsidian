---
title: "Tipografía y precio final destacado en el modo Normal"
source_file: "docs/actualizaciones/2026-09-10-tipografia-y-precio-final-modo-normal.md"
synced_at: "2026-09-17T19:00:00.282Z"
tags: [calculadora, proyecto-tecnico, actualizacion, fecha-2026-09-10]
---

# Actualización: Tipografía y precio final destacado en el modo Normal

Fecha: 2026-09-10
Estado: Publicada en producción y verificada

## Objetivo

Continuar la propuesta visual aprobada para el modo Normal: subir la
tipografía a un tamaño legible para el área comercial y destacar el precio
final sugerido como el número más importante en pantalla, sin tocar el modo
Científico.

## Reglas de negocio

- No se modificó ninguna regla de negocio ni el motor de costeo.
- Cambio puramente visual, con todas las reglas scoped bajo
  `.calculator-normal` para no afectar el modo Científico.

## Cambios realizados

- `app/page.tsx`: se agregó `className="price-final"` a la tarjeta de
  "Precio final sugerido" dentro del resumen, para poder destacarla con CSS
  sin tocar las otras cuatro.
- `app/globals.css`: nuevo bloque de estilos scoped a `.calculator-normal`
  que sube tamaños de fuente y padding en secciones, encabezados, labels,
  inputs, badges y botones (de 8-10px a 11-16px según el elemento), y
  destaca la tarjeta de precio final con el mismo gradiente morado usado en
  la tarjeta de estado en vivo.
- No se tocó ninguna clase compartida sin el prefijo `.calculator-normal`,
  así que el modo Científico usa exactamente el mismo CSS que antes.

## Validación

- 81/81 pruebas automatizadas aprobadas.
- `npm run build`: compilación de producción y TypeScript aprobados (se
  encontró y limpió un archivo de tipos obsoleto en `.next/dev/` que
  rompía el build; no relacionado con este cambio, se resolvió con
  `rm -rf .next` antes de reconstruir).
- ESLint: mismos 38 problemas preexistentes, cero regresiones nuevas.
- Revisión visual en local y en producción, ambos modos:
  - Normal: textos y controles notablemente más grandes y legibles: la
    tarjeta "Precio final sugerido" resalta en morado sobre las otras
    cuatro (blancas). El precio coincide entre la tarjeta de estado en
    vivo (arriba) y la tarjeta destacada (abajo): S/ 384.33 en ambas.
  - Científico: verificado sin cambios de densidad ni de color en sus
    tarjetas de resultado.

## Publicación

- Publicado a producción con `vercel deploy --prod --force`.
- URL pública: `https://calculadora-logistica-sinba.vercel.app`.
- Verificado directamente en producción, no solo en local.

## Pendientes

- Del mockup original todavía queda por evaluar: reducir aún más la
  cantidad de tarjetas con borde morado repetidas (vehicle-badge, day-badge,
  etc.) y decidir si el layout de columnas del modo Normal debería cambiar
  de ancho fijo (360px) a algo más flexible en desktop grande.
- Seguir con las limpiezas chicas pendientes (regex, catálogo de
  vehículos, accesibilidad).

## Clasificación de la información

Documento interno de desarrollo. Puede compartirse con el equipo técnico
de SINBA; no debe utilizarse para almacenar credenciales ni información
personal.
