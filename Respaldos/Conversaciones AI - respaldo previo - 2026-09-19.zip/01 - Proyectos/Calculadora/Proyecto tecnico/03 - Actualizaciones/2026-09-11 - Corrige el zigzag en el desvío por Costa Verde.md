---
title: "Corrige el zigzag en el desvío por Costa Verde"
source_file: "docs/actualizaciones/2026-09-11-corrige-zigzag-desvio-costa-verde.md"
synced_at: "2026-09-17T19:00:00.282Z"
tags: [calculadora, proyecto-tecnico, actualizacion, fecha-2026-09-11]
---

# Actualización: Corrige el zigzag en el desvío por Costa Verde

Fecha: 2026-09-11
Estado: Publicada en producción y verificada contra el API de Google

## Objetivo

Marlon reportó que una cotización con camión grande (N2, varias paradas
en San Miguel y San Borja) trazaba una ruta que subía hasta La
Victoria/Gamarra y volvía a bajar, en vez de ir directo entre las paradas
— una vuelta de 100.5 km cuando la ruta original medía 43.6 km.

## Causa raíz

Cuando un vehículo N2/N3 no puede circular por el Circuito de Playas
(Costa Verde), el sistema arma una ruta alternativa insertando un
"corredor autorizado" (3 puntos fijos cerca de Vía de Evitamiento y
Av. Argentina) para desviar al camión tierra adentro.

El bug: ese corredor se insertaba **una vez por cada tramo bloqueado**,
no una vez por todo el bloque de tramos bloqueados consecutivos. Con
varias paradas seguidas cerca de la costa, el camión terminaba yendo al
mismo corredor fijo, de regreso, otra vez al corredor — eso es
exactamente el zigzag hacia Gamarra que se veía en el mapa.

## Reglas de negocio

- La restricción de Costa Verde para vehículos N2/N3 (>6.5 t) sigue
  vigente sin cambios — se confirmó contra el procedimiento
  `SST.LOG.PR.08 Procedimiento Circulación Lima Callao V3` que compartió
  Marlon: prohibición total 24 horas desde la bajada Escardó (San
  Miguel) hasta la bajada Huaylas (Chorrillos). El bloqueo en el código
  sigue siendo correcto.
- Se actualizó la referencia interna de "SST.LOG.PR.08 v02" a "v03" en
  el mensaje de cumplimiento y en el registro de la cotización, para que
  coincida con el documento vigente.

## Cambios realizados

- `app/api/route/route.ts`: el corredor de desvío ahora se inserta una
  sola vez por bloque continuo de tramos bloqueados (se resetea al
  primer tramo que ya no esté bloqueado), en vez de una vez por cada
  tramo individual.
- `lib/route-compliance.ts`: referencia del procedimiento actualizada a
  v03.

## Intento revertido: reoptimizar el orden en la ruta segura

Se intentó además permitir que la ruta alternativa (ya con el desvío de
seguridad) también reordenara las paradas cuando el usuario activa
"Optimizar paradas", ya que el orden usado hoy sigue siendo el que
Google calculó para la ruta costera original, no el ideal para el
camino tierra adentro.

**Se revirtió tras probarlo contra el API real de Google**: el API
rechaza de plano combinar `optimizeWaypointOrder: true` con puntos de
tipo `via` en la misma solicitud (error 400,
`Waypoint optimization does not support via waypoint`). Como el desvío
de seguridad se construye exactamente con puntos `via`, no es posible
pedir ambas cosas en una sola llamada a Google. Se documentó esto en el
código para que no se vuelva a intentar sin resolver antes ese
conflicto (requeriría una segunda llamada de optimización solo para las
paradas reales, antes de insertar los puntos de desvío).

## Validación

- 81/81 pruebas automatizadas aprobadas.
- `npm run build`: compilación de producción y TypeScript aprobados.
- ESLint: mismos 38 problemas preexistentes, cero regresiones nuevas (se
  corrigió además una advertencia menor en
  `scripts/export-docs-to-obsidian.mjs` con un caracter de control en una
  expresión regular intencional).
- Se verificó contra el API real de Google Routes (no simulado) el
  conflicto `optimizeWaypointOrder` + `via`, antes de descartar ese
  intento.
- No se pudo reproducir visualmente el caso exacto de Marlon (sin acceso
  a navegador esta sesión); la corrección se verificó por inspección de
  código y por las pruebas automatizadas existentes, que no fallaron.

## Publicación

- Publicado a producción con `vercel deploy --prod --force`.
- URL pública: `https://calculadora-logistica-sinba.vercel.app`.

## Pendientes

- Confirmar con Marlon, en una ruta real con camión grande y varias
  paradas costeras, que el zigzag desapareció.
- Evaluar una segunda llamada de optimización previa (solo paradas
  reales, sin puntos via) para que el orden de visita sí se ajuste al
  camino tierra adentro, no solo el desvío puntual — pendiente de
  decisión, es un cambio más grande sobre lógica de cumplimiento.
- Seguir con las limpiezas chicas pendientes (regex, catálogo de
  vehículos, accesibilidad, revisión visual del rediseño del modo
  Normal).

## Clasificación de la información

Documento interno de desarrollo. Puede compartirse con el equipo técnico
de SINBA; no debe utilizarse para almacenar credenciales ni información
personal.
