---
title: "Revierte la deduplicación del corredor de Costa Verde"
source_file: "docs/actualizaciones/2026-09-11-revierte-deduplicacion-corredor-costa-verde.md"
synced_at: "2026-09-17T19:00:00.282Z"
tags: [calculadora, proyecto-tecnico, actualizacion, fecha-2026-09-11]
---

# Actualización: Revierte la deduplicación del corredor de Costa Verde

Fecha: 2026-09-11
Estado: Publicada en producción y verificada contra el API de Google

## Objetivo

El cambio publicado hoy mismo (`1264ee4`, "Corrige el zigzag del desvío
por Costa Verde") introdujo una regresión: al probar planta → Mercado
Magdalena → planta con el vehículo N2 CDD-935, la app respondía
"La alternativa de Google todavía ingresa a la Costa Verde. La ruta
permanece bloqueada" — una ruta simple de ida y vuelta con una sola
parada, que antes funcionaba, dejó de poder cotizarse.

## Causa: mi propio error

El cambio de esta mañana insertaba el corredor autorizado (vía de
desvío) una sola vez por **bloque continuo** de tramos bloqueados, en
vez de una vez por cada tramo. La intención era evitar que rutas con
muchas paradas costeras rebotaran repetidamente al mismo corredor fijo.

Lo que no consideré: en una ruta de ida y vuelta con un solo destino, el
tramo de ida y el tramo de regreso son el **mismo corredor recorrido en
sentidos opuestos** — ambos necesitan su propio desvío hacia el
corredor autorizado. Como el código solo insertaba el desvío en el
primer tramo bloqueado y no reiniciaba el conteo entre dos tramos
bloqueados consecutivos, el tramo de regreso se quedaba sin ninguna
protección y Google volvía a trazarlo por la Costa Verde.

## Verificación antes de revertir

Se reprodujo el caso exacto (planta → Mercado Magdalena → planta,
vehículo N2) contra el API real de Google, no de forma simulada:

- Con la deduplicación (el código de esta mañana): el tramo de regreso
  seguía marcado `blocked=true` tras insertar el desvío — confirma la
  regresión.
- Sin deduplicación (insertando el corredor en cada tramo bloqueado,
  como estaba antes de hoy): ambos tramos (ida y vuelta) evitan
  correctamente la Costa Verde. Distancia total: 99.7 km (vs. 47.4 km
  directo) — más larga, pero válida y sin bloqueo.

## Cambios realizados

- `app/api/route/route.ts`: se revirtió la deduplicación por bloque
  continuo. El corredor autorizado vuelve a insertarse una vez por cada
  tramo bloqueado, como funcionaba antes de la actualización de esta
  mañana. Se dejó documentado en el código, con el detalle de por qué
  no es seguro deduplicar así, para que no se repita el mismo error sin
  antes resolver el caso de ida y vuelta.

## Validación

- 81/81 pruebas automatizadas aprobadas.
- `npm run build`: compilación de producción y TypeScript aprobados.
- ESLint: mismos 38 problemas preexistentes, cero regresiones nuevas.
- Verificado contra el API real de Google Routes con el caso exacto
  reportado (planta → Mercado Magdalena → planta, CDD-935): la ruta ya
  no se bloquea.

## Publicación

- Publicado a producción con `vercel deploy --prod --force`.
- URL pública: `https://calculadora-logistica-sinba.vercel.app`.

## Pendientes

- El problema original (zigzag hacia Gamarra/La Victoria en rutas con
  **varias** paradas costeras consecutivas) sigue sin resolver — el
  intento de esta mañana para solucionarlo fue el que causó esta
  regresión. Cualquier solución futura debe probarse contra el API real
  de Google, específicamente el caso de ida y vuelta con una sola
  parada, antes de publicarse.
- Confirmar con Marlon que la cotización planta → Mercado Magdalena →
  planta con CDD-935 ya funciona en producción.
- Seguir con las limpiezas chicas pendientes (regex, catálogo de
  vehículos, accesibilidad, revisión visual del rediseño del modo
  Normal).

## Clasificación de la información

Documento interno de desarrollo. Puede compartirse con el equipo técnico
de SINBA; no debe utilizarse para almacenar credenciales ni información
personal.
