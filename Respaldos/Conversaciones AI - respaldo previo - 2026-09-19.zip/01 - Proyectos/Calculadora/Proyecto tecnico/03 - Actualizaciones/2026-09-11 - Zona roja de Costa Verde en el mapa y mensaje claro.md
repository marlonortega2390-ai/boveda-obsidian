---
title: "Zona roja de Costa Verde en el mapa y mensaje claro"
source_file: "docs/actualizaciones/2026-09-11-zona-roja-costa-verde-y-mensaje-claro.md"
synced_at: "2026-09-17T19:00:00.282Z"
tags: [calculadora, proyecto-tecnico, actualizacion, fecha-2026-09-11]
---

# Actualización: Zona roja de Costa Verde en el mapa y mensaje claro

Fecha: 2026-09-11
Estado: Publicada en producción; verificada la lógica, pendiente confirmación visual

## Objetivo

Tras entender por qué el sistema bloquea ciertas rutas para camión grande,
Marlon pidió una forma más clara de comunicarlo: en vez de un mensaje
genérico, mostrar en el mapa la franja de Costa Verde en rojo (zona
prohibida) y explicar exactamente en qué tramo la ruta calculada la toca.
Explícitamente **sin opción de "aprobar de todos modos"**: el bloqueo se
mantiene tal cual, solo mejora la explicación.

## Reglas de negocio

- No cambia ninguna regla: la Costa Verde sigue bloqueada sin excepción
  para vehículos N2/N3, sin opción de anular el bloqueo desde la
  interfaz. Se confirmó explícitamente con Marlon antes de construir
  esto.
- Cambio de comunicación/UX, no de política.

## Cambios realizados

- `lib/route-compliance.ts`: se exporta `COSTA_VERDE_CHECKPOINTS` (antes
  privado) con un nombre de zona legible para cada punto de control
  (Barranco, Miraflores, San Isidro, Magdalena/San Miguel, etc.).
  `routeUsesCostaVerde` y `evaluateRouteCompliance` ahora devuelven
  `matchedZoneNames`, y el mensaje de bloqueo menciona la zona exacta en
  vez de un texto genérico.
- `app/api/route/route.ts`: el error `SAFE_ROUTE_STILL_RESTRICTED`
  (cuando ni la alternativa segura logra evitar Costa Verde) también
  menciona la zona exacta. El `routingAdjustment` que se guarda en la
  cotización aprobada ahora incluye `avoidedZoneNames`.
- `lib/costing/types.ts`: se agregó `avoidedZoneNames: string[]` al tipo
  `routingAdjustment` de `RouteSnapshot`.
- `app/components/InteractiveMap.tsx`: nuevo prop `restrictedCorridor`
  que dibuja una polilínea roja punteada sobre el mapa, independiente de
  si hay una ruta calculada o no — se ve apenas se selecciona el
  vehículo, no solo después de un bloqueo.
- `app/page.tsx`: cuando el vehículo seleccionado es N2/N3, se pasa el
  corredor de Costa Verde al mapa y se agrega su leyenda ("Costa Verde ·
  prohibido para N2"). El mensaje de "ruta recalculada por camión
  grande" ahora dice la zona evitada en vez de solo "Costa Verde"
  genérico.

## Validación

- 81/81 pruebas automatizadas aprobadas.
- `npm run build`: compilación de producción y TypeScript aprobados
  (se corrigió un error de tipos: el corredor exportado incluye
  `name`, y el mapa esperaba solo `{latitude, longitude}` — se proyecta
  antes de pasarlo).
- ESLint: mismos 38 problemas preexistentes, cero regresiones nuevas.
- Se verificó contra el API real de Google, reutilizando el caso de
  Mercado Magdalena: el mensaje ahora dice literalmente "Google trazó el
  recorrido por el Circuito de Playas (Costa Verde) en la zona de San
  Isidro, Magdalena / San Miguel" — antes decía solo "Google trazó parte
  del recorrido por la Costa Verde", sin especificar dónde.
- **No se pudo confirmar visualmente** que la línea roja se dibuja
  correctamente sobre el mapa de Google — la herramienta de navegador
  sigue sin funcionar esta sesión. Se verificó el código del componente
  y el build pasa, pero la confirmación visual queda pendiente.

## Publicación

- Publicado a producción con `vercel deploy --prod --force`.
- URL pública: `https://calculadora-logistica-sinba.vercel.app`.

## Pendientes

- Confirmar visualmente que la franja roja se ve bien sobre el mapa al
  seleccionar un vehículo N2/N3 (no se pudo verificar esta sesión).
- Evaluar si conviene mostrar la franja roja siempre (no solo con
  vehículo pesado seleccionado) para que el usuario la vea antes de
  elegir el camión.
- Seguir con las limpiezas chicas pendientes (regex, catálogo de
  vehículos, accesibilidad, revisión visual del rediseño del modo
  Normal).

## Clasificación de la información

Documento interno de desarrollo. Puede compartirse con el equipo técnico
de SINBA; no debe utilizarse para almacenar credenciales ni información
personal.
