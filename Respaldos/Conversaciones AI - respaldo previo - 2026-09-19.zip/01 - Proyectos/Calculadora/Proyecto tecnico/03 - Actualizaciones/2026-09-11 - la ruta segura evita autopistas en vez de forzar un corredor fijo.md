---
title: "la ruta segura evita autopistas en vez de forzar un corredor fijo"
source_file: "docs/actualizaciones/2026-09-11-ruta-segura-evita-autopistas-en-vez-de-corredor-fijo.md"
synced_at: "2026-09-17T19:00:00.282Z"
tags: [calculadora, proyecto-tecnico, actualizacion, fecha-2026-09-11]
---

# Actualización: la ruta segura evita autopistas en vez de forzar un corredor fijo

Fecha: 2026-09-11
Estado: Publicada en producción; verificada contra el API real de Google, pendiente confirmación visual

## Objetivo

Marlon reportó que, para un camión pesado (N2/N3) bloqueado por la Costa
Verde, la ruta recalculada daba un rodeo raro (por ejemplo hacia La
Victoria/Gamarra) en vez de ir directo. Compartió una captura de Google
Maps real mostrando que existe un camino directo razonable (Javier Prado
Este → Av. Brasil) que evita la Costa Verde sin ese rodeo. La sospecha de
Marlon — que el sistema estaba forzando puntos de paso fijos en vez de
simplemente evitar la autopista — era correcta.

## Reglas de negocio

- No cambia ninguna regla de negocio: la Costa Verde se mantiene
  bloqueada sin excepción para N2/N3, sin opción de anularlo desde la
  interfaz.
- Cambia el **mecanismo técnico** con el que Google recalcula la ruta
  cuando detecta el bloqueo.

## Cambios realizados

- `app/api/route/route.ts`: se eliminó el mecanismo de "corredor
  interior autorizado" (`AUTHORIZED_INLAND_CORRIDOR`, `pointDistance`,
  `orderedInlandViaPoints`, `viaWaypoint`) que insertaba 3 puntos de paso
  fijos (`via`) en cada tramo bloqueado. Se reemplazó por un único
  recálculo con `routeModifiers.avoidHighways: true` — se le pide a
  Google la misma ruta pero evitando vías expresas, sin forzar por dónde
  pasar.
- Efecto adicional: como ya no se usan puntos `via` (que son
  incompatibles con la reordenación automática de paradas en el API de
  Google), la ruta seguros ahora también respeta el botón "Optimizar
  paradas" cuando el usuario lo activa — antes esto no era posible en el
  tramo recalculado.
- `lib/costing/types.ts`: `routingAdjustment.strategy` ahora acepta
  `"AVOID_HIGHWAYS"` además de `"AUTHORIZED_INLAND_CORRIDOR"` (se
  mantiene el valor antiguo en el tipo por compatibilidad con
  cotizaciones ya guardadas en la base de datos).

## Validación

- Verificado contra el API real de Google (no simulado) con dos casos:
  - **Ida y vuelta a un solo punto** (Mercado Magdalena): la ruta segura
    da 49.0 km, contra 99.7 km del mecanismo anterior (corredor fijo)
    para el mismo caso — más de la mitad de distancia innecesaria antes.
  - **Multi-parada** (3 paradas costeras con reordenación activada): 0
    tramos bloqueados en la ruta final, y Google reordena las paradas
    normalmente (`optimizedIntermediateWaypointIndex` presente),
    combinación que antes no era posible.
- 81/81 pruebas automatizadas aprobadas.
- `npm run build`: compilación de producción y TypeScript aprobados
  (se corrigió un error de tipos por el nuevo valor de `strategy`).
- ESLint: mismos 38 problemas preexistentes (34 errores `jsx-a11y` + 4
  warnings), cero regresiones nuevas.
- **No se pudo confirmar visualmente** en el mapa — la herramienta de
  navegador integrada sigue sin funcionar esta sesión. Toda la
  validación de este cambio se hizo contra el API real de Google y las
  pruebas automatizadas, no por inspección visual del mapa.

## Publicación

- Publicado a producción con `vercel deploy --prod --force`.
- URL pública: `https://calculadora-logistica-sinba.vercel.app`.

## Pendientes

- Confirmar visualmente en el mapa que la ruta calculada para camiones
  pesados ya no zigzaguea (no se pudo verificar esta sesión).
- Confirmar visualmente que la franja roja de Costa Verde se ve bien
  (pendiente de la actualización anterior, sigue sin resolverse).
- Limpiezas menores ya identificadas (accesibilidad, regex, catálogo de
  vehículos) — sin prioridad actual.

## Clasificación de la información

Documento interno de desarrollo. Puede compartirse con el equipo técnico
de SINBA; no debe utilizarse para almacenar credenciales ni información
personal.
