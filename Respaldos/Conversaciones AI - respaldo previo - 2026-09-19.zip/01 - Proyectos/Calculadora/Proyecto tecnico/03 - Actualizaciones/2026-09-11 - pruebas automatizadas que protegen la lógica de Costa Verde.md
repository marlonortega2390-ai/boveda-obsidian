---
title: "pruebas automatizadas que protegen la lógica de Costa Verde"
source_file: "docs/actualizaciones/2026-09-11-pruebas-automatizadas-costa-verde.md"
synced_at: "2026-09-17T19:00:00.282Z"
tags: [calculadora, proyecto-tecnico, actualizacion, fecha-2026-09-11]
---

# Actualización: pruebas automatizadas que protegen la lógica de Costa Verde

Fecha: 2026-09-11
Estado: Publicada (solo pruebas/herramientas de desarrollo, no cambia producción)

## Objetivo

El cambio anterior de esta misma sesión (evitar autopistas en vez de un
corredor fijo) fue bueno, pero Marlon notó algo importante: la única
razón por la que detectamos el error del corredor fijo, y luego una
regresión mía al intentar arreglarlo, fue porque probé manualmente contra
el API real con scripts sueltos que después borré. Si eso vuelve a pasar
con otro cambio futuro, no hay nada que avise automáticamente.

Este cambio agrega una red de seguridad: los casos reales que ya nos
dieron problemas quedan grabados como pruebas automatizadas permanentes,
así que si algo rompe esta lógica de nuevo, se nota al correr las
pruebas (`npm run build` / CI), no cuando un cliente reporta una ruta
rara.

## Cambios realizados

- `tests/fixtures/google-routes/*.json`: respuestas **reales** del API de
  Google Routes, grabadas una sola vez, para los 3 casos que importan:
  - `magdalena-roundtrip-initial` / `-safe`: el caso original reportado
    (ida y vuelta a Mercado Magdalena, bloqueado y luego resuelto).
  - `multistop-initial` / `-safe`: 3 paradas costeras con "optimizar
    paradas" activado, para probar que el reordenamiento sigue
    funcionando en la ruta recalculada.
- `scripts/record-route-fixtures.mjs`: script para regrabar estos
  fixtures contra el API real si algún día cambian las direcciones de
  prueba o se necesitan casos nuevos (no se ejecuta en cada build, solo
  cuando alguien decide actualizar los fixtures).
- `tests/route-api.test.ts`: 3 pruebas nuevas que llaman al handler real
  de `/api/route` (`POST` tal cual lo usa la app), simulando la red con
  las respuestas grabadas de Google en vez de llamarlo en vivo:
  1. Camión N2 bloqueado ida y vuelta → confirma que se recalcula y ya
     no queda bloqueado.
  2. Camión N2 con 3 paradas + optimizar activado → confirma que el
     recalculo conserva el reordenamiento de paradas (la mejora que
     desbloqueó el cambio anterior).
  3. Camión N1 → confirma que un vehículo liviano nunca dispara este
     recálculo (no debería, la restricción es solo para N2/N3).

## Validación

- 84/84 pruebas automatizadas aprobadas (81 anteriores + 3 nuevas).
- `npm run build`: compilación de producción aprobada.
- No se tocó ninguna ruta de producción; estas son solo pruebas y
  herramientas de desarrollo.

## Publicación

- No aplica publicación a Vercel (no cambia código de producción).

## Pendientes

- Considerar una alerta en producción cuando Google no logra evitar la
  Costa Verde (`SAFE_ROUTE_STILL_RESTRICTED`), para enterarnos si eso
  empieza a pasar seguido — sugerido, no implementado aún.
- Verificación visual automatizada del mapa (Playwright) sigue pendiente
  — sugerida, no implementada aún.

## Clasificación de la información

Documento interno de desarrollo. Puede compartirse con el equipo técnico
de SINBA; no debe utilizarse para almacenar credenciales ni información
personal.
