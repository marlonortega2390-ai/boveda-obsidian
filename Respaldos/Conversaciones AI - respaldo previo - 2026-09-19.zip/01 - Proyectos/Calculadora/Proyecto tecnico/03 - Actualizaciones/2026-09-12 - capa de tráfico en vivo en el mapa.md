---
title: "capa de tráfico en vivo en el mapa"
source_file: "docs/actualizaciones/2026-09-12-capa-de-trafico-en-vivo-en-el-mapa.md"
synced_at: "2026-09-17T19:00:00.282Z"
tags: [calculadora, proyecto-tecnico, actualizacion, fecha-2026-09-12]
---

# Actualización: capa de tráfico en vivo en el mapa

Fecha: 2026-09-12
Estado: Publicada en producción; verificada por build y pruebas, pendiente confirmación visual

## Objetivo

A partir de un enlace de Google Maps que Marlon compartió, surgió la
pregunta de si podíamos integrar Waze para tener esa misma sensación
visual (colores de tráfico, íconos). Se investigó y se concluyó que:

- Waze no ofrece un API público para negocios; el programa gratuito
  (Waze for Cities) es solo para entidades de gobierno, y el SDK de
  transporte está siendo descontinuado (1 nov 2026).
- Los servicios de terceros que revenden datos de Waze (ej. wazeapi.com)
  operan sin autorización de Waze, en contra de sus términos de
  servicio explícitos — riesgo de que el proveedor sea bloqueado en
  cualquier momento.
- Los íconos de incidentes (choques, controles) que se ven en la app de
  Google Maps/Waze son exclusivos de esas apps de consumidor; Google no
  los expone por su API de mapas para negocios, con o sin costo.

Lo que sí es real y gratuito con el mismo API que ya se paga: la capa de
colores de tráfico (`TrafficLayer`). Se decidió implementar esto en vez
de perseguir una integración de terceros de legalidad dudosa.

## Reglas de negocio

- No cambia ninguna regla de negocio ni de cálculo de costos; es una
  mejora puramente visual del mapa.

## Cambios realizados

- `app/components/InteractiveMap.tsx`: se agrega `google.maps.TrafficLayer`
  al mapa, activo siempre (se enciende junto con el mapa, no depende de
  si hay una ruta calculada). Usa el mismo API key de Google Maps para
  navegador que ya está configurado — no requiere ninguna cuenta, permiso
  ni costo adicional.

## Validación

- 84/84 pruebas automatizadas aprobadas (sin relación directa con el
  mapa, pero confirman que no se rompió nada más).
- `npm run build`: compilación de producción aprobada.
- ESLint: mismos 38 problemas preexistentes, cero regresiones nuevas.
- **No se pudo confirmar visualmente** que la capa de tráfico se ve
  correctamente sobre el mapa — la herramienta de navegador integrada
  sigue sin funcionar esta sesión. Queda pendiente que Marlon confirme
  visualmente en la app.

## Publicación

- Publicado a producción con `vercel deploy --prod --force`.
- URL pública: `https://calculadora-logistica-sinba.vercel.app`.

## Pendientes

- Confirmar visualmente que los colores de tráfico se ven bien sobre
  el mapa (no se pudo verificar esta sesión).
- Evaluar, si Marlon lo pide, un indicador propio de "retraso por
  tráfico" en la cotización (ya se calcula `trafficDelayMinutes`, solo
  falta mostrarlo con más énfasis visual).
- Evaluar, si Marlon lo pide, un sistema propio de reportes de
  incidentes por parte de los choferes (alternativa interna a lo que
  Waze no permite compartir).

## Clasificación de la información

Documento interno de desarrollo. Puede compartirse con el equipo técnico
de SINBA; no debe utilizarse para almacenar credenciales ni información
personal.
