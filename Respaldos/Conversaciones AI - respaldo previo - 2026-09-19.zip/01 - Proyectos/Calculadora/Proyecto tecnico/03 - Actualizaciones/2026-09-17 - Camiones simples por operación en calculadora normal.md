---
title: "Camiones simples por operación en calculadora normal"
source_file: "docs/actualizaciones/2026-09-17-camiones-simples-por-operacion.md"
synced_at: "2026-09-17T19:00:00.282Z"
tags: [calculadora, proyecto-tecnico, actualizacion, fecha-2026-09-17]
---

# Actualización: Camiones simples por operación en calculadora normal

Fecha: 2026-09-17
Estado: Publicada

## Objetivo

Simplificar la selección de camiones en la calculadora normal y ubicar el perfil de carga antes de los viajes operativos.

## Reglas de negocio

- SINBA normal: Camión pequeño usa BUY-730 (eléctrico); Camión grande usa CDD-935 (GNV).
- Cubas normal: únicamente Camión grande, seleccionado automáticamente, referencia AUX-943 (Hyundai EX10). El usuario lo mencionó como AVX; la matrícula existente en el catálogo es AUX-943.
- Científica: conserva las cinco unidades SINBA y las cuatro Cubas, con su selección detallada.
- Al volver a normal se normaliza la unidad: SINBA N1 a BUY-730, SINBA pesado a CDD-935, Cubas a AUX-943.
- Se conservan las tarifas, capacidad, autonomía y asignación de conductor de las unidades reales. No se crean precios promedio ni un nuevo motor.
- Cambiar operación o camión en normal limpia ruta, aprobación, resultado e impresión previos. La siguiente consulta de ruta requiere acción del usuario.
- Perfil de carga precede a viajes únicamente en normal; científica conserva su orden.

## Cambios realizados

- app/page.tsx: opciones normales por proveedor, referencia visible, Cubas automático y normalización entre modos.
- Reutilización del mismo bloque de carga para conservar sus controles en ambos modos.
- Asociación accesible del selector de vehículo con su etiqueta.

## Validación

- 84/84 pruebas existentes: npx tsx --test tests/costing.test.ts tests/route-api.test.ts.
- npm run build: compilación y TypeScript correctos.
- Navegador Edge local: dos tamaños SINBA, un tamaño Cubas con AUX-943 seleccionado, conductor A1/A2B, capacidad, cinco vehículos SINBA y cuatro Cubas en científica, transición a normal, aviso al superar 500 kg de reciclaje en pequeño y orden carga/viajes.
- Vista móvil de 390 px sin desborde horizontal; captura revisada.
- Sin errores JavaScript durante la prueba. Servicios API simulados y tráfico externo bloqueado: cero consultas Google y sin escrituras de cotizaciones reales.
- ESLint de app/page.tsx aún reporta 32 errores de etiquetas y una advertencia de dependencias de efecto; no se considera lint aprobado.
- git diff --check correcto.

## Publicación

Publicada en producción en Vercel el 2026-09-17.

- Enlace público estable: https://calculadora-logistica-sinba.vercel.app/
- Despliegue de producción: dpl_H2s3PCHqc144PYs2H2YZxwy3tgD6.
- Estado de Vercel: Ready.
- Verificación posterior: HTTP 200, título de la calculadora y código publicado con “Camión pequeño” y la referencia AUX-943.

## Pendientes

- Resolver la deuda de accesibilidad del formulario en una actualización dedicada.
- Las pruebas de pantalla no validan conectividad Google ni persistencia real de cotizaciones.

## Clasificación de la información

Documento interno. No contiene credenciales ni datos personales.
