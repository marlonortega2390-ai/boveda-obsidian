---
title: "Plantilla de actualizacion"
source_file: "docs/actualizaciones/PLANTILLA.md"
synced_at: "2026-09-17T19:00:00.282Z"
tags: [calculadora, proyecto-tecnico, plantilla]
---

# Actualización: Título breve

Fecha: AAAA-MM-DD  
Estado: Local / En validación / Publicada

## Objetivo

Explicar brevemente qué problema se resolvió y para quién.

## Reglas de negocio

- Regla incorporada o modificada.
- Resultado esperado.

## Cambios realizados

- Pantallas, cálculos o servicios modificados.
- Archivos principales afectados, sin copiar secretos ni datos sensibles.

## Validación

- Pruebas ejecutadas.
- Compilación y revisión visual.

## Publicación

- Entorno y estado de despliegue.
- No registrar códigos de acceso, tokens, IP ni enlaces temporales de autenticación.

## Pendientes

- Trabajo que todavía requiere decisión, datos o autorización.

## Clasificación de la información

Documento interno. No contiene credenciales ni datos personales.
