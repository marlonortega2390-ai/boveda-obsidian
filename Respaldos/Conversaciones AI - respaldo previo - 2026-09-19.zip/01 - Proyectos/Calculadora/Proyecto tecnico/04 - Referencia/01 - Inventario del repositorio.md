---
title: "Inventario del repositorio"
source_file: "repositorio local"
synced_at: "2026-09-17T19:00:00.282Z"
tags: [calculadora, proyecto-tecnico, inventario]
---


# Inventario del repositorio

Ruta local: `C:\Users\marlo\OneDrive\Desktop\CALCULADORA`

> [!info]
> Este inventario referencia el codigo, no lo duplica. Obsidian guarda la documentacion.

## Interfaz y paginas

- `app/api/assistant/route.ts`
- `app/api/catalog/detour/route.ts`
- `app/api/catalog/nearby/route.ts`
- `app/api/catalog/route.ts`
- `app/api/maps-config/route.ts`
- `app/api/maps-link/route.ts`
- `app/api/operational-routes/route.ts`
- `app/api/quotes/route.ts`
- `app/api/route/route.ts`
- `app/api/settings/route.ts`
- `app/api/settings/sync/route.ts`
- `app/chatgpt-auth.ts`
- `app/components/InteractiveMap.tsx`
- `app/components/LogisticsAssistant.tsx`
- `app/globals.css`
- `app/layout.tsx`
- `app/page.tsx`

## Logica de negocio

- `lib/api-response.ts`
- `lib/assistant/local-knowledge.ts`
- `lib/assistant/question-bank.ts`
- `lib/client-catalog/catalog.ts`
- `lib/client-catalog/geometry.ts`
- `lib/client-catalog/storage.ts`
- `lib/client-catalog/types.ts`
- `lib/costing/audit.ts`
- `lib/costing/bags.ts`
- `lib/costing/calendar.ts`
- `lib/costing/capacity.ts`
- `lib/costing/catalog.ts`
- `lib/costing/config.ts`
- `lib/costing/engine.ts`
- `lib/costing/public-result.ts`
- `lib/costing/storage.ts`
- `lib/costing/tolls.ts`
- `lib/costing/types.ts`
- `lib/costing/unit-economics.ts`
- `lib/google-maps.ts`
- `lib/google-routes-client.ts`
- `lib/google-sheets-config.ts`
- `lib/massive-routing.ts`
- `lib/massive-schedule.ts`
- `lib/operation-timing.ts`
- `lib/route-compliance.ts`
- `lib/route-departure.ts`
- `lib/runtime-env.ts`

## Base de datos

- `db/index.ts`
- `db/schema.ts`

## Migraciones

- `drizzle/0000_steep_hemingway.sql`
- `drizzle/0001_dashing_paladin.sql`
- `drizzle/0002_silly_storm.sql`
- `drizzle/0003_auditable_snapshots.sql`
- `drizzle/0004_client_catalog.sql`
- `drizzle/meta/0000_snapshot.json`
- `drizzle/meta/0001_snapshot.json`
- `drizzle/meta/0002_snapshot.json`
- `drizzle/meta/_journal.json`

## Pruebas

- `tests/costing.test.ts`
- `tests/fixtures/google-routes/magdalena-roundtrip-initial.json`
- `tests/fixtures/google-routes/magdalena-roundtrip-safe.json`
- `tests/fixtures/google-routes/multistop-initial.json`
- `tests/fixtures/google-routes/multistop-safe.json`
- `tests/fixtures/massive-routes-30.csv`
- `tests/rendered-html.test.mjs`
- `tests/route-api.test.ts`

## Scripts

- `scripts/export-docs-to-obsidian.mjs`
- `scripts/import-operational-routes.py`
- `scripts/import_kml_catalog.py`
- `scripts/record-route-fixtures.mjs`
