---
tags: [indice, conversaciones-ai]
---

# Check List

- [[Optimiza checklist móvil y alertas--01a03e51-f6f9-7bd1-8367-0dbedfd41002|Optimiza checklist móvil y alertas]]
