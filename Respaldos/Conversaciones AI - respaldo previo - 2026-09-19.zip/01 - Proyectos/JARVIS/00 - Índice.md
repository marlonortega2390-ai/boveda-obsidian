---
tags: [indice, conversaciones-ai]
---

# JARVIS

- [[Corrige borrado de conversaciones--01a05a53-5cc8-7f83-8512-01742abf2833|Corrige borrado de conversaciones]]
- [[Retoma el proyecto existente--01a04e3a-ff79-7b03-8de1-c17e57bb7753|Retoma el proyecto existente]]
- [[Exportación para JARVIS--6a95abde-f7d0-83e9-ba1e-b052d8424f21|Exportación para JARVIS]]
- [[Crear documento maestro JARVIS--01a058a7-b997-75a0-b8d5-ecdb156441e6|Crear documento maestro JARVIS]]
- [[Recuperar carpeta Jarvis--6a9090d6-1e84-83e9-b603-806883b2effd|Recuperar carpeta Jarvis]]

<!-- JARVIS-TECH-START -->
## Proyecto técnico

- [[Proyecto técnico/00 - Centro de control|Abrir centro de control de JARVIS]]
<!-- JARVIS-TECH-END -->
