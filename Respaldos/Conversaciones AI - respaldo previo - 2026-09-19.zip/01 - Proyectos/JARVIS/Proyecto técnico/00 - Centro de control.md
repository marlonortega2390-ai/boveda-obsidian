---
title: "JARVIS - Centro de control"
synced_at: "2026-09-10T19:04:43.927038+00:00"
tags: [jarvis, proyecto, indice]
---

# JARVIS — Centro de control

> [!summary] Estado
> MVP 1 en laboratorio. La memoria es versionada, las contradicciones exactas se bloquean, las comunicaciones siguen simuladas y existe una primera lectura local por voz.

## Continuar el trabajo

- [[02 - Estado/01 - Contexto recuperado|Contexto recuperado]]
- [[02 - Estado/02 - Avance 2026-09-05|Último avance documentado]]
- [[03 - Evaluación/01 - Evaluaciones MVP 0|Evaluaciones y criterios de salida]]

## Diseño del producto

- [[01 - Fundamentos/01 - Fundación y comportamiento|Fundación y reglas]]
- [[01 - Fundamentos/02 - Diseño de experiencia|Voz, personalidad e interfaz]]

## Referencia técnica

- [[04 - Referencia/01 - README técnico|Cómo ejecutar y probar]]
- [[04 - Referencia/02 - Inventario del repositorio|Mapa del código]]

## Conversaciones relacionadas

- [[../00 - Índice|Índice de conversaciones de JARVIS]]

## Próximo bloque recomendado

1. Entrada de voz local con pulsar para hablar e indicador visible del micrófono.
2. Adaptador intercambiable para modelos de lenguaje con presupuesto y límites.
3. Integración opcional de ElevenLabs cuando el flujo local esté probado.
