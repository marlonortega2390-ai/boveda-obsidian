---
title: "Contexto recuperado"
source_file: "CONTEXTO_RECUPERADO.md"
synced_at: "2026-09-10T19:04:43.927038+00:00"
tags: [jarvis, proyecto-tecnico, continuidad]
---

# Proyecto JARVIS - Punto de control recuperado

Fecha de actualizacion: 2026-09-05

## Objetivo vigente

Construir un asistente personal local y verificable mediante entregas pequenas:
coordinacion y memoria locales, permisos explicitos, auditoria reconstruible y
acciones externas solamente despues de una confirmacion ligada a un alcance
exacto.

La direccion acordada en los documentos es la Ruta B (arquitectura hibrida),
implementada gradualmente mediante la Ruta C. La vision multimodal completa se
mantiene como norte, no como primer despliegue.

## Estado encontrado

### Nucleo Python (MVP 0)

Implementado en `src/jarvis_core`:

- eventos, solicitudes, autorizaciones y decisiones estructuradas;
- politicas de alcance y autorizacion exacta;
- memoria SQLite separada por proyecto;
- fuentes y prompts versionados;
- auditoria local JSONL;
- laboratorio de acciones simuladas y reversibles;
- detencion de emergencia;
- boveda personal con candidatos de memoria, aprobacion del propietario,
  audiencias y respaldos cifrados.

Hay 55 pruebas entre el nucleo, la boveda, comunicaciones, la interfaz y la
configuracion de seguridad de Tauri. Todas pasan con el runtime Python local
3.12.13 ubicado bajo `.cache/codex-runtimes`; no es necesario instalar Python
globalmente durante el desarrollo actual.

### Comunicaciones simuladas (inicio de MVP 1)

- `CommunicationItem` representa mensajes sin convertirlos en acciones.
- la clasificacion y prioridad usan reglas deterministas, no criterio libre de
  un modelo de lenguaje;
- la cola esta separada por proyecto;
- posponer e ignorar quedan auditados sin almacenar el texto original;
- la interfaz web muestra cuatro mensajes ficticios y sus reglas de prioridad;
- mensajes claros y probables generan borradores locales deterministas;
- mensajes inciertos o sin necesidad de respuesta no generan borradores;
- aprobar o rechazar requiere una decision explicita y queda auditado;
- aprobar nunca envia: todos los borradores conservan `sent: false`;
- todavia no existen cuentas conectadas ni envios.

### Registro seguro de herramientas

- `ToolRegistry` es la lista blanca autoritativa del laboratorio;
- solamente se aceptan combinaciones exactas de herramienta y operacion;
- cada operacion tiene un riesgo minimo que la solicitud no puede rebajar;
- herramientas y operaciones desconocidas se rechazan por defecto;
- una autorizacion no puede habilitar una herramienta no registrada;
- `PolicyEngine` conserva la autorizacion puntual por huella para operaciones
  registradas que escriben o tienen riesgo reversible o sensible.

### Importacion de memoria

- `MemoryImportService` valida las diez secciones de `export_version` 1.0;
- la vista previa no crea candidatos ni recuerdos;
- solamente `memory_candidates` puede pasar a la boveda;
- importar crea candidatos pendientes, nunca memorias aprobadas;
- las huellas persistentes detectan reimportaciones del mismo candidato;
- los patrones evidentes de claves privadas o tokens quedan bloqueados;
- la auditoria registra hashes, conteos e identificadores, no el contenido;
- el archivo real de prueba produjo 34 registros, 4 candidatos listos y luego
  4 duplicados al verificar la importacion;
- los cuatro candidatos reales permanecen pendientes de decision de Marlon.

### Interfaces existentes

1. `src/jarvis_core/desktop_app.py`: interfaz Tkinter conectada al nucleo.
2. `native/JarvisDemo.cs` y `dist/JarvisDemo.exe`: demostracion nativa de
   Windows.
3. `ui` y `src-tauri`: interfaz visual mas reciente, con esfera flotante y
   panel independiente.

La interfaz Tauri tiene CSP restrictiva y solamente `core:default`; no concede
acceso a shell, archivos, HTTP, dialogos ni procesos. La interfaz web local si
esta conectada al nucleo Python mediante un servidor limitado a `127.0.0.1`.

## Estado de Tauri comprobado

La toolchain local de Rust funciona y Tauri compila un ejecutable real. El icono
requerido ya existe. La politica empresarial de integridad de codigo de Windows
bloquea la ejecucion de binarios nuevos sin firma; no se debe debilitar esa
proteccion. Por ahora la via funcional y segura es la interfaz web local.

## Continuacion recomendada

Actualización 2026-09-05: consultar `AVANCE_2026-09-05.md` para la edición
versionada de candidatos, bloqueo de contradicciones y primera lectura por voz.
Los puntos 2 y 3 de la lista siguiente quedan implementados con comparación
de claves exactas; la detección semántica aún está pendiente.

1. Revisar y decidir los cuatro candidatos importados desde el tablero.
2. Permitir corregir un candidato de memoria antes de aprobarlo.
3. Agregar versionado y contradicciones explicitas a la boveda.
4. Mantener `ActionRequest` reservado para acciones ejecutables de niveles 3-4.
5. Solo despues evaluar integraciones de lectura; no conectar cuentas reales hasta
   tener permisos, limites y pruebas especificos.

## Riesgo de continuidad

La carpeta ya es un repositorio Git. El commit inicial `1939483` contiene todo el
MVP 0 y las interfaces anteriores. Los artefactos generados estan excluidos; cada
nuevo avance material debe terminar con pruebas y un commit identificable.
