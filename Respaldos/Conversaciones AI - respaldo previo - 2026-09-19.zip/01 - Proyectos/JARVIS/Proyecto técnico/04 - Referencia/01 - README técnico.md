---
title: "README técnico"
source_file: "README.md"
synced_at: "2026-09-10T19:04:43.927038+00:00"
tags: [jarvis, proyecto-tecnico, referencia]
---

# JARVIS Core - MVP 1 en laboratorio

Este directorio contiene el primer nucleo ejecutable del proyecto. No usa microfono, red, WhatsApp, cuentas, shell ni archivos personales.

Capacidades actuales:

- eventos y decisiones estructuradas;
- memoria SQLite separada por proyecto;
- registro de prompts versionados;
- autorizaciones ligadas al recurso y alcance exactos;
- registro de herramientas por lista blanca, con rechazo seguro por defecto;
- importador JSON con vista previa, deduplicacion y aprobacion posterior;
- auditoria local en JSONL;
- herramientas simuladas y reversibles;
- bandeja de comunicaciones simuladas, separada por proyecto;
- clasificacion y prioridad deterministas, con reglas visibles y auditables;
- decisiones locales para posponer o ignorar mensajes de prueba;
- borradores locales deterministas que siempre esperan aprobacion y nunca se envian;
- 55 pruebas automatizadas del nucleo, la interfaz y sus politicas.

## Ejecutar pruebas

Desde este directorio:

```powershell
$env:PYTHONPATH = "src"
python -m unittest discover -s tests -v
```

El proyecto no instala dependencias externas.

## Registro seguro de herramientas

El nucleo solamente acepta combinaciones de herramienta y operacion declaradas
en `src/jarvis_core/tool_registry.py`. Cada operacion registra su riesgo minimo.
Una herramienta desconocida, una operacion nueva o una solicitud que declare un
riesgo inferior al registrado se bloquean antes de llegar al ejecutor, incluso si
la solicitud presenta una autorizacion.

## Importar memoria

El tablero permite seleccionar un `JARVIS_IMPORT.json` local. La primera etapa
solo valida el esquema y muestra los candidatos. La segunda crea candidatos
pendientes en la boveda; no los aprueba. El importador detecta repeticiones por
huella, limita el tamano y la cantidad de registros, bloquea patrones evidentes
de secretos y conserva en auditoria solamente hashes e identificadores.

## Limites deliberados

La version 0.1 no puede escuchar el microfono, acceder a Internet, leer WhatsApp o correo, ejecutar comandos del sistema, modificar libros reales ni enviar, publicar, comprar o borrar.

## Interfaz Tauri

La nueva interfaz vive en `ui` y `src-tauri`. Se compone de una esfera flotante
y un panel local independiente. Su configuracion inicial solo concede
`core:default`: no tiene permisos de archivos, shell, HTTP, dialogos ni procesos.

Cuando Microsoft C++ Build Tools y el Windows SDK esten instalados, ejecuta
`Start-Jarvis-Tauri.cmd`. La primera compilacion descargara y compilara las
dependencias oficiales de Rust; las siguientes aperturas seran mas rapidas.

## Interfaz web local

`Start-Jarvis-Web.ps1` abre el panel moderno usando un servidor Python limitado
a `127.0.0.1`. La version de demostracion usa datos temporales, no concede
acceso a cuentas reales y conecta memoria, autorizaciones y detencion con el
nucleo del MVP 0. Las operaciones de escritura siguen confinadas al laboratorio.

La primera pieza del MVP 1 es una bandeja completamente simulada: no lee correo,
WhatsApp ni cuentas reales. Ordena cuatro mensajes de demostracion mediante
reglas explicitas, muestra por que obtuvo cada prioridad y registra las decisiones
de posponer o ignorar sin guardar el texto del mensaje en la auditoria.

Los mensajes claros o probables pueden producir un borrador de respuesta local.
Los mensajes inciertos se detienen para revision humana y los que no requieren
respuesta no generan borrador. Aprobar un texto solamente cambia su estado local:
la interfaz y la auditoria conservan explicitamente `sent: false`.
