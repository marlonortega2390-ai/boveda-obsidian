---
title: "Inventario del repositorio"
source_file: "repositorio local"
synced_at: "2026-09-10T19:04:43.927038+00:00"
tags: [jarvis, proyecto-tecnico, inventario]
---


# Inventario del repositorio

Ruta local: `C:\Users\marlo\Documents\Codex\2026-08-22\https-www-youtube-com-watch-v\jarvis-core`

> [!info]
> Este inventario referencia el código. Obsidian guarda la documentación, no duplica binarios ni bases privadas.

## Núcleo Python

- `src/jarvis_core/__init__.py`
- `src/jarvis_core/audit.py`
- `src/jarvis_core/backup.py`
- `src/jarvis_core/communications.py`
- `src/jarvis_core/desktop_app.py`
- `src/jarvis_core/laboratory.py`
- `src/jarvis_core/memory.py`
- `src/jarvis_core/memory_import.py`
- `src/jarvis_core/models.py`
- `src/jarvis_core/orchestrator.py`
- `src/jarvis_core/policy.py`
- `src/jarvis_core/prompts.py`
- `src/jarvis_core/sources.py`
- `src/jarvis_core/tool_registry.py`
- `src/jarvis_core/vault.py`
- `src/jarvis_core/web_app.py`

## Interfaz

- `ui/orb.css`
- `ui/orb.html`
- `ui/orb.js`
- `ui/panel.css`
- `ui/panel.html`
- `ui/panel.js`
- `ui/voice.js`

## Aplicación Tauri

- `src-tauri/src/main.rs`

## Configuración

- `config/prompts.json`
- `config/sources.json`

## Pruebas

- `tests/test_communications.py`
- `tests/test_desktop_ui.py`
- `tests/test_memory_import.py`
- `tests/test_memory_versions.py`
- `tests/test_mvp0.py`
- `tests/test_obsidian_project_export.py`
- `tests/test_tauri_security.py`
- `tests/test_vault.py`
- `tests/test_web_app.py`
