---
title: "Actualizar procedimiento permisos"
conversation_id: "6a9858a9-5f7c-83e9-9eea-2fbe10a40c58"
type: "chatgpt"
project_id: "g-p-6a020623cb188191a191cc56b72a75d2"
area: "01 - Proyectos/Logística SINBA"
updated_at: 1788369713.265
archived: false
export_complete: true
tags: [conversacion-ai, jarvis-import]
---

# Actualizar procedimiento permisos

- ID: `6a9858a9-5f7c-83e9-9eea-2fbe10a40c58`
- Tipo: `chatgpt`
- Proyecto: `g-p-6a020623cb188191a191cc56b72a75d2`
- Estado: `activa`

## Conversación

### Marlon

Necesito actualizar mi procedimiento con estos permisos

[User attached 4 files; file contents were not included]

### Asistente

Sí. Ya actualicé tu procedimiento y lo dejé como **Versión 3 – 02/09/2026**, listo para revisión y nueva aprobación.

Los cambios principales fueron:
- Incorporé la **Resolución de Subgerencia N.° D003620-2026-MML-GMU-SER**, emitida el 20/08/2026, que autoriza a SINBA a prestar el servicio de transporte de carga en Lima Metropolitana por 5 años. fileciteturn2file1
- Incluí las **8 unidades autorizadas**, con placa, categoría N1/N2, PBV y TUC: BUY-730, CKL-934, C3H-785, D4X-827, D9L-942, AUX-943, CDD-935 y CDD-700. fileciteturn1file16
- Incorporé la **Red Vial de Carga de Lima Metropolitana** y las condiciones para N1 y N2 según peso y tipo de vía. fileciteturn2file2
- Dejé expresamente separado **Lima Metropolitana de Callao**: el nuevo permiso de MML **no autoriza por sí mismo las vías restringidas del Callao**. Esto era importante para no generar una interpretación equivocada frente a fiscalización. fileciteturn2file1
- Conservé las reglas que ya tenías para Callao, rutas alternas y Costa Verde, pero adapté la estructura del procedimiento original. fileciteturn2file0
- También marqué las firmas como **PENDIENTES**, porque al pasar de versión 2 a versión 3 no corresponde reutilizar las firmas de aprobación anteriores como si aprobaran esta modificación.

Además, dejé una advertencia interna sobre la Nota Informativa de 2023: contiene referencias a una suspensión que llegaba solo hasta el **31/12/2023**, por lo que no la presenté como una exoneración vigente en 2026. fileciteturn2file2

:chatgpt-content-reference{index="4"}
