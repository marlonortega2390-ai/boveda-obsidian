---
title: "Agregar pendientes a Notion"
conversation_id: "6aa16b51-d25c-83e9-b163-bb723868c193"
type: "chatgpt"
project_id: "g-p-6a020623cb188191a191cc56b72a75d2"
area: "01 - Proyectos/Logística SINBA"
updated_at: 1788963814.653
archived: false
export_complete: true
tags: [conversacion-ai, jarvis-import]
---

# Agregar pendientes a Notion

- ID: `6aa16b51-d25c-83e9-b163-bb723868c193`
- Tipo: `chatgpt`
- Proyecto: `g-p-6a020623cb188191a191cc56b72a75d2`
- Estado: `activa`

## Conversación

### Marlon

[@Notion](plugin://computer-use@openai-bundled?app=com.electron.notion) quiero agregar mis pendientes de trabajo a notion

### Asistente

Sí. Te acabo de mostrar la integración oficial de **Notion** para que la conectes.

Cuando quede conectada, escríbeme **“listo”** y puedo trabajar tus pendientes directamente ahí. Mi propuesta es no crear cosas duplicadas: primero revisaré si ya tienes una página o base de datos de tareas y, si existe, la usaré.

La organizaría con estas columnas: **Pendiente | Proyecto/Área | Prioridad | Estado | Fecha límite | Responsable | Próximo paso | Notas**.

Además, puedo ayudarte a cargar los pendientes que ya venimos trabajando de **Logística SINBA**, pero antes de registrar los que puedan estar desactualizados te los mostraré para confirmar cuáles siguen vigentes.
