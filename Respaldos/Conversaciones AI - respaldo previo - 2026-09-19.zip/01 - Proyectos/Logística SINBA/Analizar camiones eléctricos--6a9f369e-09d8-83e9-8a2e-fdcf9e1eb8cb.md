---
title: "Analizar camiones eléctricos"
conversation_id: "6a9f369e-09d8-83e9-8a2e-fdcf9e1eb8cb"
type: "chatgpt"
project_id: "g-p-6a020623cb188191a191cc56b72a75d2"
area: "01 - Proyectos/Logística SINBA"
updated_at: 1788819389.106
archived: false
export_complete: true
tags: [conversacion-ai, jarvis-import]
---

# Analizar camiones eléctricos

- ID: `6a9f369e-09d8-83e9-8a2e-fdcf9e1eb8cb`
- Tipo: `chatgpt`
- Proyecto: `g-p-6a020623cb188191a191cc56b72a75d2`
- Estado: `activa`

## Conversación

### Marlon

[@Google Drive](plugin://google-drive@openai-curated-remote)  conecta a mi drive y busca un archivo comparti que dice camiones N1 y dentro de esa carpeta hay un carpeta electrico revisala y dale un analisis

### Asistente

Sí. Ya entré a tu Google Drive, encontré la carpeta compartida **“Camiones N1”** y dentro la carpeta **“Electricos”**. Revisé las fichas técnicas, la promoción de Voltera de septiembre 2026, las capturas de WhatsApp y las fotos que están allí. Hay una conclusión importante desde el inicio: **de los tres Farizon que aparecen con ficha técnica, solo el F3E entra realmente como N1**.

En Perú, un N1 es un vehículo de carga con **peso bruto vehicular de hasta 3.5 toneladas**. El MTC mantiene esa clasificación. citeturn354443search0turn354443search12

### Comparación que te interesa para Sinba

| Modelo | PBV | Categoría | Carga útil declarada | Autonomía real | Batería | Carga rápida | Lectura para Sinba |
|---|---:|---|---:|---:|---:|---|---|
| **Farizon F3E MY2027** | **3,495 kg** | **N1** | **1,845 kg** antes de carrozar | **200 km** | 55.64 kWh CATL LFP | 20–80% en 20 min @110 kW | ⭐ **El que más me interesa** |
| **Farizon F5E** | 4,495 kg | N2 | **2,715 kg** | 180 km | 62 kWh LFP | GB/T DC + 6.6 kW AC | Muy interesante, pero ya no es N1 |
| **Farizon T9E MY2027** | 7,500 kg | N2 | **3,975 kg** | **200 km real** | 120.27 kWh CATL LFP | 20–80% en 18 min @240 kW | Excelente para volumen/peso, pero es otra categoría |

El **F3E 2027** mide 5.80 m de largo y 1.835 m de ancho, tiene 55 kW nominales/110 kW máximos, batería CATL de fosfato de hierro-litio, frenado regenerativo de tres niveles y varias ayudas de seguridad: ESC, aviso de cambio de carril, aviso de colisión frontal, TPMS, cámara de retroceso y control crucero adaptativo. fileciteturn7file0

El **F5E** sube muchísimo la capacidad: 2,715 kg de carga útil y 62 kWh, pero su PBV es 4,495 kg. Por eso, aunque está metido dentro de la carpeta “Camiones N1”, **técnicamente ya cae en N2**. Tiene 180 km de autonomía real declarada y la ficha indica garantía de batería de 8 años/150,000 km y del vehículo de 5 años/100,000 km. fileciteturn6file0

Y el **T9E** ya es un camión bastante serio: 3,975 kg de carga útil, furgón interior de aproximadamente **4.185 × 2.10 × 2.10 m**, tres ocupantes, batería CATL de 120.27 kWh y 200 km reales. Su precio de lista es USD 50,990 y la cotización indica **USD 48,990 por unidad para flota de más de tres unidades**, con 45% de adelanto y 55% a la llegada. El plazo indicado es 90–120 días hasta Callao, más el proceso posterior de placas. fileciteturn5file0

## El F3E es el que yo pondría primero sobre la mesa

Para tu operación de Lima, me parece mucho más estratégico empezar estudiando a fondo el **F3E**.

¿Por qué? Porque mantiene un PBV de **3,495 kg**, apenas por debajo del límite N1. Eso te permite conseguir un camión de carga bastante más capaz sin saltar de categoría. Además, con 1.835 m de ancho es significativamente más manejable para accesos urbanos que el T9E de 2.20 m de ancho. fileciteturn7file0

La autonomía declarada de 200 km también cambia bastante el panorama que venías teniendo con eléctricos. En tu documentación anterior habías registrado limitaciones alrededor de los **90 km reales**, justamente como uno de los problemas de la flota eléctrica actual. fileciteturn0file7

Así que, sobre el papel, pasar de ~90 km a alrededor de 200 km es un salto operativo enorme.

Pero hay una trampa importante: los **1,845 kg del F3E corresponden al chasis cabina**. Una vez que le agreguen furgón, estructura, eventualmente plataforma hidráulica, herramientas, conductor y acompañante, la capacidad disponible para residuos será menor.

Por eso **no compraría todavía usando la cifra 1,845 kg como “carga útil Sinba”**.

Quiero que Voltera nos dé el peso vacío definitivo de:

**F3E + furgón + plataforma hidráulica + conductor/acompañante.**

Esa es la cifra que realmente necesitamos.

## Los precios tienen oportunidades interesantes

La presentación promocional tiene varias unidades. El F3E antiguo MY2022 aparece en liquidación a **USD 18,990 chasis cabina y USD 20,500 con furgón**, con cargador portátil de 7 kW, 11 m³ y una referencia de S/47 por 240 km. También aparece un F3E nuevo 2026 de aproximadamente 2 toneladas, promoción **USD 25,990**, autonomía de 180–200 km y batería de 53.5 kWh. fileciteturn4file0

Aquí yo separaría totalmente dos decisiones.

El **F3E antiguo 2022 a USD 20,500** es tentador por precio, pero no lo compraría sin un diagnóstico de batería. Puede ser una oportunidad espectacular o una falsa economía dependiendo del tiempo que la batería haya permanecido almacenada, fecha efectiva de inicio de garantía y estado de salud de la batería.

El **F3E nuevo 2026/2027** cuesta más, pero el nuevo MY2027 trae CATL, carga rápida de 110 kW y un paquete de seguridad bastante superior. fileciteturn7file0

### Hay además una inconsistencia que debemos hacer corregir

La presentación general dice **garantía de unidad de 3 años/100,000 km y batería de 8 años/150,000 km**, mientras la ficha del F5E habla de **5 años/100,000 km para el vehículo** y 8 años/150,000 km para batería. fileciteturn4file0 fileciteturn6file0

Eso significa que la garantía tiene que quedar escrita **por modelo específico en la cotización que Sinba firme**, no basarnos en la presentación comercial.

## Y aquí está el tema más interesante: los cargadores

Las capturas de WhatsApp que dejaste en la carpeta son muy importantes.

El proveedor te indica que existe cargador de **40 kW** y también uno de **60 kW**, y para el camión de 4 toneladas recomienda el de 60 kW. Te cotiza ese cargador en aproximadamente **USD 12,000 + IGV, sin instalación**. Además, dice que el modelo de 60 kW tiene **dos mangueras** y puede conectar dos camiones simultáneamente. fileciteturn8file0 fileciteturn9file0

La foto adicional efectivamente muestra estaciones DC instaladas, por lo que al menos existe evidencia visual de instalaciones operativas del tipo que están ofreciendo. fileciteturn10file0

Pero aquí quiero hacerte una observación técnica importante.

El T9E acepta hasta **240 kW** y su batería es de 120.27 kWh. fileciteturn5file0

Con 60 kW, cargar del 20% al 80% supone aproximadamente 72 kWh. En condiciones ideales estamos hablando de alrededor de **1 hora y 12 minutos**, no 18 minutos. Para lograr los 18 minutos que publicita la ficha necesitarías acercarte a la potencia de carga DC máxima que declara el vehículo.

Y si ese cargador de 60 kW conecta dos vehículos simultáneamente, tenemos que preguntarle al proveedor algo muy específico:

> **¿Son 60 kW por conector o 60 kW totales repartidos entre los dos conectores?**

Porque si son 30 + 30 kW cuando cargas dos camiones, el tiempo aproximadamente se duplica.

Eso puede cambiar por completo tu planificación de 16 horas de utilización diaria.

## Algo que me gusta bastante del F3E para tu esquema

Con una batería de 55.64 kWh, el F3E no necesariamente necesita que Sinba compre inmediatamente un cargador DC de USD 12,000.

Un cargador AC de 7 kW podría recuperar aproximadamente el 60% de su batería en unas **4 horas 45 minutos ideales**. Una carga completa desde vacío estaría alrededor de ocho horas, antes de pérdidas. La presentación comercial cotiza ese cargador AC adicional de 7 kW en **USD 1,750**, sin instalación. fileciteturn4file0

Eso abre una estrategia mucho más inteligente:

**primero F3E + carga nocturna AC**, medir la operación real y después decidir si Sinba necesita una estación DC de 40/60 kW.

No compraría un cargador DC de USD 12,000 desde el día uno salvo que vayamos directamente al T9E o que realmente queramos trabajar el F3E en dos turnos largos diarios con recargas intermedias.

## Mi ranking para Sinba

1. **🥇 Farizon F3E 2027 — candidato principal.** Mantiene N1, buena maniobrabilidad, ~200 km, carga rápida y seguridad moderna. Ideal para atacar primero la operación urbana.
2. **🥈 Farizon F5E — candidato de capacidad.** Muy buena carga útil de 2.7 t, pero ya N2. Lo estudiaría si descubrimos que 1.5–1.8 t se queda pequeño para ciertas rutas.
3. **🥉 Farizon T9E — proyecto de inversión independiente.** Me gusta mucho para reemplazar rutas grandes/tercerizadas, pero no lo mezclaría con el proyecto N1. Es un camión N2 de 7.5 t que necesita otro análisis de calles, permisos, carga eléctrica e infraestructura.
4. **F3E 2022 liquidación — oportunidad financiera, con condición.** Solo avanzaría si Voltera entrega un reporte formal de SOH de batería, ciclos, antigüedad, fecha de garantía y respaldo de repuestos.

Antes de llevar esto a Pedro/Piero/Chara, yo exigiría al proveedor una sola ronda de información: **peso real con furgón y plataforma; categoría que aparecerá en tarjeta de propiedad; SOH de unidades 2022; costo de batería de reemplazo; mantenimiento a 5 años; garantía específica de cada modelo; precio instalado del cargador 7/40/60 kW; potencia eléctrica necesaria en VES; reparto de potencia del cargador de dos mangueras; disponibilidad de repuestos; y una prueba del F3E cargado al 80% de su capacidad haciendo una ruta real de Sinba.**

Y hay una última cosa que me parece especialmente importante: **yo no llamaría a esta carpeta simplemente “Camiones N1” tal como está ahora**, porque el F5E y el T9E no pertenecen a esa categoría. Separaría el estudio en **N1 – F3E** y **N2 – F5E/T9E**. Eso evita que después Comercial o Finanzas compare vehículos que, operativamente, juegan en ligas distintas.

Mi conclusión por ahora es bastante clara: **si Sinba quiere reemplazar/mejorar el eléctrico actual sin complicar demasiado la operación, el F3E 2027 es el vehículo que merece un caso de negocio completo.** Si el objetivo es internalizar rutas hoy tercerizadas y mover 3–4 toneladas, entonces el proyecto correcto ya no es N1: **es T9E + infraestructura DC**, y ahí sí tenemos que calcular TCO, ahorro contra Cubas, costo/km, depreciación, electricidad e inversión en cargador como un proyecto separado.
