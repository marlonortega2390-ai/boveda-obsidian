---
title: "Conectar ChatGPT con Blender"
conversation_id: "6aa0376b-0560-83e9-b0e6-c6469c288e17"
type: "chatgpt"
project_id: "g-p-6a020623cb188191a191cc56b72a75d2"
area: "01 - Proyectos/Logística SINBA"
updated_at: 1788884889.572
archived: false
export_complete: true
tags: [conversacion-ai, jarvis-import]
---

# Conectar ChatGPT con Blender

- ID: `6aa0376b-0560-83e9-b0e6-c6469c288e17`
- Tipo: `chatgpt`
- Proyecto: `g-p-6a020623cb188191a191cc56b72a75d2`
- Estado: `activa`

## Conversación

### Marlon

Pregunta cómo conecto chat gpt astra con blender ?

### Asistente

Sí, pero hay una diferencia importante: **hoy no existe una conexión oficial directa “ChatGPT Astra → Blender”** que simplemente actives y ChatGPT empiece a mover objetos dentro de Blender. Revisé la documentación actual de OpenAI y Blender no aparece entre las aplicaciones compatibles directamente con “Trabajar con apps”. citeturn0search0

Lo que **sí podemos hacer**, y encaja muchísimo con lo que venías aprendiendo con Eduardo sobre APIs, MCP y agentes fileciteturn0file12, es construir un puente:

**Tú → ChatGPT → MCP/API → Python → Blender**

Por ejemplo, tú podrías decir:

> “Crea un almacén logístico de 20 × 30 metros, coloca racks, zona de carga y tres camiones.”

ChatGPT interpreta la instrucción → genera/ejecuta las acciones necesarias → un servidor o complemento las pasa a Blender → Blender crea objetos, cambia materiales, cámaras, iluminación, etc.

### Para tu caso, yo lo haría así

No empezaría intentando conectar “Astra” directamente.

Empezaría con:

**ChatGPT + VS Code + Python + Blender**

y después agregaría **MCP** para que la comunicación sea mucho más natural.

Esto además aprovecha exactamente lo que ya estabas estudiando: en tu reunión hablaron de instalar Python en VS Code, entender APIs y posteriormente estudiar MCP; incluso hablaron específicamente de Blender. fileciteturn0file12

El resultado que buscaríamos sería algo parecido a:

```text
MARLON
   ↓
"Créame el Nodo VES en 3D"
   ↓
CHATGPT
   ↓
MCP / herramienta
   ↓
PYTHON
   ↓
BLENDER
   ↓
🏭 Modelo 3D
```

Y después podríamos llevarlo bastante más lejos: darle las medidas reales del CIRC/Nodo VES, vehículos, zonas de estacionamiento, racks, rutas internas, puntos de carga, etc., y usar Blender para **simular visualmente cambios de layout antes de implementarlos físicamente**.

Además, OpenAI actualmente está llevando las integraciones hacia su sistema de **plugins/apps**, por lo que el concepto de conectar ChatGPT con herramientas externas sí forma parte de la arquitectura actual; simplemente **Blender no figura como integración oficial directa** en la documentación que revisé. citeturn0search4turn0search0

[Documentación oficial de OpenAI sobre trabajar con aplicaciones](https://help.openai.com/es-419/articles/10119604-work-with-apps-on-macos?utm_source=chatgpt.com)

Si quieres hacerlo, puedo enseñarte **desde cero y paso por paso**, tipo *“abre Blender → entra aquí → pega esto → ahora abre VS Code…”*, hasta conseguir que escribas en ChatGPT **“crea una mesa”** y aparezca la mesa en Blender. Esa sería nuestra primera prueba antes de pasar al Nodo VES.
