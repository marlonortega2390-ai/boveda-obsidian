---
title: "Guardar guía Sinba"
conversation_id: "6a9597f3-58b0-83e9-a96f-0a36b418900b"
type: "chatgpt"
project_id: "g-p-6a020623cb188191a191cc56b72a75d2"
area: "01 - Proyectos/Logística SINBA"
updated_at: 1788190471.58
archived: false
export_complete: true
tags: [conversacion-ai, jarvis-import]
---

# Guardar guía Sinba

- ID: `6a9597f3-58b0-83e9-a96f-0a36b418900b`
- Tipo: `chatgpt`
- Proyecto: `g-p-6a020623cb188191a191cc56b72a75d2`
- Estado: `activa`

## Conversación

### Marlon

Hola! Como diseñador senior experto en la marca **Sinba**, entiendo perfectamente la consigna: trabajaremos al nivel de **bocetos estructurados**, priorizando la intención, composición, pesos visuales y alineación conceptual según las pautas del manual de marca. &#x20;

Para poder darte las propuestas de bocetos más estratégicas e impactantes, **necesito que primero me compartas los detalles de tu requerimiento**. &#x20;

**📋 Información requerida antes de bocetear:**

1. **Objetivo de la pieza:** (Ej. Promocionar un servicio para hogares, captar empresas, educación ambiental, branding puro).
2. **Público objetivo:** (Ej. Personas/Vecinos, Empresas B2B, Comunidad en general).
3. **Canal de difusión:** (Ej. Instagram, LinkedIn, impreso/afiche, cartel exterior).
4. **Formato:** (Ej. Post 1:1, Carrusel, Story 9:16, Flyer A5).
5. **Texto base:** (Si ya tienes un borrador de copy o idea central). &#x20;
6. **CTA (Llamado a la acción):** (Ej. "Inscríbete", "Visita sinba.pe", "Contrata el plan").
7. **Referencias:** (Imágenes o ejemplos si los tienes). &#x20;

### 🎨 Mis instrucciones y directrices internas (Manual de Marca Sinba)

Una vez que me entregues la información, estructuraré las propuestas de bocetos aplicando rigurosamente los siguientes pilares de la marca: &#x20;

- **Propósito y Tono de Voz:** Mensajes con orden de prioridad: 1. Propósito, 2. Servicio, 3. Comunidad. Tono cercano, optimista, educador, consciente y movilizador.
- **Tono de Diseño:** Estilo **Simple + Festivo + Ingenioso**. Sin saturación de texto y con máxima claridad. &#x20;
- **Paleta de Colores (Jerarquía):**
  - **Principales (80%):** Lila (`#EBE9FC`) y Morado (`#5A1A9B`).
  - **Acentos (20%):** Verde (`#419847`), Naranja (`#F2AC2C`), Rojo (`#E05841`) y Amarillo (`#F5DB22`).
- **Tipografías e Intención:**
  - **Titulares:** Peso *XXNarrow Black* o ultra-condensado en MAYÚSCULAS.
  - **Cuerpo/Soporte:** Fuente geométrica/sans-serif legible (*Azo Sans* estilo Regular/Medium/Bold).
- **Recurso Visual Clave (Tachado y Cintas):**
  - Uso de cintas rectas (ángulos de -20° a 25°, 180°, etc.) con 85% de opacidad.
  - Aplicado para tachar la palabra "BASURA" o conceptos negativos.
- **Mascota ("Manito Sinba"):** Naranja exclusivo, utilizada como elemento dinámico/cercano para tips, anotaciones o apoyo (nunca como el foco principal absoluto).

**Quedo a la espera de los datos de tu pieza para presentarte las opciones de bocetos.** ¡Construyamos juntos un mundo sin basura Estas son instrucciones que me dieron de una gente de Gemini, ¿no? Entonces igualmente guárdala. Es bueno que lo tengamos para cualquier presentación. Justamente ahorita viene la presentación de líderes, entonces es bueno que tengamos esta información para que me ayude con la presentación, ¿no?

### Asistente

Sí, lo guardé como **guía de referencia de marca Sinba** para que la usemos en adelante cuando preparemos presentaciones, láminas, infografías o piezas internas.

Y para la **presentación de líderes** nos sirve bastante: no quiero que terminemos haciendo un PowerPoint corporativo genérico lleno de texto. La idea será que cada lámina tenga una sola idea fuerte, titulares grandes, bastante aire, predominio lila/morado y los colores secundarios únicamente para resaltar información, alertas, avances o resultados.

También tomaré como regla la jerarquía que te dieron: **Propósito → Servicio → Comunidad**. Así, incluso cuando presentemos algo muy operativo —rutas, costos, capacidad, personas, mejoras— intentaremos conectarlo con el impacto: qué problema resolvemos, qué estamos haciendo y qué mejora produce.

Y hay algo especialmente útil para ti: el estilo **“Simple + Festivo + Ingenioso”** encaja bien para contar logística sin volverla pesada. Podemos convertir números, problemas y decisiones en gráficos sencillos, semáforos, comparaciones visuales y frases cortas en lugar de tablas gigantes.

Cuando empecemos la presentación de líderes, trabajaré esta guía como nuestro **“Manual Sinba de bolsillo”**. No necesitarás volver a copiarme todo esto.

### Marlon

Aquí tienes la estructura y resumen ejecutivo del \*\*Brandbook de Sinba (Edición 2023)\*\*:

\---

\# 📘 RESUMEN DEL BRANDBOOK DE SINBA

\### 1. Esencia, Propósito y Tono

\* \*\*Propósito Central:\*\* \*Cocrear un mundo sin basura, donde nada sobra y nadie sobra.\*

\* \*\*¿Qué es Sinba?:\*\* Empresa social, ONG y comunidad.


\* \*\*Orden de Prioridad en Mensajes:\*\* 1. Propósito $\rightarrow$ 2. Servicio $\rightarrow$ 3. Comunidad.


\* \*\*Tono de Voz:\*\* Cercano, optimista, educador, consciente y movilizador.


\* \*\*Tono de Diseño:\*\* \*\*SIMPLE + FESTIVA + INGENIOSA\*\*.



\---

\### 2. Paleta de Color y Proporciones

\* \*\*Lila (\`#EBE9FC\`) – 40%:\*\* Color de fondo/base.


\* \*\*Morado (\`#5A1A9B\`) – 40%:\*\* Color principal para textos/estructura.


\* \*\*Colores de Acento (5% c/u):\*\* Verde (\`#419847\`), Rojo (\`#E05841\`), Naranja (\`#F2AC2C\`), Amarillo (\`#F5DB22\`).



\---

\### 3. Tipografía e Intención

\* \*\*Titulares (Principal):\*\* \*Owners XXNarrow Black\* (Siempre en \*\*MAYÚSCULAS\*\*, ultra-condensada, pesada).


\* \*\*Cuerpo / Soporte (Secundaria):\*\* \*Azo Sans\* (Regular, Medium, Bold).



\---

\### 4. Recursos Visuales Clave

\* \*\*Cintas y Tachado:\*\* Elemento gráfico con 85% de opacidad para tachar la palabra "BASURA" o conceptos negativos. Usa ángulos rectos o inclinaciones de -20°, 20°, 25°, 180°, etc.


\* \*\*Mascota ("Manito Sinba"):\*\* Exclusivamente en color Naranja. Aporta dinamismo, calidez y se usa para tips o anotaciones (nunca como protagonista absoluto).



\---

\---

\# 🎨 PROPUESTA DE BOCETO (EJEMPLO ESTRUCTURAL)

A continuación, presento un \*\*boceto esquemático\*\* que simula cómo se compone una pieza gráfica de Sinba priorizando intención visual, jerarquías y pesos, utilizando tipografías estándar para el wireframe.

\---

\### 📌 Información General de la Pieza (Ejemplo)

\* \*\*Objetivo:\*\* Promocionar el plan de reciclaje para hogares.


\* \*\*Canal / Formato:\*\* Instagram / Post Cuadrado (1:1).


\* \*\*Público Objetivo:\*\* Vecinos y familias interesadas en la sostenibilidad.



\---

\### 📐 Estructura del Boceto Visual (Wireframe)

\`\`\`text
+-----------------------------------------------------------------------+
\|  [Fondo: Lila #EBE9FC]                                                |
\|                                                                       |
\|  (Arriba Izquierda)                                                   |
\|  [LOGO: sinba] (Versión Morado en Positivo)[cite: 1]                          |
\|                                                                       |
\|  -------------------------------------------------------------------  |
\|                                                                       |
\|  (Zona Central / Titular Principal - Peso Ultra Condensado / Altas)  |
\|                                                                       |
\|    TODOS JUNTOS PODEMOS VIVIR                                         |
\|    SIN [ BASURA ]   <--- [Cinta Verde #419847 en Opacidad 85%]        |
\|                                (Tachando la palabra "BASURA")[cite: 1]        |
\|                                                                       |
\|  -------------------------------------------------------------------  |
\|                                                                       |
\|  (Bajada / Texto Secundario - Tipografía Geométrica Sans-Serif)[cite: 1]      |
\|                                                                       |
\|    Nos llevamos los residuos de tu hogar para que tú                 |
\|    y tus vecinos vivan en un entorno más limpio.[cite: 1]                   |
\|                                                                       |
\|  -------------------------------------------------------------------  |
\|                                                                       |
\|  (Elemento de Apoyo Visual)                                           |
\|                                                                       |
\|    [ 🤚 Manito Sinba en Naranja #F2AC2C ]                             |
\|    Sosteniendo un globo de texto corto: "¡Súmate al cambio!"[cite: 1]     |
\|                                                                       |
\|  -------------------------------------------------------------------  |
\|                                                                       |
\|  (Zona Inferior / Botón CTA)                                          |
\|                                                                       |
\|    [ BOTÓN: Morado #5A1A9B con Texto Blanco ]                         |
\|    >>> CONTRATA TU PLAN EN SINBA.PE <<<[cite: 1]                            |
\|                                                                       |
+-----------------------------------------------------------------------+

\`\`\`

\---

\### 🧠 Criterio de Diseño y Justificación (Brandbook)

1\. \*\*Uso del Tachado (Cinta Verde):\*\* Se aplica la cinta sobre la palabra "BASURA" para reforzar visualmente el propósito de eliminación de desperdicios. Se usa verde como acento positivo.


2\. \*\*Jerarquía Tipográfica:\*\* Se mantiene un titular de peso alto (\*Block/Condensado\*) en mayúsculas completas para generar impacto, combinado con un cuerpo de texto sans-serif súper legible.


3\. \*\*Rol del Personaje:\*\* La "Manito Sinba" aparece únicamente en naranja en la esquina inferior para aportar cercanía sin restarle protagonismo al titular principal.


4\. \*\*Equilibrio de Color:\*\* Predomina el Lila (80% del área de fondo) con detalles en Morado y un toque de Verde/Naranja (20%).



\---

Si deseas que trabaje en un requerimiento específico, solo compárteme los detalles de tu pieza (objetivo, texto base, formato y canal) y te generaré las propuestas de boceto correspondientes.

### Asistente

Perfecto. Ya actualicé la referencia que teníamos con esta versión más precisa del **Brandbook Sinba 2023**.

Hay una corrección importante frente a lo anterior: ya no tomaré “80% lila” de forma literal. La proporción correcta será **40% lila + 40% morado + 20% repartido entre los cuatro acentos**. Eso nos va a ayudar bastante a que las presentaciones se vean realmente Sinba y no solo “moradas”.

También voy a conservar este wireframe como referencia de composición. Para la presentación de líderes, cuando la armemos, voy a pensar cada diapositiva así: **una idea principal fuerte, titular grande en mayúsculas, muy poco texto, jerarquía clara y recursos visuales con intención**. Si mostramos un problema, incluso podemos usar el recurso de cinta/tachado; si mostramos una alerta, aprendizaje o comentario, podemos recurrir a Manito sin que se robe la lámina.

Y algo clave: esto ya lo trataré como nuestro **criterio oficial de diseño Sinba 2023** para las próximas piezas, salvo que aparezca un manual más reciente que lo reemplace.
