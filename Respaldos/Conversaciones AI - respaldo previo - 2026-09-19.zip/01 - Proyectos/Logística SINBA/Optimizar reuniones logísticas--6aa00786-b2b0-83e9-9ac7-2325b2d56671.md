---
title: "Optimizar reuniones logísticas"
conversation_id: "6aa00786-b2b0-83e9-9ac7-2325b2d56671"
type: "chatgpt"
project_id: "g-p-6a020623cb188191a191cc56b72a75d2"
area: "01 - Proyectos/Logística SINBA"
updated_at: 1788872706.62
archived: false
export_complete: true
tags: [conversacion-ai, jarvis-import]
---

# Optimizar reuniones logísticas

- ID: `6aa00786-b2b0-83e9-9ac7-2325b2d56671`
- Tipo: `chatgpt`
- Proyecto: `g-p-6a020623cb188191a191cc56b72a75d2`
- Estado: `activa`

## Conversación

### Marlon

Verás que aquí debatíamos con Lili, con los chicos en el área de logística, que cuántas reuniones deberíamos tener, porque sentíamos como que el tiempo no nos alcanzaba para hacer nuestras tareas, innovar. Ya conoces todo el contexto operativo también, ¿no? llevar el personal, y sentimos como que ya es medio agotador, ¿no? Entonces, ¿cuántas reuniones debería tener un área por lo menos de logística, no? O por lo menos un área, ¿cuántas debería tener? ¿O es por persona? ¿O quizá sí soy ignorante en algo de pronto? Enséñame. O cómo podrías yo dar el contexto también para mencionárselo al equipo, ¿no? Hoy en la reunión de operaciones, como que bueno, estamos bien, ¿no? pero estamos un poco cansados, ¿no? Sentimos que el tiempo sí se nos va muy rápido y juzgar eso, ¿no? también. Realmente hay reuniones, cuáles son las reuniones necesarias que debemos tener, aprovechar realmente el tiempo, si queremos innovar, hacer tantas cosas, etcétera. a veces sentimos que el tiempo va volando, la verdad.

### Asistente

Sí. Y la primera idea importante es esta: **no existe un número “correcto” de reuniones para un área**. El problema se debe medir principalmente **por persona y por horas-persona consumidas**, no simplemente por cantidad de reuniones.

Una misma área puede tener cinco rituales semanales y funcionar perfecto si cada persona solo participa en los dos que realmente necesita. En cambio, tres reuniones donde entran todos, duran una hora y repiten información pueden comerse una cantidad enorme de capacidad.

Y en Logística SINBA esto pesa especialmente. Por ejemplo, el rol de Guardián de Rutas ya incluye monitoreo en vivo, seguimiento de incidencias, comunicación con clientes y conductores, actualización de data, accesos, documentación, checklist y soporte operativo. fileciteturn0file5 Además, ustedes están intentando simultáneamente mejorar capacidad instalada, costos, vehículos, procesos e inversiones; es decir, no solamente “operar”, sino también **mejorar la operación**. fileciteturn0file7

### Entonces, ¿cómo lo mediría para ustedes?

Yo separaría algo que normalmente se mezcla:

| Necesidad | ¿Reunión? | Propuesta para Logística |
|---|---|---|
| Saber qué pasó / informar novedades | Casi siempre NO | Chat, tablero o resumen |
| Coordinar operación del día | Sí | 10–15 min |
| Resolver bloqueos/decidir | Sí | Solo involucrados |
| Revisar indicadores | Sí | 45 min semanal |
| Hablar de mejoras/innovación | Sí | 60 min quincenal |
| Desarrollo de una persona | Sí | 1:1 quincenal/mensual |
| Mostrar avances sin necesitar decisión | Generalmente NO | Documento/dashboard |
| Emergencia operativa | Sí | Los necesarios |

Ahí está una clave importante: **una reunión no debería existir porque “toca reunirse”. Debería existir porque hay algo que decidir, coordinar, resolver o crear.**

Para su equipo yo diseñaría algo bastante simple.

### El sistema de reuniones que pondría en Logística

**Daily operativo — 10 a 15 minutos.** Solo: personal disponible, vehículos, rutas críticas, incidencias importantes y bloqueos. Nada de entrar a discutir un problema durante veinte minutos. Si aparece algo complejo: “Marlon + Lili lo vemos aparte”.

**Reunión semanal de Logística — 45 minutos.** Aquí fusionaría varias cosas que hoy pueden estar dispersas: scorecard + operación + prioridades. Cinco o seis indicadores, problemas importantes, decisiones y responsables. No convertirla en una lectura del Excel.

**Logística–Experiencia / áreas relacionadas — 30 minutos semanal.** Especialmente mientras siguen ordenando las fronteras entre quién solicita, quién programa y quién ejecuta. Una vez que el proceso esté estable podría pasar a quincenal.

**Mejora e innovación — 60 minutos cada dos semanas.** Esta para mí es importantísima en su caso. Aquí NO se revisan rutas del día, faltas, horarios ni “el camión tuvo esto”. Se trabaja una sola pregunta: reducir tercerización, automatizar reportes, mejorar SinbaRoute, capacidad de vehículos, mantenimiento, costos/km, optimización de rutas, etc.

**1:1 — 25 a 30 minutos cada dos semanas o mensual.** No necesariamente necesitas un 1:1 semanal con todo el mundo. Con personas clave o que lideran procesos, quincenal; con otros, mensual puede funcionar perfectamente.

Eso quiere decir que el equipo puede tener **cinco tipos de reunión**, pero ningún colaborador necesita estar en las cinco todo el tiempo. Esa diferencia es enorme.

De hecho, para una persona operativa yo empezaría a preocuparme cuando las reuniones recurrentes empiezan a ocupar **más o menos medio día laboral por semana o más**, salvo que su función sea justamente coordinación. Para ti, como líder, será normal tener algo más, pero también necesitas proteger tiempo para presupuesto, análisis, procedimientos, automatización y mejora continua.

Y aquí creo que está pasando algo que tú y Lili están sintiendo intuitivamente: **la operación está consumiendo el espacio de mejora.**

Cuando todo es reunión → WhatsApp → incidencia → reunión → reporte → coordinación, terminan trabajando *dentro* de la operación todo el día y casi nunca *sobre* la operación.

### Hay una regla que pueden empezar a aplicar desde hoy

Antes de aceptar una reunión deberían poder responder:

**¿Qué decisión o resultado debe existir cuando esta reunión termine?**

Si la respuesta es simplemente:

“Para informar.”  
“Para revisar.”  
“Para ponernos al día.”  
“Para ver cómo vamos.”

Probablemente puede resolverse sin reunión.

En cambio:

“Decidir qué vehículo compramos.”  
“Definir quién asume este proceso.”  
“Resolver el problema de capacidad de la ruta.”  
“Seleccionar las tres mejoras que ejecutaremos este mes.”

Eso sí justifica reunir gente.

También introduciría una pequeña disciplina: **si una reunión dura una hora y participan ocho personas, la empresa no gastó una hora; gastó ocho horas de trabajo.** Esa manera de verlo cambia muchísimo cómo uno invita gente.

### Y hay algo que yo propondría hoy en Operaciones

No iría a decir “tenemos demasiadas reuniones”. Puede sonar a que el equipo no quiere coordinar.

Yo lo plantearía como **capacidad operativa y capacidad de mejora**.

Podrías decir algo así:

> “Hay algo que hemos venido conversando con Lili y con el equipo de Logística. No es que estemos mal; de hecho, siento que operativamente hemos avanzado bastante. Pero sí estamos sintiendo que el tiempo se nos está comprimiendo mucho entre operación, reuniones, seguimiento, personal e incidencias.
>
> Y quiero que revisemos algo: no solamente necesitamos tiempo para ejecutar la operación. También necesitamos capacidad para mejorarla.
>
> Si queremos automatizar, analizar costos, optimizar rutas, mejorar vehículos, procedimientos y desarrollar proyectos, necesitamos proteger horas para pensar y construir esas mejoras.
>
> Por eso me gustaría que revisemos nuestras reuniones: cuáles realmente necesitan decisión o coordinación, cuáles podemos hacer más cortas, cuáles pueden convertirse en un seguimiento escrito y quién realmente necesita participar.
>
> No se trata de reunirnos menos por reunirnos menos. Se trata de que cada reunión tenga un resultado y que también tengamos tiempo para hacer el trabajo que sale de esas reuniones.”

Ese mensaje me parece bastante potente porque **no reclama; propone mejorar la productividad del sistema**.

Y yo añadiría una propuesta muy concreta para probar durante un mes:

**“Septiembre: experimento de reuniones.”**

Daily máximo 15 min.  
Semanal logística 45 min.  
Reuniones sin agenda → no se hacen.  
Solo personas necesarias.  
Problemas específicos → reunión aparte con 2–3 personas.  
Dos bloques semanales de 90 minutos sin reuniones para trabajo profundo/mejoras.  
Al final del mes revisar: horas de reunión, tareas cerradas e innovaciones avanzadas.

Eso sería muchísimo más interesante que simplemente preguntarle a Operaciones “¿podemos tener menos reuniones?”.

Porque incluso podrían descubrir algo curioso: quizá **no tienen demasiadas reuniones en cantidad**, sino demasiadas personas en cada reunión, demasiado tiempo por reunión o demasiados temas mezclados.

Y para mí esa es probablemente la conversación más madura: **no medir reuniones. Medir tiempo + decisiones + resultados.**

En el caso de su Logística, yo apuntaría a que el equipo pase la mayor parte de la semana **operando, analizando y mejorando**, y que las reuniones sean la infraestructura que habilita ese trabajo, no el trabajo mismo.
