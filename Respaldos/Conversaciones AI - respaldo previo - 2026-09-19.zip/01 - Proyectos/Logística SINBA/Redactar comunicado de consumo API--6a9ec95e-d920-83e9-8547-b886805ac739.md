---
title: "Redactar comunicado de consumo API"
conversation_id: "6a9ec95e-d920-83e9-8547-b886805ac739"
type: "chatgpt"
project_id: "g-p-6a020623cb188191a191cc56b72a75d2"
area: "01 - Proyectos/Logística SINBA"
updated_at: 1788791428.154
archived: false
export_complete: true
tags: [conversacion-ai, jarvis-import]
---

# Redactar comunicado de consumo API

- ID: `6a9ec95e-d920-83e9-8547-b886805ac739`
- Tipo: `chatgpt`
- Proyecto: `g-p-6a020623cb188191a191cc56b72a75d2`
- Estado: `activa`

## Conversación

### Marlon

Hola eq

Hola equipo,

Quería comentarles que detectamos un consumo mayor al esperado en Google Roads API durante agosto, el cual generó un monto de USD 124 al superar el consumo contemplado.

Al revisar el funcionamiento de SinbaRoute, identificamos que el apartado de Seguimiento volvía a procesar automáticamente el recorrido completo de un vehículo cada cinco minutos mientras permanecía seleccionado. Esto generaba solicitudes adicionales, especialmente cuando la pantalla quedaba abierta durante varias horas o era utilizada desde diferentes equipos.

Este comportamiento ya fue corregido. Actualmente, Roads API no se utiliza automáticamente al ingresar a Seguimiento ni al revisar una incidencia. La consulta solo se realiza cuando el usuario selecciona manualmente la opción de ajustar el recorrido a las calles. Además, el resultado queda almacenado para evitar solicitudes repetidas sobre un mismo recorrido.

También se implementó un registro interno que permitirá llevar un mejor control de la cantidad de consultas generadas por SinbaRoute.

Adicionalmente, realizaremos una auditoría de las APIs utilizadas por la plataforma y estableceremos un seguimiento semanal de su consumo. Esto nos permitirá:

- Identificar consumos innecesarios o fuera de lo esperado.
- Revisar semanalmente el uso y costo de las APIs.
- Dar aviso cuando el límite gratuito de una API esté próximo a agotarse o haya sido superado.
- Separar las credenciales utilizadas por cada proyecto para tener un mejor control del consumo.
- Configurar límites y alertas de presupuesto cuando sea posible.
- Tomar medidas preventivas antes de que se generen gastos adicionales.

SinbaRoute continúa funcionando con normalidad y las medidas implementadas están orientadas a mantener el consumo de las APIs bajo control y prevenir nuevos gastos inesperados.

Compartiremos los resultados de la auditoría y cualquier recomendación adicional que encontremos.

Saludos,
Patrick

ipo,

Quería comentarles que detectamos un consumo mayor al esperado en Google Roads API durante agosto, el cual generó un monto de USD 124 al superar el consumo contemplado.

Al revisar el funcionamiento de SinbaRoute, identificamos que el apartado de Seguimiento volvía a procesar automáticamente el recorrido completo de un vehículo cada cinco minutos mientras permanecía seleccionado. Esto generaba solicitudes adicionales, especialmente cuando la pantalla quedaba abierta durante varias horas o era utilizada desde diferentes equipos.

Este comportamiento ya fue corregido. Actualmente, Roads API no se utiliza automáticamente al ingresar a Seguimiento ni al revisar una incidencia. La consulta solo se realiza cuando el usuario selecciona manualmente la opción de ajustar el recorrido a las calles. Además, el resultado queda almacenado para evitar solicitudes repetidas sobre un mismo recorrido.

También se implementó un registro interno que permitirá llevar un mejor control de la cantidad de consultas generadas por SinbaRoute.

Adicionalmente, realizaremos una auditoría de las APIs utilizadas por la plataforma y estableceremos un seguimiento semanal de su consumo. Esto nos permitirá:

- Identificar consumos innecesarios o fuera de lo esperado.
- Revisar semanalmente el uso y costo de las APIs.
- Dar aviso cuando el límite gratuito de una API esté próximo a agotarse o haya sido superado.
- Separar las credenciales utilizadas por cada proyecto para tener un mejor control del consumo.
- Configurar límites y alertas de presupuesto cuando sea posible.
- Tomar medidas preventivas antes de que se generen gastos adicionales.

SinbaRoute continúa funcionando con normalidad y las medidas implementadas están orientadas a mantener el consumo de las APIs bajo control y prevenir nuevos gastos inesperados.

Compartiremos los resultados de la auditoría y cualquier recomendación adicional que encontremos.

&#x20;me ayudas a ver como puedo mejorar este correo la idea es yo como lider reconocer el error que no ha visto patrick y las soluciones que se dieron y asumir el gastode parte de mi area informando que se genero este gasto

### Asistente

Sí. Yo cambiaría el enfoque para que se note claramente que **tú, como líder, estás asumiendo la responsabilidad del proceso**, sin cargarle el error a Patrick. La frase clave no sería “Patrick no lo vio”, sino **“como área no identificamos oportunamente este comportamiento”**.

Además, separaría tres cosas: qué ocurrió, qué responsabilidad asumes y qué controles ya quedaron implementados.

Te lo dejaría así:

**Asunto: Consumo extraordinario de Google Roads API – SinbaRoute**

Hola equipo,

Quería informarles sobre un consumo mayor al esperado de **Google Roads API durante agosto**, que generó un costo extraordinario de aproximadamente **USD 124**.

Luego de revisar el funcionamiento de SinbaRoute junto con Patrick, identificamos que el módulo de **Seguimiento reprocesaba automáticamente el recorrido completo del vehículo cada cinco minutos mientras este permanecía seleccionado**. Si la pantalla quedaba abierta durante varias horas, o se utilizaba desde distintos equipos, esto generaba múltiples consultas adicionales a Roads API.

Como líder de Logística, **asumo la responsabilidad por no haber identificado oportunamente este riesgo y por no haber establecido desde el inicio un control más cercano sobre el consumo de las APIs utilizadas en las herramientas que estamos desarrollando desde el área**.

Patrick ya realizó la corrección técnica correspondiente. Actualmente:

- Roads API ya no se ejecuta automáticamente al ingresar a Seguimiento ni al revisar una incidencia.
- La consulta se realiza únicamente cuando el usuario selecciona manualmente la opción de **ajustar el recorrido a las calles**.
- El resultado queda almacenado para evitar procesar nuevamente un recorrido que ya fue consultado.
- Se incorporó un registro interno para controlar la cantidad de solicitudes generadas por SinbaRoute.

Adicionalmente, vamos a realizar una **auditoría de las APIs utilizadas por nuestras herramientas** y establecer un control semanal de consumo. Esto incluirá revisión de costos, alertas de presupuesto, separación de credenciales por proyecto y límites de uso cuando la plataforma lo permita.

Respecto al costo extraordinario generado en agosto, **propongo que los USD 124 sean asumidos dentro del presupuesto de Logística**, considerando que corresponde a una herramienta desarrollada y utilizada desde nuestra operación. Posteriormente coordinaremos la imputación correspondiente con Administración/Finanzas.

Lo importante es que el problema ya fue identificado y corregido, SinbaRoute continúa funcionando con normalidad y, a partir de este incidente, estamos incorporando controles para evitar que vuelva a generarse un consumo inesperado.

Compartiremos los resultados de la auditoría y cualquier otra mejora que identifiquemos.

Saludos,  
**Marlon**

Me gusta bastante más así porque **no escondes el error**, pero tampoco conviertes el correo en una confesión dramática. Transmites: *“ocurrió esto, como líder me corresponde asumirlo, ya entendimos la causa y ya pusimos controles”*.

También cambiaría específicamente **“asumiremos el gasto”** por **“propongo que sea asumido dentro del presupuesto de Logística”** hasta que Finanzas confirme cómo registrarlo. Así no te comprometes personalmente ni saltas un procedimiento interno.
