---
title: "Revisar carpeta eléctricos"
conversation_id: "6a9f34dc-6fe0-83e9-8afd-60299a72e762"
type: "chatgpt"
project_id: "g-p-6a020623cb188191a191cc56b72a75d2"
area: "01 - Proyectos/Logística SINBA"
updated_at: 1789056142.397
archived: false
export_complete: true
tags: [conversacion-ai, jarvis-import]
---

# Revisar carpeta eléctricos

- ID: `6a9f34dc-6fe0-83e9-8afd-60299a72e762`
- Tipo: `chatgpt`
- Proyecto: `g-p-6a020623cb188191a191cc56b72a75d2`
- Estado: `activa`

## Conversación

### Marlon

[@Google Drive](plugin://google-drive@openai-curated-remote) camiones n1 carpeta de electricos revisala por favor

### Asistente

Sí. Ya entré a tu Drive, encontré **Camiones N1 → Electricos** y revisé las fichas técnicas, la promoción de septiembre y las capturas que guardaste. fileciteturn1file0

Hay un hallazgo importante de entrada: **la carpeta no contiene solamente camiones N1**. En Perú, N1 llega hasta **3.5 t de peso bruto vehicular**; por encima de 3.5 t y hasta 12 t es N2. citeturn350976search12

| Modelo | PBV | Carga útil | Autonomía real declarada | Batería | Categoría |
|---|---:|---:|---:|---:|---|
| **Farizon F3E 2027** | 3,495 kg | **1,845 kg** | **200 km** | 55.64 kWh CATL | ✅ **N1** |
| **Farizon F5E** | 4,495 kg | **2,715 kg** | **180 km** | 62 kWh | ⚠️ **N2** |
| **Farizon T9E** | 7,500 kg | **3,975 kg** | **200 km** | 120.27 kWh CATL | ⚠️ **N2** |

El **F3E 2027** me parece especialmente interesante para la operación urbana de Sinba. Tiene 1.845 t de carga útil, 200 km de autonomía real declarada, batería CATL LFP, carga rápida GB/T y especifica **20–80 % en 20 minutos con cargador de 110 kW**. Además trae cámara y sensor de retroceso, control crucero adaptativo, ESC, aviso de cambio de carril, aviso de colisión y monitoreo de presión de neumáticos. fileciteturn7file0

Y aquí hay una ventaja estratégica: al quedarse en **3,495 kg PBV**, está prácticamente usando todo el límite de N1 sin saltar a N2. Para rutas urbanas, eso hace que yo lo vea como el candidato más equilibrado si buscamos reemplazar o complementar un eléctrico pequeño sin irnos todavía a un camión pesado.

El **F5E** ya cambia bastante la película. Tiene **2.715 t de carga útil**, 180 km de autonomía y batería de 62 kWh; mide aproximadamente **5.94 m de largo × 1.95 m de ancho × 2.07 m de alto**. Es muchísimo más capaz en carga, pero ya es N2. fileciteturn6file0

El **T9E** es otra liga: casi **4 toneladas de carga útil**, tres asientos, furgón de aproximadamente **4.185 × 2.10 × 2.10 m**, batería CATL de **120.27 kWh** y autonomía real declarada de 200 km. También especifica carga del 20–80 % en apenas 18 minutos, pero eso es usando **240 kW**, no un cargador pequeño. fileciteturn5file0

El precio de la cotización del T9E que guardaste es **USD 50,990 incluido IGV** como precio unitario, y **USD 48,990** para flotas de más de tres unidades. Pago 45 % con la orden y 55 % a la llegada; entrega estimada 90–120 días al Callao. Importante: la cotización dice que **viene con furgón pero no incluye cargador**. fileciteturn5file0

Y justo ahí aparece el tema más importante de toda esta evaluación: **infraestructura de carga**. En las capturas que guardaste, el proveedor te indica que para el camión de 4 t recomienda un cargador de **60 kW**, con precio aproximado de **USD 12,000 + IGV**, instalación aparte. También te comenta que el equipo de 60 kW tiene dos mangueras y podría atender dos camiones. fileciteturn8file0

Yo antes de comprar ese cargador preguntaría algo muy concreto:

**“Cuando conecto dos vehículos simultáneamente, ¿los 60 kW son 60 kW por conector o se reparten 30 + 30 kW?”**

Eso cambia completamente la operación. La ficha del T9E anuncia esos 18 minutos usando 240 kW; con 60 kW la carga necesariamente será bastante más lenta.

La presentación general de Voltera también tiene cosas interesantes. Declara garantía general de unidades de **3 años/100,000 km** y batería de **8 años/150,000 km** en la promoción; aparecen liquidaciones de modelos anteriores y nuevas versiones F3E/F5E/T9E. También usa S/0.75/kWh como referencia para calcular costos de recorrido. fileciteturn4file0

### Mi primera conclusión para Sinba

**1. F3E 2027 — mi favorito para estudiar primero.**  
Por carga, autonomía, categoría N1 y tecnología. Puede ser el punto medio que nos estaba faltando.

**2. F5E — el “caballo de batalla” intermedio.**  
Si 1.8 t se queda corto, subir a 2.7 t puede tener mucho sentido, pero ya debemos evaluarlo bajo operación N2.

**3. T9E — no lo descartaría, pero no lo compraría solo mirando autonomía.**  
Lo evaluaría para rutas de alto volumen, pallets, reciclables, empresas grandes y reducción de tercerización. Ahí su carga de casi 4 t puede justificar la inversión.

Y hay algo más: **las fotos que guardaste muestran flotas reales entregadas y equipos de carga DC instalados**, no solamente renders comerciales, lo cual me parece positivo como evidencia comercial, aunque obviamente eso no reemplaza validar servicio técnico, repuestos, mantenimiento y disponibilidad de cargadores. fileciteturn10file0 fileciteturn11file0

Para mí, el siguiente paso sería mucho más potente: **agarrar F3E vs F5E vs T9E vs nuestro eléctrico actual y hacer el caso financiero Sinba completo**: inversión, carga útil, autonomía, S/km, costo de energía, capacidad de contenedores, tercerización evitada, cargador necesario y recuperación de inversión. Ahí sí podemos saber cuál conviene comprar, no solamente cuál se ve mejor en la ficha.

### Marlon

por favor dame un resumen de toda la informacion solamente informativo por medio del correo y solo le voy a pasar que los camiones que salen en los pdf y que tu me redactes la informacion de los pantallazos de whatsp

### Asistente

Claro. Te lo dejaría como un **correo meramente informativo**, sin recomendar todavía qué unidad comprar ni hacer comparaciones. La idea sería compartir las alternativas encontradas en los PDF y complementar únicamente con la información que te enviaron por WhatsApp sobre los cargadores.

**Asunto: Información de alternativas de camiones eléctricos y sistema de carga**

Hola equipo,

Comparto de manera informativa algunas alternativas de camiones eléctricos revisadas en la documentación comercial de Voltera, junto con información adicional recibida por WhatsApp respecto a las opciones de carga.

Dentro de los modelos revisados se encuentran los siguientes:

- **Farizon F3E 2027:** camión eléctrico con peso bruto vehicular de 3,495 kg, carga útil aproximada de 1,845 kg, batería CATL de 55.64 kWh y autonomía estimada real de 200 km. Cuenta con opción de carga AC y carga rápida DC bajo estándar GB/T. fileciteturn7file0
- **Farizon F5E:** unidad eléctrica con peso bruto vehicular de 4,495 kg, carga útil aproximada de 2,715 kg, batería de 62 kWh y autonomía estimada real de aproximadamente 180 km. fileciteturn6file0
- **Farizon T9E Furgón:** unidad eléctrica de mayor capacidad, con peso bruto vehicular de 7,500 kg, carga útil aproximada de 3,975 kg, batería CATL de 120.27 kWh y autonomía estimada real de aproximadamente 200 km. El furgón tiene dimensiones aproximadas de 4.18 m de largo × 2.10 m de ancho × 2.10 m de alto. fileciteturn5file0

Respecto al **Farizon T9E**, la cotización revisada indica un precio de lista de **USD 50,990 incluido IGV**, mientras que para compras de más de tres unidades se menciona un precio de **USD 48,990 por unidad**. El plazo indicado para pedido directo es de aproximadamente 90 a 120 días hasta el puerto del Callao. La unidad viene con furgón, pero el cargador no está incluido. fileciteturn5file0

Adicionalmente, en la promoción general de septiembre se presentan diferentes alternativas de vehículos eléctricos de carga, así como soluciones de carga AC y DC. La información comercial señala también garantías para las unidades y baterías, dependiendo del modelo. fileciteturn4file0

Por otro lado, mediante WhatsApp el proveedor nos compartió información complementaria relacionada con la infraestructura de carga. Para el camión de aproximadamente **4 toneladas**, cuya batería es cercana a los **120 kWh**, recomienda considerar un cargador de **60 kW**.

Según lo informado:

- El cargador de **60 kW tendría un precio aproximado de USD 12,000 + IGV**.
- El precio indicado **no incluye instalación**.
- También existen alternativas de cargadores de **40 kW y 60 kW**.
- El modelo de 60 kW mostrado por el proveedor dispone de **dos mangueras/conectores**, permitiendo conectar hasta dos vehículos de manera simultánea, tanto unidades pequeñas como el camión de mayor capacidad.
- El proveedor también compartió fotografías referenciales de cargadores ya instalados y unidades eléctricas entregadas a otros clientes.

Por el momento comparto esta información únicamente como referencia para conocer las alternativas disponibles de vehículos eléctricos y los requerimientos asociados a su infraestructura de carga.

Saludos,  
**Marlon Ortega**  
Líder de Logística

### Marlon

Claro, aquí mencionar que no existen cargadores de potencia rápida que sean actualmente no, en Perú no existe ningún tipo de cargador que sea rápido y sea... no sea...portatil, todos se dben instalar

### Asistente

Perfecto. Esa precisión conviene ponerla porque cambia bastante cómo se entiende la infraestructura necesaria. La redactaría así dentro del correo:

> Adicionalmente, el proveedor indicó que actualmente **no se cuenta con cargadores rápidos portátiles disponibles en Perú para este tipo de unidad**. Los cargadores de mayor potencia, como los de 40 kW o 60 kW, requieren **instalación fija**, por lo que sería necesario considerar previamente las condiciones eléctricas del punto donde se instalaría el equipo, así como el costo de instalación correspondiente.

Y el bloque completo de cargadores podría quedar así:

- Para el camión de aproximadamente **4 toneladas**, cuya batería es cercana a los **120 kWh**, el proveedor recomienda considerar un cargador de **60 kW**.
- El cargador de **60 kW tendría un precio aproximado de USD 12,000 + IGV**.
- El precio indicado **no incluye instalación**.
- Existen alternativas de cargadores de **40 kW y 60 kW**.
- El modelo mostrado de 60 kW cuenta con **dos mangueras/conectores**, permitiendo conectar hasta dos vehículos.
- Según lo informado por el proveedor, actualmente **no existen cargadores rápidos portátiles disponibles en Perú para este tipo de camión**. Los equipos de carga rápida requieren **instalación fija**, por lo que también debe evaluarse la infraestructura eléctrica necesaria para su implementación.

Así queda más claro y más técnico, sin sonar a recomendación todavía.

### Marlon

arma el corre de nuevo

### Asistente

**Asunto: Información de alternativas de camiones eléctricos y sistemas de carga**

Hola equipo,

Comparto de manera informativa algunas alternativas de camiones eléctricos revisadas en la documentación comercial de Voltera, junto con información adicional recibida por WhatsApp respecto a las opciones de carga.

Dentro de los modelos revisados se encuentran los siguientes:

- **Farizon F3E 2027:** camión eléctrico con peso bruto vehicular de 3,495 kg, carga útil aproximada de 1,845 kg, batería CATL de 55.64 kWh y autonomía estimada real de aproximadamente 200 km. Cuenta con carga AC y carga rápida DC bajo estándar GB/T. fileciteturn7file0
- **Farizon F5E:** unidad eléctrica con peso bruto vehicular de 4,495 kg, carga útil aproximada de 2,715 kg, batería de 62 kWh y autonomía estimada real de aproximadamente 180 km. fileciteturn6file0
- **Farizon T9E Furgón:** unidad eléctrica de mayor capacidad, con peso bruto vehicular de 7,500 kg, carga útil aproximada de 3,975 kg, batería CATL de 120.27 kWh y autonomía estimada real de aproximadamente 200 km. El furgón tiene dimensiones aproximadas de 4.18 m de largo x 2.10 m de ancho x 2.10 m de alto. fileciteturn5file0

Respecto al **Farizon T9E**, la cotización revisada indica un precio de lista de **USD 50,990 incluido IGV** y un precio de **USD 48,990 por unidad para flotas de más de tres unidades**. El plazo indicado para pedido directo es de aproximadamente **90 a 120 días hasta el puerto del Callao**. La unidad viene con furgón, pero el cargador no está incluido. fileciteturn5file0

Adicionalmente, en la promoción general de septiembre se muestran distintas alternativas de vehículos eléctricos de carga y diferentes soluciones de carga AC y DC. fileciteturn4file0

Sobre la infraestructura de carga, el proveedor nos indicó por WhatsApp que para el camión de aproximadamente **4 toneladas**, cuya batería es cercana a los **120 kWh**, recomienda considerar un cargador de **60 kW**.

Según la información recibida:

- El cargador de **60 kW tendría un precio aproximado de USD 12,000 + IGV**.
- El precio indicado **no incluye la instalación**.
- También existen alternativas de cargadores de **40 kW y 60 kW**.
- El modelo mostrado de 60 kW cuenta con **dos mangueras o conectores**, con posibilidad de conectar hasta dos vehículos.
- El proveedor también compartió fotografías referenciales de cargadores instalados y unidades eléctricas entregadas a otros clientes.
- Asimismo, nos indicó que actualmente **no existen cargadores rápidos portátiles disponibles en Perú para este tipo de unidad**. Los cargadores de mayor potencia requieren **instalación fija**, por lo que sería necesario considerar previamente las condiciones eléctricas del punto de carga y el costo correspondiente de instalación.

Por el momento comparto esta información únicamente como referencia para conocer las alternativas disponibles de vehículos eléctricos y los requerimientos asociados a su sistema de carga.

Saludos,  
**Marlon Ortega**  
Líder de Logística
