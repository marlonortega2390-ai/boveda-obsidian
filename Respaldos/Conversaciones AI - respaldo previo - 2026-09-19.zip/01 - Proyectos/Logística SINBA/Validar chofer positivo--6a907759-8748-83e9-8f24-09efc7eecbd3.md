---
title: "Validar chofer positivo"
conversation_id: "6a907759-8748-83e9-8f24-09efc7eecbd3"
type: "chatgpt"
project_id: "g-p-6a020623cb188191a191cc56b72a75d2"
area: "01 - Proyectos/Logística SINBA"
updated_at: 1787853095.722
archived: false
export_complete: true
tags: [conversacion-ai, jarvis-import]
---

# Validar chofer positivo

- ID: `6a907759-8748-83e9-8f24-09efc7eecbd3`
- Tipo: `chatgpt`
- Proyecto: `g-p-6a020623cb188191a191cc56b72a75d2`
- Estado: `activa`

## Conversación

### Marlon

Me quiere hacer una pregunta lógica? A ver, me ha salido un chofer A2F. Entonces quiero validar si mi respuesta es identificable y qué otros aspectos puedes ver tú y si puedes verlo desde un panorama desde afuera, ¿no? Entonces ahorita voy a hacer la consulta de un chofer que ha pasado la prueba de manejo muy bien, de verdad. Ha ido al examen médico, pero ha dado positivo para marihuana. Obviamente ahorita supuestamente, Pedro el otro vez comentó que fumar marihuana es como algo normal, en teoría. Pero estamos aquí en Perú, sabemos que los accidentes de tránsito ocurren. Entonces yo no podría aceptar un chofer que tenga de positivo, porque yo no voy a estar cuidándolo. Maneja una unidad, es una herramienta, pero también es un arma. Pongo en riesgo muchas cosas al colocar al volante a alguien así. De resto creo que solamente quiero validar mi opinión contigo. Coméntame.

### Asistente

Sí, tu criterio tiene bastante sentido desde **gestión del riesgo**, pero yo haría una precisión importante para que tu posición sea sólida y no se convierta en “dio positivo = consume mientras maneja”.

Un resultado positivo a marihuana **no demuestra necesariamente que estaba bajo sus efectos en ese momento**. Dependiendo de la prueba, pueden detectarse metabolitos tiempo después del consumo. Por eso yo no juzgaría a la persona ni afirmaría que “maneja drogado”. Lo que sí tienes es un **hallazgo objetivo incompatible, por ahora, con un puesto crítico de conducción**, hasta que SST/Medicina Ocupacional determine su aptitud.

Y ahí cambia completamente la discusión.

Para un chofer profesional, el estándar de riesgo es mucho más alto que para alguien que trabaja sentado en una oficina. En documentación oficial peruana incluso existen perfiles ocupacionales específicos para **operadores/conductores/choferes** que incluyen examen toxicológico de marihuana y cocaína. citeturn795140search23 Además, la Ley 29783 obliga al empleador a identificar, evaluar y controlar los riesgos ocupacionales. citeturn795140search0turn795140search2

Por eso, desde afuera, yo separaría el caso así:

1. **Prueba de manejo:** excelente. Eso demuestra competencia técnica.
2. **Licencia/categoría:** puede cumplir perfectamente.
3. **Actitud y experiencia:** podrían ser buenas.
4. **Aptitud médica ocupacional:** aquí aparece la observación crítica.
5. **Riesgo del puesto:** conduce varias horas, transporta personal/carga, circula por Lima y tiene terceros alrededor.
6. **Consecuencia potencial del error:** alta. No es una función donde un error simplemente implique rehacer un Excel.

Incluso en documentos públicos de SST para conductores se establece expresamente que un conductor no debe conducir bajo los efectos de alcohol o drogas. citeturn795140search25

Y hay algo adicional que me parece especialmente importante para tu caso: **el propio contrato que Sinba tiene con Cubas ya maneja exactamente esa lógica preventiva**. Exige examen médico ocupacional para nuevos ingresos y establece que el personal no debe consumir sustancias estupefacientes antes o durante el servicio ni estar bajo sus efectos al prestar el servicio; si se constata, debe ser retirado y reemplazado inmediatamente. fileciteturn0file8

Entonces, donde coincido contigo es aquí: **yo tampoco lo habilitaría para conducir una unidad en estas condiciones.**

Pero cambiaría ligeramente tu frase de:

> “No puedo aceptar a un chofer que fuma marihuana.”

por algo profesionalmente mucho más defendible:

> “Para un puesto crítico de conducción no puedo aprobar el ingreso mientras exista un resultado toxicológico positivo y no tengamos una declaración de aptitud por Medicina Ocupacional.”

Eso evita entrar en si fumar marihuana es “normal”, aceptable socialmente, medicinal, ocasional, etc. **Esa discusión ni siquiera es necesaria.** Pedro puede pensar una cosa y otra persona otra. Tu responsabilidad operacional es otra: **¿puedo entregar las llaves de un vehículo de varias toneladas a esta persona con la evidencia que tengo hoy?**

Hoy, mi respuesta sería **no**.

También evitaría asumir tú solo la decisión médica. Lo correcto sería pedir a RR. HH./SST que confirme tres cosas: que el resultado sea efectivamente positivo y no preliminar, qué conclusión de **APTO / APTO CON RESTRICCIONES / NO APTO** emite Medicina Ocupacional, y cuál es el protocolo de Sinba para puestos críticos. Los exámenes ocupacionales precisamente terminan con una evaluación del estado de salud y aptitud del trabajador. citeturn795140search4turn795140search5

Y desde una mirada externa te diría algo más: **tu argumento más fuerte no es “el camión es un arma”.** Entiendo perfectamente lo que quieres decir, pero frente a RR. HH. o gerencia yo hablaría de “posición crítica de seguridad y alto potencial de consecuencia”. Suena menos emocional y es técnicamente mucho más fuerte.

De hecho, si mañana ese chofer tuviera un accidente grave y ya existía un examen preocupacional con este hallazgo, una de las primeras preguntas internas sería bastante incómoda: **“¿quién autorizó que condujera y con qué criterio?”**

Ahí entiendo completamente por qué no quieres asumir ese riesgo.

### Marlon

Mira, normalmente el consumo de marihuana puede ser normal, pero ¿sabes qué? El problema está en que el consumo por marihuana se puede disfrazar con gotas, menta, pastillas de menta y fácilmente podríamos saber si podríamos no tener conocimiento si alguien está fumando o no está fumando o consumiendo, ¿no? Entonces el tema está en que dio positivo y si el chofer salió con ese tema, entonces creería que debería ser negativo para seguir buscando otro candidato.

### Asistente

Sí, con ese enfoque tu decisión queda más clara: **no seguiría con ese candidato para un puesto de chofer**.

Solo corregiría una parte de tu razonamiento: yo no basaría la decisión en que “puede disfrazar el consumo con menta, gotas o pastillas”, porque eso te lleva a intentar detectar si consumió recientemente y puede generar discusiones difíciles de probar. El punto más fuerte es mucho más simple: **para un puesto crítico de conducción, el examen preocupacional arrojó un resultado positivo y eso representa un riesgo que no necesitas asumir si estás todavía en etapa de selección.**

Además, siendo candidato y no trabajador ya incorporado, operacionalmente tienes una alternativa sencilla: continuar con otro postulante que cumpla tanto la prueba de manejo como los requisitos médicos establecidos.

Yo lo plantearía internamente así: **“Manejó muy bien y técnicamente cumple, pero por el resultado positivo en el examen toxicológico considero que no deberíamos continuar con su ingreso como conductor. Por la naturaleza del puesto necesitamos minimizar riesgos y contar con un candidato que cumpla también con los criterios médicos y de seguridad.”**

Eso me parece mucho más sólido que entrar a discutir si la marihuana es “normal” o no. La discusión no es moral; es de **seguridad operacional y criterio de selección**.

### Marlon

Pero dame un panorama más amplio. Para consumo de marihuana, cómo se detecta? Se detecta obviamente por la orina. Pero, ¿se puede detectar de aquí a dos meses, tres meses o reciente, dos semanas? por ahí. avísame a ver qué me indicas, investiga.

### Asistente

Sí. Investigué específicamente **cómo se interpreta la detección de cannabis en orina**, porque hay una diferencia importante entre “dio positivo” y “consumió recientemente”.

La prueba de orina normalmente **no busca el THC activo**, sino principalmente un metabolito llamado **THC-COOH**, que queda en el organismo después de haber consumido cannabis. Por eso una persona puede dar positivo aunque en ese momento no esté bajo los efectos. citeturn704217search0turn704217search36

Como referencia general, las ventanas pueden verse aproximadamente así:

| Patrón de consumo | Posible detección en orina |
|---|---:|
| Uso aislado/ocasional | ~1–3 días, a veces más |
| Varias veces por semana | ~5–7 días |
| Uso diario | ~10–15 días |
| Uso crónico/intenso | **30 días o más** |
| Casos de consumo crónico muy intenso | pueden llegar a **30–60 días**, excepcionalmente más |

Mayo Clinic señala que en consumidores crónicos el THC y sus metabolitos pueden acumularse en tejido graso y continuar excretándose **30–60 días después de suspender el consumo**. citeturn704217search2turn704217search3 SAMHSA da cifras orientativas similares: aproximadamente 3 días tras uso aislado, unos 10 días para uso intenso y 30–36 días en consumo crónico intenso. citeturn704217search36

Y aquí está la parte clave para tu decisión: **un positivo aislado en orina no permite saber cuándo fumó**. No puedes concluir simplemente “fumó ayer”, “fumó hace una semana” o “estaba drogado durante el examen”. En consumidores frecuentes puede ser residuo de un consumo anterior. Incluso las concentraciones pueden variar por hidratación y otros factores. citeturn704217search5

### ¿Dos o tres meses?

**Dos meses: sí, es posible en determinados consumidores crónicos.** Hay literatura científica que ha observado ventanas particularmente prolongadas, aunque eso no es lo habitual para un consumidor ocasional. citeturn704217search7turn704217search10

**Tres meses: existen reportes en consumidores crónicos muy intensos**, pero sería un extremo y no deberías interpretar automáticamente un positivo como consumo ocurrido dentro de los últimos días. Un estudio citado en la literatura encontró detecciones prolongadas de hasta 67–93 días dependiendo del método y del punto de corte utilizado. citeturn704217search7

Entonces imagina estos dos candidatos:

**Candidato A:** consumió una vez hace varios días → podría dar positivo.

**Candidato B:** consume frecuentemente y dejó hace varias semanas → también podría dar positivo.

Con **un solo análisis de orina**, probablemente no puedes distinguirlos.

Y esto modifica un poco nuestra conversación anterior: **el positivo sí es una señal relevante para SST y para un puesto sensible como conducción, pero científicamente no demuestra que ese hombre conduzca bajo los efectos ni que haya consumido recientemente.**

Si quieres determinar si existe **consumo nuevo versus eliminación residual**, ya se necesitan pruebas cuantitativas seriadas y una interpretación del laboratorio/medicina ocupacional; se puede comparar la concentración de THC-COOH ajustada por creatinina entre muestras. citeturn704217search5

Por eso, para tu caso en Sinba, yo preguntaría al centro médico algo muy concreto antes de cerrar el tema: **“¿El resultado solamente dice positivo/negativo o tenemos concentración de THC-COOH y conclusión de aptitud ocupacional?”**

Eso te puede cambiar bastante el panorama del candidato.

### Marlon

No, el resultado solo dice positivo.

### Asistente

Entonces, con solo **“positivo”**, no puedes saber tres cosas importantes: **cuándo consumió, cuánto consumió ni si estaba bajo efectos al momento del examen**.

Ese resultado funciona más como un **filtro de presencia**: detectó metabolitos compatibles con consumo previo, pero no te permite distinguir si fue hace 2 días, 2 semanas o más tiempo en un consumidor frecuente.

Para tu decisión de selección, yo lo vería así: si Sinba tiene como criterio para choferes que el toxicológico debe salir negativo, entonces **no necesitas interpretar más de lo que el examen dice**. Simplemente el candidato no cumple ese requisito hoy y continúas buscando otro.

La forma más sólida de manejarlo sería: **“El candidato aprobó la prueba de manejo, pero el examen toxicológico arrojó positivo. Al tratarse de una posición crítica de conducción y no contar con mayor detalle sobre temporalidad ni concentración, considero que no deberíamos continuar con el ingreso.”**

Eso es mucho más defendible que intentar concluir si fuma seguido o si consumió recientemente. Con ese resultado solo, eso no se puede afirmar.

### Marlon

Claro, pero lo que pasa es que es, digo, es desconfianza total, porque ya hay una desconfianza para poner a alguien al control de un volante. Entonces puede que no haya un consumo, puede que el consumo haya sido una hace una semana, hace un mes, o lo que sea. Pero, para ser sensato, hay gente que puede dominar incluso el control, ¿no?, del consumo del cannabis y puedes verlo como algo normal, ¿no? puedes mantenerse en constante nota y quizás estar tranquilo trabajando sin ningún problema.

### Asistente

Sí, ese es justamente el punto más difícil: **la incertidumbre**.

Puede existir una persona que consuma cannabis de forma frecuente y que, subjetivamente, sienta que “lo controla” o que funciona normalmente. Pero para un puesto de conducción eso no te resuelve el problema, porque tú no puedes basar la seguridad en la autopercepción del candidato ni en si “parece tranquilo”.

Desde afuera, yo lo separaría así:

- **Una cosa es consumo previo.** El positivo en orina solo te dice que hubo exposición/consumo en algún momento dentro de una ventana que puede ser amplia.
- **Otra cosa es deterioro actual.** Esa prueba por sí sola no demuestra que estaba afectado ese día.
- **Y otra distinta es el riesgo laboral.** Para un conductor profesional, si ya tienes una señal de consumo y no puedes saber frecuencia, temporalidad ni si podría repetirse cerca de una jornada, aparece una incertidumbre que para un puesto crítico pesa bastante.

Entonces tu desconfianza no necesariamente significa “esta persona va a manejar drogada”. Más bien significa: **“no tengo suficiente certeza para asumir este riesgo en una posición donde un error puede tener consecuencias graves.”**

Ahí sí me parece sensato.

Donde yo tendría cuidado es con la idea de “puede mantenerse en constante nota y trabajar normal”. Puede haber personas que desarrollen tolerancia subjetiva, pero **tolerancia no equivale a ausencia de afectación**, especialmente en atención, tiempo de reacción, juicio o percepción del riesgo. Y además, no es algo que tú puedas verificar de manera confiable en la operación diaria.

Por eso, para selección, veo dos criterios posibles:

**Criterio estricto:** para cualquier chofer, toxicológico negativo como requisito de ingreso. Si sale positivo, no continúa.

**Criterio médico:** si sale positivo, se deriva a Medicina Ocupacional para confirmación/aptitud y solo continúa si existe un protocolo formal que lo permita.

Lo que me parecería débil es un tercer escenario: “manejó bien, parece responsable, así que lo dejamos pasar”. Ahí sí estarías tomando una decisión basada en impresión personal frente a una señal objetiva.

En resumen: **tu desconfianza no tiene que ser moral ni personal; puede ser simplemente operacional.** No estás diciendo “es una mala persona” ni “es un adicto”. Estás diciendo: “para este puesto necesito un nivel de certeza mayor del que tengo hoy”. Eso, para conducción, es un criterio bastante razonable.
