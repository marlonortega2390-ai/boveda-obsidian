---
tags: [indice, conversaciones-ai, importacion]
---

# Otros — bandeja de importación personal

La clasificación útil está en [[../00 - Personal|Personal]]. Esta página conserva la lista original para comprobar que ninguna conversación quede fuera.

## Conversaciones

- [[Deducciones sobre ti--6a9fa994-9974-83e9-8266-51ab65f8ca7d|Deducciones sobre ti]]
- [[Programar estudio A2B--6a890071-38d8-83e9-b14b-6d24c47cc76e|Programar estudio A2B]]
- [[Vitaminas para lactancia--6a9eea5a-d198-83e9-8391-e2f4721e4d2c|Vitaminas para lactancia]]
- [[Editar foto gym--6a99ea8e-506c-83e9-8d45-53407f14d876|Editar foto gym]]
- [[Análisis de discusión doméstica--6a990273-b42c-83e9-b1ac-f1fc9c32d875|Análisis de discusión doméstica]]
- [[Editar logo y sentadilla--6a95fb6e-31e4-83e9-a4a3-9ad5f9fab8c9|Editar logo y sentadilla]]
- [[Mejorar banner del gym--6a95e307-7900-83e9-9fb2-6032d14dea26|Mejorar banner del gym]]
- [[Retrato profesional de marca--6a95c646-ad58-83e9-90f2-1b40f7758613|Retrato profesional de marca]]
- [[Analizar vídeo--6a9325b2-9428-83e9-8c59-22b94e6b7164|Analizar vídeo]]
- [[Explicar apps de IA--6a8f0762-9664-83e9-99bd-11febc4567fa|Explicar apps de IA]]
- [[Explicar límite de Codex--6a8f0d0a-8e64-83e9-9e55-6a3da8c56ee8|Explicar límite de Codex]]
- [[Carta de renuncia y correo--6a8ee76c-933c-83e9-a414-923e72a7e9eb|Carta de renuncia y correo]]
