---
title: "Carta de renuncia y correo"
conversation_id: "6a8ee76c-933c-83e9-a414-923e72a7e9eb"
type: "chatgpt"
project_id: "g-p-6a03602663008191b5d8ab97a83e1d56"
area: "02 - Personal/Otros"
updated_at: 1787750951.077
archived: false
export_complete: true
tags: [conversacion-ai, jarvis-import]
---

# Carta de renuncia y correo

- ID: `6a8ee76c-933c-83e9-a414-923e72a7e9eb`
- Tipo: `chatgpt`
- Proyecto: `g-p-6a03602663008191b5d8ab97a83e1d56`
- Estado: `activa`

## Conversación

### Marlon

Escribe una carta de renuncia, dirigido a lourdes achara de parte de isabel machuca y escribe un correo de porque de la renuncia como un formato para que ella pueda llenar  y explayarse en el correo ya que su renuncia tiene varios motivos falta de 1 a 1 con el gerente de operacione, problemas con la lider de nodo en biofabrica, falta de empatia ostigamiento, y denuncia de ostigamiendo que no se llevo acabo investigacion se calmo un poco la situacion y de nuevo ha habido nuevo problemas sobre esto y falta de seguimiento de trabajo con ella para su crecimiento laboral lo cual la ha perjudicado, del nivel 1  que era paso a nivel -2 cerca del tres en su evaluacion anual llevando al limite y de mandar este renuncia, entonces ella no es de saber hablar muy bien en el sentido no se sabe expresar entonces necesito que exprese claridad sin faltar el respeto pero tambien mencionando esto,ella tien pruebas en whatsap etc etc donde se evidencia la falta de empatia ostigamiendo laboral y coloquialmente un cargamonton de errores y poniendo a otros colaboradores por encima de ella que no tienen ni un año, y ella va cumplir 5 años en la empresa, donde se destaco bastante bien pero desde que esta en biofabrica en el mando del lourdes, se ha visto su desmejora, desanimo falta de crecimiendo por falta que si esta generando en otros colaboradores, solicito cambio de area en la unica area que no esta la señorita lourdes que es logistica asi sea como ayudante pero le mencionaron que tenia 3 meses de prueba a una persona que tiene 5 años laborando en la empresa y es de la mas ejemplares y viendose vinculado piero perrigo donde se ha hecho de la vista ciega porque lourdes es las personas que no acepta que nadie le lleve la contraria, y piero tampoco y le han dado esa mala informacion donde piero ha visto de mala forma y le ha dicho que quiere a su capitana de nuevo pero todo cambio cuando paso del circ comandado por angel cortez y pasando a lourdes achata viendose una baja, sigue como te dije en duda si se hizo una investigacion por ostigamiendo laboral y no se realizo la comunicacion y esta ostigamiendo tambien se ha extendido a otros capitanes que se han dado de baja por falta de esa empatia y trabajo con el personal  debe ser un correo claro consiso sin omitir nada la idea es dejar el msjs a la gente&#x20;

### Asistente

Sí. En este caso conviene separar **dos documentos**:

1. **Carta de renuncia:** breve, formal y sin entrar en el conflicto.
2. **Correo que acompaña la renuncia:** aquí Isabel deja constancia de los motivos, antecedentes, solicitudes de apoyo y evidencias.

Hay algo importante: en el correo evitaría afirmar como hecho probado que determinadas personas “cometieron hostigamiento”. Es más sólido escribir **“situaciones que percibí y reporté como hostigamiento laboral”**, describir hechos concretos y señalar que existen evidencias. Así deja una constancia seria sin convertir el correo en un ataque personal.

## 1. CARTA DE RENUNCIA — ISABEL MACHUCA

**Lima, [FECHA]**

**Señora:**  
**Lourdes Achata**  
Presente.-

**Asunto: Renuncia voluntaria**

De mi consideración:

Por medio de la presente, yo, **Isabel Machuca**, presento formalmente mi **renuncia voluntaria** al cargo que actualmente desempeño en la empresa, solicitando que esta sea efectiva a partir del día **[FECHA DE CESE]**.

Esta decisión ha sido tomada luego de una evaluación personal y profesional de diversas situaciones que se han venido presentando durante los últimos meses y que han afectado mi experiencia laboral, motivación y perspectivas de crecimiento dentro de la organización.

Agradezco sinceramente las oportunidades de aprendizaje y desarrollo que he recibido durante los **casi cinco años que he formado parte de la empresa**, así como la confianza que en diferentes etapas fue depositada en mi trabajo.

Por separado, mediante correo electrónico, dejaré constancia de los principales motivos que me han llevado a tomar esta decisión, con la finalidad de que puedan ser conocidos y, de considerarlo pertinente, revisados por la organización.

Solicito se realicen los procedimientos correspondientes para formalizar mi cese y la entrega de la documentación que corresponda.

Atentamente,

**Isabel Machuca**  
DNI/CE: [__________]  
Cargo: [__________]  
Firma: __________________

---

# 2. CORREO PARA EXPLICAR LOS MOTIVOS

Este sí lo haría **mucho más completo**, porque si Isabel está llegando a renunciar después de casi cinco años, debería quedar documentado que **no se trata de una decisión repentina ni de un único problema**.

**Asunto: Presentación de renuncia y exposición de motivos – Isabel Machuca**

Estimada Lourdes:

Por medio del presente adjunto formalmente mi carta de renuncia.

No ha sido una decisión sencilla. Estoy próxima a cumplir **cinco años trabajando en la empresa**, periodo durante el cual considero que he demostrado compromiso, responsabilidad y disposición para aprender y apoyar en las funciones que me han sido asignadas.

Precisamente por el tiempo que llevo en la organización y por lo importante que ha sido para mí, considero necesario explicar con claridad los motivos que me han llevado a tomar esta decisión.

Durante una etapa importante de mi permanencia en la empresa tuve un buen desempeño y una evolución favorable. Sin embargo, considero que mi situación comenzó a cambiar significativamente desde mi traslado del **CIRC, donde trabajaba bajo el liderazgo de Ángel Cortez, hacia Biofábrica**.

Desde entonces he sentido un deterioro progresivo tanto en mi experiencia laboral como en mi motivación y desarrollo profesional.

Uno de los aspectos que más me ha afectado ha sido **[AQUÍ ISABEL DEBE EXPLICAR CON SUS PALABRAS QUÉ SITUACIONES HA VIVIDO CON LOURDES: llamados de atención, formas de comunicación, diferencias de trato, situaciones frente a compañeros, etc.]**.

En diferentes oportunidades he percibido falta de empatía en el trato y situaciones que considero que han generado un ambiente laboral hostil hacia mi persona. Incluso llegué a **reportar situaciones que consideré como posible hostigamiento laboral**.

Respecto de este reporte, hasta la fecha **[COMPLETAR: indicar cuándo se reportó, a quién, qué se comunicó y qué respuesta recibió]**. Si se realizó una investigación formal, personalmente no recibí una comunicación clara sobre sus resultados, conclusiones, medidas adoptadas o cierre del caso.

Posteriormente la situación pareció tranquilizarse durante un tiempo. Sin embargo, se han presentado nuevamente situaciones que me han hecho sentir que el problema de fondo no fue solucionado ni tuvo el seguimiento que esperaba.

Cuento con **conversaciones de WhatsApp y otras evidencias** que respaldan diferentes situaciones que estoy mencionando y que puedo presentar por los canales correspondientes en caso sean requeridas.

Otro punto que considero importante dejar registrado es que, durante este periodo, he sentido una acumulación constante de observaciones y errores atribuidos a mi trabajo, mientras que he percibido un trato y oportunidades diferentes hacia otros colaboradores, incluso personas con menor tiempo dentro de la organización.

No considero que la antigüedad deba otorgarme privilegios ni colocarme por encima de ningún compañero. Sin embargo, después de casi cinco años trabajando en la empresa, considero razonable esperar que mi trayectoria, experiencia, desempeño histórico y conocimiento adquirido sean evaluados de manera integral.

También considero que me ha faltado **acompañamiento para mi desarrollo profesional**. No he contado con espacios 1 a 1 suficientemente constantes con la Gerencia de Operaciones que me permitieran revisar mi desempeño, comprender claramente qué debía mejorar, establecer objetivos y contar con un plan de seguimiento que me permitiera recuperar y fortalecer mi rendimiento.

Esto ha terminado reflejándose también en mis evaluaciones. Pasé de encontrarme anteriormente en un **nivel 1 a llegar a aproximadamente un nivel -2, cercano al -3, en mi evaluación anual**.

Más allá de la calificación, lo que me preocupa es no haber sentido que existiera un proceso de acompañamiento proporcional a esta caída. Para mí, una disminución tan considerable en el desempeño de una persona que anteriormente había mostrado buenos resultados también debería haber generado preguntas sobre qué estaba ocurriendo, qué había cambiado en su entorno de trabajo y qué apoyo necesitaba para mejorar.

La situación llegó al punto de que solicité evaluar un **cambio de área**, específicamente hacia Logística, incluso manifestando mi disposición de ingresar como ayudante si era necesario, porque mi prioridad era continuar trabajando y encontrar un espacio donde pudiera recuperar mi motivación y demostrar nuevamente mi capacidad.

Frente a esa posibilidad se me indicó **[COMPLETAR EXACTAMENTE QUIÉN LO DIJO Y CÓMO SE PLANTEÓ]** que tendría un periodo de prueba de tres meses.

Esto me generó mucha frustración. Entiendo perfectamente que un cambio de puesto implica adaptación y que debo demostrar que puedo cumplir nuevas funciones. Sin embargo, después de casi cinco años dentro de la misma organización y teniendo un historial laboral previo que puede ser revisado, sentí que mi trayectoria estaba siendo prácticamente reiniciada en lugar de ser considerada como parte de mi evaluación.

También tuve conocimiento de comentarios realizados por **Piero Perrigo** respecto de mi situación, entre ellos **[ESCRIBIR TEXTUALMENTE O LO MÁS EXACTO POSIBLE LO QUE DIJO SOBRE “QUIERO A MI CAPITANA DE NUEVO”, INDICANDO EL CONTEXTO]**.

Este punto también me afectó porque considero que algunas percepciones sobre mi desempeño pudieron haberse formado sin que yo tuviera suficientes espacios para explicar directamente mi situación, mostrar mi perspectiva y recibir retroalimentación de manera continua.

Quiero ser muy clara: **este correo no tiene como finalidad atacar, desacreditar ni faltar el respeto a Lourdes, Piero ni a ninguna otra persona de la organización.** Tampoco pretendo afirmar que todo lo sucedido responda necesariamente a una intención personal en mi contra.

Lo que estoy haciendo es dejar constancia de **cómo he vivido este proceso**, de las situaciones que reporté, de la falta de seguimiento que he percibido y del impacto que todo esto ha tenido sobre mi motivación, desempeño y decisión de retirarme.

También considero importante que la empresa evalúe si algunas de estas situaciones se han presentado con otros integrantes de los equipos o con anteriores capitanes, porque **[AQUÍ ISABEL PUEDE EXPLICAR ÚNICAMENTE LOS CASOS QUE CONOZCA DIRECTAMENTE, EVITANDO HABLAR POR TERCEROS O AFIRMAR MOTIVOS DE RENUNCIA QUE ELLOS NO LE HAYAN CONFIRMADO]**.

Después de casi cinco años, me resulta especialmente triste terminar mi relación laboral de esta manera.

No considero que haya dejado de tener capacidad para aportar a la empresa. Por el contrario, siento que progresivamente fui perdiendo motivación y oportunidades de desarrollo dentro del entorno en el que me encontraba, hasta llegar a un punto en el que continuar se volvió muy difícil para mí.

Por ello, mi renuncia no responde únicamente a un hecho reciente. Es consecuencia de una **acumulación de situaciones, falta de seguimiento, dificultades en la relación laboral, percepción de trato desigual, ausencia de espacios adecuados de retroalimentación y una sensación de estancamiento profesional** que se ha mantenido durante un periodo prolongado.

Antes de retirarme, considero responsable dejar esta información registrada para que la empresa pueda revisarla y determinar si existen oportunidades de mejora en la forma en que se acompaña, evalúa y gestiona a las personas.

Solicito además, de considerarlo correspondiente, que este correo sea puesto en conocimiento de **Gestión Humana y/o de la instancia responsable de revisar este tipo de situaciones**, y que se me confirme su recepción.

Estoy dispuesta a ampliar cualquiera de los puntos mencionados y a presentar las evidencias que correspondan por los canales formales que la empresa establezca.

A pesar de las circunstancias que motivan mi salida, agradezco las oportunidades que recibí durante estos casi cinco años y a las personas que contribuyeron positivamente a mi desarrollo durante mi permanencia en la organización.

Atentamente,  
**Isabel Machuca**  
[Cargo]  
[Teléfono, si corresponde]

---

### Algo que sí cambiaría antes de enviarlo

No pondría literalmente **“Lourdes no acepta que nadie le lleve la contraria”, “Piero se hizo de la vista gorda”, “cargamontón”** o que otros capitanes renunciaron *por culpa de Lourdes*. Esas frases son entendibles hablando entre ustedes, pero debilitan un correo formal.

Es mucho más fuerte que Isabel ponga **hechos comprobables**:

> “El [fecha] ocurrió X. Lo comuniqué a X persona mediante WhatsApp/correo. Recibí esta respuesta. Posteriormente ocurrió X. Adjunto/cuento con la conversación correspondiente.”

Si existen WhatsApps, fechas, nombres de testigos, evaluaciones anteriores y posteriores, solicitudes de cambio de área y el reporte previo por posible hostigamiento, **eso habla mucho más fuerte que cualquier calificativo**.

Y hay un detalle clave: **yo no mandaría las pruebas desordenadas junto con el primer correo**. Primero las organizaría cronológicamente: fecha → situación → a quién se reportó → respuesta → evidencia disponible. Eso permitiría que Isabel tenga un expediente bastante más sólido si posteriormente Gestión Humana le pide sustento.

### Marlon

Lo que pasa es que en la carta, en el inicio mencionas de que la persona tiene pruebas y luego dices que no es algo atribuible ni al orden ni a... pero sí hay ciertas pruebas. Entonces creo que deberíamos organizar muy bien el mensaje porque pareciera que afirmamos algo y luego nos contradecimos. No sé si lo puedes notar.

### Asistente

Sí, lo noto. El problema no es solo de redacción, sino de **posición del correo**.

Primero decimos que existen evidencias de determinadas conductas y luego usamos una frase como *“no pretendo afirmar que exista una intención personal en mi contra”*. Aunque jurídicamente intenta ser prudente, narrativamente **le quita fuerza a lo anterior** y puede sonar como: “esto ocurrió, tengo pruebas… pero quizá no ocurrió así”.

Yo lo reorganizaría bajo una sola línea: **Isabel afirma los hechos que vivió y que puede acreditar; lo que no hace es especular sobre las intenciones de las personas.** Eso no es contradictorio.

Por ejemplo, esa parte debería quedar así:

> Durante este periodo se han presentado situaciones relacionadas con el trato recibido, la forma de comunicación y determinadas actuaciones laborales que considero inadecuadas y que oportunamente reporté como situaciones de hostigamiento laboral.
>
> **Estas situaciones no se sustentan únicamente en mi percepción. Cuento con conversaciones de WhatsApp y otros elementos que permiten acreditar diversos hechos mencionados en este correo**, los cuales puedo presentar formalmente si son requeridos.
>
> En su momento comuniqué esta situación a [PERSONA/ÁREA] el [FECHA]. Posteriormente, el problema disminuyó durante un periodo; sin embargo, no recibí información clara respecto de si se realizó una investigación formal, cuáles fueron sus conclusiones, qué medidas se adoptaron o cómo se daría seguimiento al caso.
>
> Actualmente se han vuelto a presentar situaciones relacionadas con esta problemática, razón por la cual considero especialmente importante dejar constancia de que **el problema fue previamente comunicado y, desde mi experiencia, no tuvo un seguimiento que permitiera resolverlo de manera definitiva.**

Y más adelante, en lugar de la parte que genera la contradicción, pondría:

> Quiero precisar que el propósito de este correo **no es realizar ataques personales ni utilizar calificativos contra Lourdes, Piero o cualquier otro integrante de la organización**. Mi propósito es dejar constancia de hechos y situaciones que han ocurrido durante mi permanencia en Biofábrica, algunos de los cuales cuentan con evidencia documental, así como explicar el impacto que han tenido en mi desempeño, motivación y finalmente en mi decisión de renunciar.
>
> Por esa misma razón, procuro diferenciar claramente entre **los hechos que puedo sustentar**, mi experiencia personal frente a ellos y aquellas situaciones sobre las cuales corresponde a la empresa determinar responsabilidades mediante los procedimientos internos correspondientes.

Eso sí queda coherente: **“Tengo pruebas de hechos concretos. No estoy insultando ni atribuyendo intenciones. Le corresponde a la empresa determinar responsabilidades.”**

También cambiaría el orden completo del correo. Ahora mismo estamos saltando entre Lourdes → evaluación → Piero → hostigamiento → cambio de área → nuevamente Lourdes. Para que tenga peso, debería contar **una historia cronológica**:

1. **Casi 5 años y desempeño previo positivo.**
2. **Cambio de CIRC/Bajo Ángel hacia Biofábrica/Bajo Lourdes.**
3. **Inicio del deterioro y situaciones concretas.**
4. **Reporte de hostigamiento + evidencias + qué hizo/no comunicó la empresa.**
5. **Situación se calma y posteriormente reaparece.**
6. **Falta de 1 a 1 y acompañamiento de Gerencia de Operaciones.**
7. **Caída de evaluación de nivel 1 a -2/cercano a -3 sin un plan adecuado de recuperación.**
8. **Percepción de trato/oportunidades diferentes frente a colaboradores nuevos.**
9. **Solicitud de traslado a Logística y respuesta de los tres meses de prueba.**
10. **Intervención/percepción de Piero y falta de espacio para que Isabel explicara su versión.**
11. **Todo lo anterior acumulado → renuncia.**
12. **Solicitud formal de que RR. HH. revise los antecedentes y el reporte previo.**

Además, hay una frase que para mí puede convertirse en **el centro del correo**:

> **“Mi preocupación no es únicamente haber recibido una evaluación negativa. Mi preocupación es cómo una trabajadora que durante años mantuvo un desempeño favorable pudo pasar de un nivel 1 a un nivel -2, cercano al -3, sin que ese deterioro generara un proceso suficiente de acompañamiento, seguimiento y análisis sobre qué estaba ocurriendo en su entorno laboral.”**

Eso es mucho más potente que decir simplemente que Lourdes la perjudicó. Obliga a quien lea el correo a preguntarse: **“¿Qué pasó entre una etapa y otra?”**

Y después se conecta con el cambio de liderazgo:

> “Considero relevante que este deterioro coincide con mi cambio de CIRC, donde trabajaba bajo el liderazgo de Ángel Cortez, hacia Biofábrica. No menciono esta comparación para responsabilizar automáticamente a una persona por mi evaluación, sino porque considero que constituye un antecedente objetivo que debería ser revisado junto con mis evaluaciones, comunicaciones y reportes anteriores.”

Ahí ya tenemos una narrativa mucho más seria: **no se retracta, no acusa sin sustento y tampoco suaviza tanto el mensaje que termina perdiéndose la denuncia.**

Si quieres, rehago **todo el correo desde cero con esta estructura**, bastante más firme que la primera versión y dejando espacios `[COMPLETAR]` solamente donde necesitamos que Isabel coloque fechas, situaciones y pruebas concretas.

### Marlon

si por favor

### Asistente

Sí. Yo lo rehacería completo para que tenga una sola línea argumental: **Isabel no está renunciando por un episodio aislado; está dejando constancia de un deterioro progresivo de su situación laboral, de hechos que ya fueron reportados, de evidencia disponible y de la falta de seguimiento que percibió.** Al mismo tiempo, evitamos afirmar conclusiones que le corresponde determinar a una investigación.

Te dejo primero el **correo principal**, que es donde realmente debe quedar el mensaje. Después, una carta de renuncia mucho más breve.

## Correo de Isabel

**Asunto: Presentación de renuncia y exposición de motivos – Isabel Machuca**

Estimada Lourdes:

Por medio del presente adjunto formalmente mi carta de renuncia.

Tomar esta decisión no ha sido sencillo. Estoy próxima a cumplir **cinco años trabajando en la empresa**, tiempo durante el cual he procurado desempeñar mis funciones con responsabilidad, compromiso y disposición para aprender y apoyar donde se me ha requerido.

Por el tiempo que llevo en la organización y por todo lo que ha significado para mí, considero importante que mi salida no quede registrada simplemente como una renuncia voluntaria sin explicar las circunstancias que me llevaron hasta este punto.

Durante varios años considero que mantuve un buen desempeño y pude demostrar mi capacidad y compromiso. Sin embargo, mi experiencia laboral comenzó a cambiar de manera importante después de mi traslado del **CIRC, donde trabajaba bajo el liderazgo de Ángel Cortez, hacia Biofábrica, bajo el liderazgo de Lourdes Achata**.

A partir de ese cambio considero que se produjo un deterioro progresivo en mi experiencia laboral, mi motivación, mi desempeño y mis posibilidades de crecimiento dentro de la empresa.

### Situaciones reportadas y antecedentes de hostigamiento

Durante mi permanencia en Biofábrica se han presentado situaciones relacionadas con el trato recibido, formas de comunicación y actuaciones laborales que consideré inadecuadas y que en su momento llegué a **reportar como situaciones de hostigamiento laboral**.

Quiero señalar que estos antecedentes **no se sustentan únicamente en mi recuerdo o percepción actual**. Cuento con conversaciones de WhatsApp y otros elementos que permiten acreditar diversos hechos y comunicaciones relacionados con las situaciones que estoy mencionando, los cuales puedo presentar formalmente si son requeridos.

El reporte fue realizado **[INDICAR FECHA/APROXIMACIÓN, A QUIÉN SE COMUNICÓ Y MEDIANTE QUÉ MEDIO]**.

Luego de comunicar lo que estaba ocurriendo, la situación disminuyó durante un periodo. Sin embargo, hasta la fecha no tuve una comunicación suficientemente clara respecto de **si se realizó una investigación formal, cuál fue su resultado, qué conclusiones se obtuvieron, qué medidas se adoptaron o cómo se realizaría el seguimiento posterior**.

Este punto es especialmente importante para mí porque, después de un periodo de mayor tranquilidad, **se han vuelto a presentar situaciones relacionadas con la problemática que anteriormente había reportado**.

Por ello, considero necesario dejar constancia de que no estoy comunicando por primera vez esta situación con motivo de mi renuncia. **Existió un reporte previo y existen antecedentes que pueden ser revisados por la empresa.**

### Deterioro de mi desempeño y falta de acompañamiento

Otro aspecto que me ha afectado profundamente ha sido observar el deterioro progresivo de mi evaluación laboral.

Anteriormente llegué a encontrarme en un **nivel 1** y actualmente he pasado a aproximadamente un **nivel -2, cercano al -3, en mi evaluación anual**.

Entiendo y acepto que como trabajadora puedo cometer errores, recibir observaciones y tener aspectos que mejorar. No pretendo desconocer mi responsabilidad sobre aquello que efectivamente me corresponda.

Sin embargo, mi preocupación no es únicamente haber recibido una evaluación negativa.

Mi preocupación es **cómo una trabajadora que durante años mantuvo un desempeño favorable pudo pasar de un nivel 1 a un nivel -2, cercano al -3, sin que ese deterioro generara un proceso suficiente de acompañamiento, seguimiento y análisis sobre qué estaba ocurriendo, qué necesitaba mejorar y qué factores podían estar influyendo en esta caída**.

Considero relevante también que este deterioro coincide con mi cambio de CIRC hacia Biofábrica.

No menciono esta comparación para atribuir automáticamente mi evaluación a una sola persona, sino porque considero que constituye un antecedente que debería analizarse junto con **mis evaluaciones anteriores, evaluaciones actuales, comunicaciones, reportes y demás antecedentes laborales**.

### Falta de espacios 1 a 1 y seguimiento para mi crecimiento

Durante este proceso también he sentido la ausencia de espacios suficientes de acompañamiento y seguimiento, incluyendo reuniones **1 a 1 con la Gerencia de Operaciones**, que me permitieran conocer claramente qué estaba haciendo mal, qué esperaba la empresa de mí, cuáles eran mis oportunidades de mejora y qué acciones debía realizar para recuperar mi desempeño.

Cuando una persona comienza a bajar considerablemente su rendimiento después de haber tenido buenos resultados anteriormente, considero que no solamente debería observarse el resultado final, sino también tratar de comprender **qué cambió y qué está ocurriendo con esa persona**.

Personalmente no sentí que existiera ese acompañamiento de manera suficiente.

Esto no solamente afectó mi evaluación, sino también mi motivación y la percepción que fui formando sobre mis posibilidades de continuar creciendo dentro de la empresa.

### Acumulación de observaciones y percepción de trato desigual

Durante esta etapa también he sentido una acumulación constante de observaciones y errores atribuidos a mi trabajo.

Reitero que no tengo inconveniente en reconocer y corregir mis errores cuando corresponda. Sin embargo, también he percibido diferencias en la manera en que se gestionan las equivocaciones, oportunidades y crecimiento de otros colaboradores.

He observado oportunidades y confianza otorgadas a personas que incluso tienen menos de un año dentro de la organización, mientras que yo, estando próxima a cumplir cinco años, progresivamente he sentido que mi trayectoria y experiencia han perdido valor dentro de mi actual entorno laboral.

No considero que tener más antigüedad me otorgue privilegios ni que deba colocarme por encima de ningún compañero. Todos merecemos oportunidades de desarrollo.

Lo que considero difícil de comprender es que una persona que durante años tuvo un desempeño favorable pueda llegar a sentirse **estancada, desmotivada y sin oportunidades claras de recuperación o crecimiento**, mientras observa que sí existen procesos de desarrollo para otros integrantes del equipo.

### Mi solicitud de cambio a Logística

Precisamente porque todavía quería continuar trabajando en la empresa y buscar una alternativa antes de llegar a renunciar, solicité la posibilidad de realizar un **cambio de área hacia Logística**.

Mi disposición llegó incluso a plantear que podía ingresar **como ayudante**, porque para mí era más importante tener la oportunidad de comenzar una nueva etapa dentro de la misma empresa, recuperar mi motivación y demostrar nuevamente mi capacidad.

Frente a esta posibilidad se me indicó **[INDICAR QUIÉN LO DIJO Y CÓMO FUE COMUNICADO]** que tendría aproximadamente **tres meses de prueba**.

Comprendo perfectamente que cambiar de área o asumir nuevas funciones requiere adaptación y que cualquier persona debe demostrar que puede cumplir correctamente un nuevo puesto.

Sin embargo, después de casi cinco años trabajando para la misma organización, esta condición me generó una sensación de que mi trayectoria previa, conocimiento de la empresa y desempeño histórico prácticamente no estaban siendo considerados.

No estaba solicitando que se me garantizara un puesto sin evaluación. Estaba solicitando **una oportunidad real de continuar dentro de una organización a la que he dedicado casi cinco años**.

### Participación de Gerencia de Operaciones

Dentro de este proceso también intervino **Piero Perrigo**, Gerente de Operaciones, y recibí comentarios respecto de mi situación y desempeño, incluyendo **[ISABEL: COLOCAR AQUÍ LO MÁS EXACTAMENTE POSIBLE QUÉ TE DIJO PIERO, EN QUÉ CONTEXTO Y CUÁNDO. POR EJEMPLO, EL COMENTARIO RELACIONADO CON “QUIERO A MI CAPITANA DE NUEVO”]**.

Esta situación también me generó preocupación porque sentí que se había formado una percepción negativa respecto de mi desempeño sin que yo hubiera tenido suficientes espacios 1 a 1 para explicar directamente lo que estaba viviendo, conocer qué información estaba recibiendo la gerencia respecto de mí y trabajar conjuntamente en un verdadero proceso de recuperación.

Después de varios años dentro de la empresa, considero que antes de llegar a este nivel de deterioro debería haber existido una oportunidad más amplia para conversar conmigo, escuchar mi versión, revisar mis antecedentes y establecer compromisos claros de mejora.

### Por qué finalmente decidí renunciar

Quiero dejar algo especialmente claro.

**Mi renuncia no responde a un único problema, una discusión reciente o una decisión impulsiva.**

Es el resultado de una acumulación de situaciones que durante un periodo prolongado han afectado mi experiencia dentro de la empresa:

- situaciones de trato que anteriormente reporté y que consideré hostigamiento laboral;
- falta de claridad respecto de la investigación y seguimiento de dicho reporte;
- aparición posterior de nuevas situaciones relacionadas con esa problemática;
- deterioro considerable de mi evaluación y desempeño;
- falta de espacios suficientes de acompañamiento y reuniones 1 a 1;
- percepción de diferencias en el trato, las observaciones y las oportunidades de crecimiento;
- sensación de estancamiento profesional;
- y finalmente, la dificultad para encontrar una alternativa de cambio interno que me permitiera continuar desarrollándome dentro de la organización.

No escribo esto con la intención de atacar personalmente a Lourdes, Piero ni a ningún otro integrante de la empresa.

Lo escribo porque considero que después de casi cinco años **tengo derecho a explicar claramente qué circunstancias me llevaron a tomar esta decisión y la empresa también tiene derecho a conocerlas**.

Por esa misma razón, considero importante diferenciar tres cosas: **los hechos y comunicaciones que puedo sustentar mediante evidencias, la manera en que estas situaciones me han afectado laboralmente y las responsabilidades que correspondan determinar a la empresa mediante los procedimientos internos pertinentes.**

No me corresponde a mí determinar el resultado de una investigación. Sí me corresponde dejar constancia de lo que viví, de aquello que reporté y de las evidencias con las que cuento.

### Una situación que considero debería ser revisada

También considero importante que la empresa evalúe si algunas de estas situaciones de liderazgo, comunicación, manejo de errores y acompañamiento al personal se han presentado con otros integrantes o anteriores capitanes.

En este punto quiero ser responsable y no hablar en nombre de terceros. Por ello, únicamente puedo mencionar directamente aquellos casos o situaciones que conozco y que pueda sustentar: **[ISABEL: AQUÍ COLOCA LOS CASOS CONCRETOS QUE CONOZCAS PERSONALMENTE. NO PONGAS RUMORES.]**

Considero que revisar estos antecedentes podría permitir determinar si mi experiencia corresponde únicamente a una situación individual o si existen oportunidades de mejora más amplias en la gestión del equipo.

### Finalmente

Después de casi cinco años, me resulta muy triste terminar mi relación laboral de esta manera.

Durante mucho tiempo me sentí capaz de aportar y tuve etapas en las que considero que demostré ser una buena trabajadora. Por eso mismo me resulta difícil observar dónde me encuentro actualmente y comparar mi situación con la trabajadora que fui durante años anteriores.

No con
