---
title: "Editar logo y sentadilla"
conversation_id: "6a95fb6e-31e4-83e9-a4a3-9ad5f9fab8c9"
type: "chatgpt"
project_id: "g-p-6a03602663008191b5d8ab97a83e1d56"
area: "02 - Personal/Otros"
updated_at: 1788383759.301
archived: false
export_complete: true
tags: [conversacion-ai, jarvis-import]
---

# Editar logo y sentadilla

- ID: `6a95fb6e-31e4-83e9-a4a3-9ad5f9fab8c9`
- Tipo: `chatgpt`
- Proyecto: `g-p-6a03602663008191b5d8ab97a83e1d56`
- Estado: `activa`

## Conversación

### Marlon

Por favor agarra este logo de center fitt solo el logo y agréganos en la esquina haciendo una sentadilla Jericka y mi persona pero con ropa negra por favor nos puede agregar sin que se vea forzado que se vea estético

[User attached 3 images; image contents were not included]

### Marlon

Pero si nos pones en cada esquina y por favor ponerme a mi es una esquina y a ella en la otra esquina para que el logo quede en medio pero misma foto que se parezca más a mi y en la misma posición que salgo en esta foto

[User attached 2 images; image contents were not included]

### Marlon

Ahora una con igual pero con esta imagen pero que se vea mi rostro y tendría que bajar mi mano

[User attached 2 images; image contents were not included]

### Marlon

Me gusta, pero me puedes hacer un poquito, un poquito, un poquito más delgado, con más tipo el físico de Cristiano Ronaldo?

### Marlon

Ahora con las mismas fotos que tienes ahorita, pero un tipo diseño animado. Obviamente con ropa negra, ¿no?

[User attached 1 image; image contents were not included]

### Marlon

Queremos esta misma imagen, pero que no salga esa parte, adhiérela, que se vea obviamente bien. Entonces, esta parte que te estoy señalando con verdecito, que desaparezca y solo mantén todo lo demás, que obviamente tendrías como que centrar, acomodar un poco el logo, ¿no? pero que se vea bien distinguido como lo estamos haciendo hasta ahora, ¿no?

[User attached 1 image; image contents were not included]

### Marlon

Ah está hazle el mismo cambio

[User attached 1 image; image contents were not included]

### Marlon

No la misma imagen pero borra la parte del logo que te mencioné anteriormente, quiero la misma foto pero sin la parte que te marqué aquí

[User attached 2 images; image contents were not included]

### Marlon

Pero la quiero hiperrealista como la foto que te mandé. No la quiero animada ahora. Ahora la quiero realista como la que te estoy mandando, pero sin la parte del logo que te señalo.

[User attached 1 image; image contents were not included]

### Marlon

quiero que hagas la misma fotografía hiperrealista pero retirando la zona que te estoy dibujando, por favor.

[User attached 1 image; image contents were not included]

### Marlon

Igual que en las fotos anteriores, también retira esta parte del logo, centra un poco más el Center Fit, obviamente que quede bien, que quede estético, que no se vea mal diseñado y quiero todo lo mismo, todo lo que está ahí igual como lo hemos dejado, ¿no? Solamente retirando esta parte que te estoy diciendo.

[User attached 1 image; image contents were not included]

### Marlon

Por favor ahora edita mis planes con este logo nuevo por favor

[User attached 2 images; image contents were not included]
