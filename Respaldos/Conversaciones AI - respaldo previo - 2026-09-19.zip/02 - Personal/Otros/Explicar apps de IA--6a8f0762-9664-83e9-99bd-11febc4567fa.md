---
title: "Explicar apps de IA"
conversation_id: "6a8f0762-9664-83e9-99bd-11febc4567fa"
type: "chatgpt"
project_id: "g-p-6a03602663008191b5d8ab97a83e1d56"
area: "02 - Personal/Otros"
updated_at: 1787777574.777
archived: false
export_complete: true
tags: [conversacion-ai, jarvis-import]
---

# Explicar apps de IA

- ID: `6a8f0762-9664-83e9-99bd-11febc4567fa`
- Tipo: `chatgpt`
- Proyecto: `g-p-6a03602663008191b5d8ab97a83e1d56`
- Estado: `activa`

## Conversación

### Marlon

ayudame  aqui no entiendo que deberia decirle o para que sirve estas apps?

[User attached 1 image; image contents were not included]

### Asistente

Sí. Lo que estás viendo **no es el Gem normal de siempre**. Es una función experimental nueva de **Google Labs dentro de Gemini**, impulsada por **Opal**, que permite crear pequeñas aplicaciones de IA sin programar, simplemente describiendo lo que quieres que hagan. Google las llama **“AI mini-apps” o workflows**. citeturn140292search7turn140292search2

En tu captura estás probando **Recipe Genie**. Arriba a la izquierda aparece el `Original prompt`, que básicamente dice: “una app recibe una foto de alimentos, identifica los ingredientes y propone varias recetas”. Después Google convirtió esa idea automáticamente en un flujo:

**Provide Ingredients → Generate Recipes → Output**

Eso es lo interesante. No solo le preguntas algo a Gemini: **estás construyendo una miniaplicación reutilizable**.

Por ejemplo, donde ahora dice *“Click + to upload an image of your fridge…”*, tú podrías subir una foto de comida y la aplicación analizaría la imagen, extraería ingredientes, ejecutaría el siguiente paso y finalmente mostraría las recetas. No necesitas decirle gran cosa ahí porque estás **ejecutando una app que otra persona ya creó**. Puedes pulsar `Skip` para probarla sin fotografía, o escribir ingredientes en la caja inferior.

La diferencia importante para entenderlo es esta:

| Herramienta | Para qué sirve |
|---|---|
| **Gem tradicional** | Le das personalidad, conocimientos e instrucciones a Gemini. Es como crear un asistente especializado. |
| **Gem de Google Labs / Opal** | Construyes una **mini-app con pasos**: entrada → procesamiento → acciones → resultado. |
| **Remix** | Copias una app existente y la transformas para tu necesidad. |
| **Advanced Editor** | Ves y modificas el flujo interno de la mini-app paso por paso. |
| **Steps** | Son las acciones que realizará automáticamente la aplicación. |

Google confirma precisamente esa distinción: los Gems normales sirven para guardar objetivos, preferencias e instrucciones repetitivas, mientras que estos **Gems experimentales de Labs permiten crear y editar workflows completos mediante lenguaje natural**. citeturn140292search0turn140292search7

Y aquí viene lo que probablemente te va a interesar mucho más que Recipe Genie: **puedes crear tus propias aplicaciones.**

Por ejemplo, para **Center Fitt**, podrías decirle algo como:

:::writing{variant="document" id="58341" title="Prompt para crear Center Fitt Coach"}
Create an AI mini-app for Center Fitt.

The app should:

1. Ask for the student's training goal.
2. Ask for training experience: beginner, intermediate or advanced.
3. Ask how many days per week the student can train.
4. Ask what equipment is available.
5. Allow the user to upload training documents or exercise images.
6. Generate a personalized training routine.
7. Organize the routine by day, exercise, sets, repetitions and rest time.
8. Explain each exercise in simple language.
9. Provide alternative exercises when equipment is unavailable.
10. Show a final clean workout card that can be shared with the student.

The app should prioritize proper exercise technique, gradual progression and safe training.
:::

Entonces podría convertirlo en algo parecido a:

**Datos alumna → Objetivo → Nivel → Equipamiento → Elegir ejercicios → Construir rutina → Mostrar ficha**

Y esto encaja especialmente bien con el material de entrenamiento que ya tienes; por ejemplo, tus archivos contienen rutinas por músculos como glúteos, espalda, bíceps, tríceps, etc. fileciteturn0file4 fileciteturn0file13 fileciteturn0file3

También podrías hacer cosas muchísimo más cercanas a tus otros proyectos: una **mini-app para incidencias logísticas**, otra para analizar facturas de mantenimiento, una para Manito, otra que convierta datos de rutas en reportes, o incluso una para generar cápsulas de ejercicios de Center Fitt.

La parte que yo tocaría ahora en tu pantalla es **`Open Advanced Editor`**. Ahí es donde vas a entender de verdad la herramienta porque vas a ver cómo Google construyó esos tres pasos. Si me mandas una captura de lo que aparece al entrar allí, te explico **cada botón como para niño** y después podemos hacer nuestra primera mini-app desde cero. citeturn140292search7

### Marlon

&#x20;guiame paso a paso un ejmplo para realizar un prueba y aprender

[User attached 1 image; image contents were not included]

### Asistente

Sí. En esta pantalla ya estás en el **editor visual** de una mini-app. Para aprender, conviene que primero **no cambies nada**: vamos a probar la que ya está hecha y entender qué hace cada bloque.

Mira tu diagrama de izquierda a derecha. Los dos bloques amarillos son las **entradas**: `Product Name` pide el nombre del producto y `Describe Target Audience` pide a quién quieres venderle. Luego `Research Product` investiga el producto; `Generate Ad Text` escribe el anuncio; `Generate Video Description` prepara la idea/guion visual; `Generate Video` intenta crear el video; y al final `Generate Ad Campaign` junta todo en una salida final.

Hagamos una prueba sencilla con algo ficticio para que no compliquemos el ejercicio.

### Paso 1: Product Name

Ahora mismo, en la derecha tienes abierto **Product Name**. En la caja que dice:

`Type or upload your response`

escribe simplemente:

**Botella térmica deportiva de 1 litro**

Luego pulsa la **flecha morada ➜**.

No toques todavía nada más.

### Paso 2: Describe Target Audience

Después debería activarse el segundo bloque amarillo: **Describe Target Audience**.

Cuando aparezca su cuadro para escribir, pon:

**Jóvenes de 18 a 30 años que entrenan en gimnasio y quieren mantener su agua fría durante varias horas.**

Pulsa nuevamente la flecha.

A partir de aquí empieza lo interesante: ya no eres tú quien escribe todo.

### Paso 3: observa `Research Product`

Cuando llegue a **Research Product**, fíjate en tu diagrama: debajo del bloque aparecen `Search Web` y `Get Webpage`.

Eso significa que esa etapa tiene herramientas para **buscar información en Internet**.

El concepto que quiero que memorices es:

**INPUT → IA/TRABAJO → OUTPUT**

En este ejemplo:

**Nombre del producto + público → investigar → escribir anuncio → crear concepto de video → video → campaña**

Es prácticamente una línea de producción.

### Paso 4: no corras; abre cada resultado

En la columna derecha verás cosas como:

`Research Product`  
`Generate Ad Text`  
`Generate Video Description`  
`Generate Video`  
`Generate Ad Campaign`

Cuando uno termine, haz clic sobre su barra para desplegarlo.

Primero abre **Research Product**.

Ahí quiero que observes qué información encontró. No importa todavía si está perfecta. Estamos aprendiendo cómo **un paso alimenta al siguiente**.

Después abre **Generate Ad Text**. Probablemente te mostrará algo parecido a un texto publicitario.

Luego abre **Generate Video Description**. Ahí debería aparecer una descripción de cómo tendría que verse el anuncio en video.

Después vendría **Generate Video**.

Y finalmente **Generate Ad Campaign**, que combina los resultados.

### Lo importante de tu pantalla

Las líneas punteadas que ves entre los bloques son fundamentales.

Por ejemplo, fíjate que:

**Product Name ─ ─ ─ → Research Product**

pero también esa información va hacia otros pasos.

Eso significa:

> “El resultado o dato de este bloque puede ser utilizado por aquel otro bloque.”

Es exactamente la lógica que después podríamos utilizar para construir algo útil para ti.

Por ejemplo:

**Nombre del cliente**  
↓  
**Buscar información**  
↓  
**Analizar requerimiento**  
↓  
**Crear propuesta**  
↓  
**Crear correo**  
↓  
**Generar informe**

O para Center Fitt:

**Objetivo de alumna + experiencia + disponibilidad**  
↓  
**Seleccionar ejercicios**  
↓  
**Construir rutina**  
↓  
**Revisar volumen semanal**  
↓  
**Crear ficha para alumna**

Tu material actual ya tiene ejercicios organizados por grupos musculares, series y repeticiones, así que ese tipo de flujo podría alimentarse con bastante información existente. Por ejemplo, el archivo de glúteos contiene sentadilla, peso muerto rumano, hip thrust y otros ejercicios con sus rangos de series y repeticiones. fileciteturn0file4

### Tu misión ahora

Haz solamente esto:

**1. Product Name:**  
`Botella térmica deportiva de 1 litro`

**2. Target Audience:**  
`Jóvenes de 18 a 30 años que entrenan en gimnasio y quieren mantener su agua fría durante varias horas.`

**3. Dale a ejecutar.**

**4. Espera hasta que llegue a `Research Product`.**

Cuando veas que avanzó o te aparezca algo nuevo, mándame **una captura de esa pantalla**.

Ahí seguimos con el siguiente nivel: te voy a enseñar a **abrir un bloque y modificar su instrucción**, que es cuando empiezas realmente a construir la app y no solamente a utilizarla.

### Marlon

[User attached 1 image; image contents were not included]

### Asistente

Perfecto 👍. Ya avanzó. En tu captura, **`Product Name` y `Describe Target Audience` ya están completados** y ahora **`Research Product` está trabajando** — por eso arriba ves la barra de progreso y aparece el botón **Stop**.

Por ahora **no pulses nada** y no le des a los ▶️ de la derecha.

Lo que está ocurriendo es:

**🟨 Tus datos**
`Product Name`
+
`Target Audience`
↓
**🟦 Research Product ← ESTÁ AQUÍ**
↓
`Generate Ad Text`
+
`Generate Video Description`
↓
`Generate Video`
↓
**🟩 Generate Ad Campaign`

Cuando termine `Research Product`, debería continuar con los siguientes pasos según cómo esté configurada esta app.

### Qué quiero que hagas ahora

Espera a que termine. Cuando desaparezca **Stop** o veas que `Research Product` terminó y comienza `Generate Ad Text`, haz clic en la **flechita ˅ del lado izquierdo de `Research Product`** para desplegarlo.

Ahí probablemente podremos ver **qué recibió → qué hizo → qué produjo**.

📸 **Mándame captura de `Research Product` abierto.**

Ese será nuestro **Paso 2**. Te voy a explicar qué significa su contenido y, después de terminar esta prueba, hacemos algo mucho más divertido: **Remix → modificamos esta aplicación nosotros mismos → rompemos algo a propósito → lo arreglamos → y finalmente construimos una mini-app sencilla desde cero.**

Así vas a entender Opal por lógica, no memorizando botones.

### Marlon

[User attached 1 image; image contents were not included]

### Asistente

¡Exacto! Ya lo tenemos. 👌 Y esta captura sirve muchísimo porque ahora puedes ver **qué hizo realmente el bloque `Research Product`**.

Ese bloque tomó tu entrada de **“botella térmica deportiva”**, buscó información y generó una investigación. En lo que muestras incluso comparó marcas como CamelBak, Hydro Flask y Klean Kanteen, señaló fortalezas, casos de uso y terminó con recomendaciones de compra.

Eso significa que ya entendiste tu primer concepto fundamental:

**Entrada → bloque inteligente → resultado**

Ahora **todavía no modifiques nada**. Arriba sigue apareciendo `Stop` y la barra está avanzando, así que el flujo **todavía está ejecutándose**.

Déjalo terminar. 🚀

Después deberían ejecutarse:

`Research Product` ✅  
↓  
`Generate Ad Text`  
↓  
`Generate Video Description`  
↓  
`Generate Video`  
↓  
`Generate Ad Campaign`

Cuando termine todo, **abre `Generate Ad Text`** con la flechita de la izquierda y mándame esa captura.

Ahí te voy a enseñar algo todavía más importante: cómo el segundo bloque **utiliza el resultado del primero**. Una vez entendamos eso, nos vamos a `Remix` y empezamos a tocar las tripas de la app nosotros mismos.

### Marlon

solo pregunta tanto se tarda y porque?

### Asistente

Sí, puede tardar bastante, sobre todo en ese ejemplo, porque no es una sola respuesta de Gemini: son **varios pasos encadenados**.

En tu caso está haciendo algo parecido a esto:

**1. Investiga el producto en web** → puede tardar porque busca y compara fuentes.  
**2. Genera el texto publicitario** → usa lo investigado.  
**3. Genera la descripción del video** → crea el concepto visual.  
**4. Genera el video** → normalmente es lo más lento, porque generar video consume mucho más procesamiento que generar texto.  
**5. Arma la campaña final** → combina los resultados anteriores.

Entonces sí: **es normal que una app así tarde varios minutos**. Si incluye generación de video, puede tardar bastante más que una conversación normal de Gemini.

También depende de la carga de Google en ese momento y del modelo que esté usando cada bloque. Para aprender, luego podemos hacer una mini-app mucho más simple, de solo **3 pasos**, que responda en segundos y te permita entender la lógica sin esperar tanto.

### Marlon

pero veo que termino y que puedo darle stop

### Asistente

Sí, puedes darle **Stop** si ya ves que terminó lo que querías probar y no necesitas que siga ejecutando más pasos.

Ese botón no “borra” lo que ya hizo. Solo **detiene la ejecución actual** del flujo. Lo que ya generó hasta ese momento normalmente queda visible.

En tu caso, como ya viste el resultado de `Research Product`, puedes darle Stop sin problema si no quieres esperar a que siga con el anuncio, la descripción del video y el video.

Y de hecho, para aprender, te conviene: paramos ahí, revisamos ese bloque, y luego hacemos una prueba más corta para que no pierdas tiempo.

### Marlon

&#x20;no se me desespera jaja creo que la cague

[User attached 1 image; image contents were not included]

### Asistente

No, no la cagaste 😄. En la captura parece que simplemente **reiniciaste o volviste al estado inicial del flujo**: `Product Name` y `Describe Target Audience` aparecen otra vez como entradas pendientes, y los demás pasos están listos para ejecutarse después.

El botón **Stop** sigue arriba porque la app parece estar en modo de ejecución, pero no veo que hayas roto nada. Lo más probable es que al detenerla o tocar algún paso, el flujo haya quedado esperando otra vez las entradas.

Haz esto: **no pulses Remix ni ningún bloque azul todavía**. Abre `Product Name`, escribe de nuevo algo corto como `Botella térmica deportiva`, envíalo; luego abre `Describe Target Audience`, pon `Personas que entrenan en gimnasio`, envíalo y deja que corra.

Si quieres evitar otra espera eterna, en cuanto termine **Research Product**, ahí sí le damos **Stop** y pasamos a aprender a editar el flujo. Así no esperamos video ni campaña completa. 😅

### Marlon

[User attached 1 image; image contents were not included]

### Asistente

😂 Ahora sí: **ya se detuvo correctamente**.

Fíjate en la señal clave arriba: antes decía **`Stop`**, ahora dice **`Start`**. Eso significa que **ya no está ejecutando nada**.

Y lo mejor: **no perdiste el resultado de `Research Product`**. Lo estás viendo ahí mismo con sus recomendaciones y referencias. Así que todo bien.

Ahora **no le des Start**. Ya aprendimos la primera parte:

**Entradas → investigación → resultado.**

El siguiente paso que te recomiendo es salir de esta prueba y aprender a **editar la aplicación**. Ahí empieza lo bueno: vamos a agarrar este ejemplo, hacer **Remix**, quitarle toda esa vaina de video que tarda una eternidad 😂 y dejar una mini-app de 3 bloques para que veas cómo se construye.

Si quieres, pulsa **`Remix`** arriba y mándame lo que te aparezca. Te voy guiando **clic por clic**, sin adelantarnos.

### Marlon

no entendi  si quiero aprender a editar la app a donde debo ir?

### Asistente

Para aprender a editarla, ve a **Remix**.

En tu pantalla está arriba a la derecha. Haz clic ahí.

La lógica es esta:

**Remix = hacer una copia editable de esa app.**

La original no la modificas; trabajas sobre tu propia versión.

Después de darle a **Remix**, deberías entrar al editor con los bloques conectados. Ahí podremos:

- cambiar textos/instrucciones,
- borrar pasos,
- agregar nuevos bloques,
- reconectar el flujo,
- probar cada parte.

Haz clic en **Remix** y mándame una captura de lo que te aparezca. Te guío clic por clic.

### Marlon

[User attached 1 image; image contents were not included]

### Asistente

¡Ahora sí! 😄 **Esta es la pantalla correcta para aprender a editar.** Estás en `Video Marketer Remix — Draft` y arriba tienes seleccionado **Editor**.

Antes de tocar nada, mira tu pantalla como si fuera LEGO:

- 🟨 **User Input** = cosas que escribe la persona.
- 🟦 **Generate** = cosas que hace la IA.
- 🟩 **Output** = resultado que verá la persona.
- ➖ **Líneas punteadas** = qué información pasa de un bloque a otro.

Arriba tienes justamente los botones para agregar esos tipos de bloques: **User Input | Generate | Output | Add Assets**.

### Primera práctica: vamos a editar UN bloque

No vamos a borrar ni agregar nada todavía.

Haz clic **una sola vez sobre el bloque azul `Generate Ad Text`** que está en el centro.

Ese bloque actualmente dice, más o menos:

> Generate the ad text based on the product's specifications and value proposition and the target audience.

Es decir: **“Genera el texto publicitario usando la información del producto y el público objetivo.”**

Al hacer clic debería abrirse la configuración de ese paso, probablemente en el panel derecho.

📸 **Haz únicamente clic en `Generate Ad Text` y mándame la siguiente captura.**

Ahí te explico cada campo que aparezca y modificamos nuestra **primera instrucción de verdad**. No avances más todavía.

### Marlon

[User attached 1 image; image contents were not included]

### Asistente

¡Eso! Ahora estás viendo **las tripas del bloque**. 😎

Mira el panel derecho. Seleccionaste `Generate Ad Text` y ahora podemos ver cómo está construido.

### Lo que estás viendo

Arriba dice **Gemini 3.1 Flash Lite**. Ese es el **modelo de IA que ejecuta específicamente este paso**.

Debajo está **Prompt**. Eso es el cerebro del bloque. Actualmente le dice, en resumen:

> Eres un experto en publicidad. Crea un anuncio atractivo de exactamente dos líneas para este producto y público objetivo...

Luego vienen instrucciones `Step by Step`, que le indican cómo razonar la tarea y qué formato entregar.

Y abajo está lo más importante. 👇

Ves tres pequeñas etiquetas:

🟨 `Product Name`  
🟨 `Target Audience`  
🟦 `Research Product`

**Esas son variables.**

Significa que este bloque no tiene la información escrita permanentemente. Cuando alguien use la app, recibe automáticamente:

**lo que escribió en Product Name**  
+ **lo que escribió en Target Audience**  
+ **lo que descubrió Research Product**

y se lo entrega a Gemini para generar el anuncio.

Por eso existen las líneas punteadas del diagrama. 💡

### Ahora hagamos nuestra primera modificación

Vamos a hacer algo pequeñito para que veas inmediatamente el efecto.

En el panel derecho, dentro de **Prompt**, haz clic sobre el texto. No borres las etiquetas `Product Name`, `Target Audience` ni `Research Product`.

Busca la parte que dice que el anuncio debe ser:

> `exactly two lines long`

y cámbiala para pedir:

**un anuncio de 3 líneas, en español, con tono enérgico y un llamado a la acción al final.**

No necesitas traducir todo el prompt todavía.

Luego fíjate arriba: debería aparecer `Saved` cuando guarde automáticamente.

### ¿Qué acabamos de aprender?

Tu app funciona conceptualmente así:

**BLOQUE 1**  
Usuario escribe producto  
⬇️

**BLOQUE 2**  
Usuario describe público  
⬇️

**BLOQUE 3**  
Gemini investiga  
⬇️

**BLOQUE 4 — EL QUE ESTAMOS EDITANDO**  
Prompt + variables → Gemini → anuncio

Y aquí aparece una idea muy potente: **cada bloque puede tener su propio prompt y hasta su propio modelo.**

Haz solo ese cambio y mándame captura. Después te enseño algo todavía más importante: **cómo agregar nosotros un bloque nuevo desde cero** sin destruir los que ya existen.

### Marlon

[User attached 1 image; image contents were not included]

### Asistente

Sí, **lo cambiaste**, pero hay un detalle importante que justamente sirve para aprender. 😄

Arriba cambiaste la instrucción a:

> anuncio de **3 líneas**, en español, tono enérgico y llamado a la acción.

Pero más abajo, en **Step by Step Instructions**, quedaron las instrucciones antiguas:

- Paso 2: escribe la **primera línea**.
- Paso 3: escribe la **segunda línea**.
- Paso 4: verifica que tenga **exactamente dos líneas**. ❌

Entonces ahora el prompt **se contradice a sí mismo**. Gemini recibe: “haz 3 líneas” y después “asegúrate de que sean exactamente 2”.

### Vamos a arreglarlo

Cambia solamente los pasos **2, 3 y 4** por esto:

```text
2. Write the first line of the ad text, highlighting the main benefit of the product.
3. Write the second line, connecting the product with the needs of the Target Audience.
4. Write the third line in Spanish with an energetic call to action.
5. Check that the final ad is exactly three lines long, written in Spanish, energetic, concise, and relevant to the Target Audience.
```

Luego espera a que arriba vuelva a aparecer **Saved**.

💡 Y acabas de aprender una regla importantísima para construir estas apps:

**El prompt completo tiene que ser coherente.**

No basta con cambiar una frase. Si más abajo hay instrucciones que contradicen el cambio, la IA puede confundirse o priorizar una sobre otra.

Cuando lo tengas en `Saved`, **no ejecutes todavía**. El siguiente ejercicio será más interesante: vamos a añadir **un bloque nuevo desde cero** y conectarlo a este flujo.

### Marlon

claro porque no me das el promt completo en ingles en ves de hacerme sufrir

### Asistente

Tienes razón 😅. Para que no estés parchando línea por línea, mejor reemplaza **todo el prompt** por uno completo y coherente en inglés.

:::writing{variant="document" id="48217" title="Prompt completo para Generate Ad Text"}
You are an expert advertising copywriter specialized in creating short, compelling ad copy for specific target audiences.

Your task is to generate a concise 3-line advertisement for a given product, using the Product Name, Target Audience, and Product Research provided below.

The ad must:
- Be written entirely in Spanish.
- Be exactly 3 lines long.
- Use an energetic, persuasive, and modern tone.
- Highlight the product's most relevant benefit for the target audience.
- Connect the product with a real need, desire, or problem of the target audience.
- End with a clear and energetic call to action.
- Avoid unnecessary explanations, titles, bullet points, or additional text.

# Step-by-Step Instructions

1. Review the Product Name, Target Audience, and Product Research.
2. Identify the strongest and most relevant benefit of the product for the Target Audience.
3. Write the first line to capture attention and introduce the main benefit.
4. Write the second line to connect the product with the needs or interests of the Target Audience.
5. Write the third line as a strong and energetic call to action.
6. Verify that the final response is exactly 3 lines long and entirely in Spanish.
7. Output only the final 3-line advertisement.

Product Name:
[Product Name]

Target Audience:
[Target Audience]

Product Research:
[Research Product]
:::

Ojo con una cosa importante: **no escribas manualmente `[Product Name]`, `[Target Audience]` y `[Research Product]` si Opal usa las etiquetas de colores que ya tienes conectadas.** Mantén esas etiquetas/variables originales en la parte inferior del prompt, porque son las que traen los datos de los otros bloques.

Haz esto: **Ctrl+A dentro del prompt → pega el texto nuevo → vuelve a insertar o conserva las tres variables de abajo → espera que diga `Saved`.**

Con eso ya queda limpio, sin contradicciones y mucho más fácil de entender.

### Marlon

donde di save?

### Asistente

No tienes que darle a ningún botón **Save** 😄. Me expresé mal antes.

En tu captura, arriba aparece **`Saved`** automáticamente. Eso significa que **Opal guarda los cambios solo**.

Así funciona:

**Escribes/modificas el prompt → esperas unos segundos → arriba aparece `Saved` → listo. ✅**

En tu captura anterior ya decía **Saved**, así que **tu modificación ya estaba guardada**.

No pulses **Publish** todavía. `Publish` es otra cosa: sirve para **publicar/compartir la app**, no para guardar.

Ahora que ya está guardado, podemos seguir con el siguiente paso: **crear nuestro primer bloque nuevo desde cero**.

### Marlon

ok

### Asistente

Perfecto 😎. Ahora vamos a aprender **a crear un bloque nuevo**, pero uno sencillo.

### Paso 1 — Crear un bloque

En la parte superior del editor tienes:

**User Input | ✨ Generate | Output | Add Assets**

Haz clic en **✨ `Generate`**.

No toques nada más todavía.

Debería aparecer un **nuevo bloque azul** en el diagrama o abrirse una ventana para configurarlo.

📸 Cuando lo hagas, mándame captura de lo que aparece y seguimos desde ahí. Así lo construimos juntos clic por clic.

### Marlon

me desperas jaja siento que podemos avanzar mas rapido diciendome a donde voy pega esto y asi es para aprender para grabarme los paso porque de esta forma aprendo&#x20;

[User attached 1 image; image contents were not included]

### Asistente

Sí, así avanzamos mejor. Vamos en modo **“haz clic aquí → pega esto → dime qué ves”**. Sin teoría larga.

Ahora mismo ya estás dentro del bloque **Generate Ad Text** y ya lo editaste. El siguiente paso es crear un bloque nuevo.

Haz esto:

1. Arriba, en la barra del editor, haz clic en **Generate**.
2. Cuando aparezca el nuevo bloque azul, haz clic sobre él.
3. En el panel derecho, busca el campo del **Prompt**.
4. Reemplaza todo el contenido por este prompt:

:::writing{variant="document" id="41382" title="Prompt para nuevo bloque"}
You are a marketing assistant.

Using the Product Name, Target Audience, and Product Research provided below, generate 3 short advertising ideas for social media.

Requirements:
- Write everything in Spanish.
- Each idea must have:
  - A short hook.
  - One main benefit.
  - One call to action.
- Keep each idea concise.
- Do not add explanations.
- Output only the 3 ideas.

Product Name:

Target Audience:

Product Research:
:::

5. Abajo del prompt, donde puedas insertar variables, agrega:
   - `Product Name`
   - `Target Audience`
   - `Research Product`

6. Espera a que arriba diga **Saved**.

7. Renombra ese bloque como:  
**Generate Social Ideas**

Con eso habrás creado tu primer bloque nuevo desde cero.

Luego me mandas captura y te digo inmediatamente:

**“ahora conecta este bloque con este otro”**

y seguimos rápido.

### Marlon

[User attached 1 image; image contents were not included]

### Asistente

¡Sí! **Perfecto.** Ahí está el bloque nuevo `Generate` y a la derecha tienes el campo **Prompt** vacío.

Haz esto ahora, rápido:

### 1. Haz clic en `Type your prompt here...`

Pega **todo esto**:

:::writing{variant="document" id="31674" title="Generate Social Ideas"}
You are a creative social media marketing expert.

Using the information provided, create 3 different advertising ideas for social media.

Requirements:
- Write entirely in Spanish.
- Create exactly 3 ideas.
- Each idea must include:
  1. A short and catchy hook.
  2. The main product benefit.
  3. A short call to action.
- Keep the ideas concise and energetic.
- Adapt the message to the Target Audience.
- Do not invent product characteristics that are not supported by the Product Research.
- Output only the 3 advertising ideas.

Product Name:
@Product Name

Target Audience:
@Target Audience

Product Research:
@Research Product
:::

### 2. IMPORTANTE con los `@`

Cuando llegues a:

`@Product Name`

escribe **@** y debería aparecerte un menú. Ahí selecciona el bloque **Product Name**.

Haz lo mismo con:

`@Target Audience` → selecciona **Describe Target Audience / Target Audience**

`@Research Product` → selecciona **Research Product**

Cuando lo haces correctamente, **no queda como texto normal**: debería convertirse en una pequeña etiqueta de color como las que viste antes.

Eso además hará las conexiones automáticamente en el mapa.

### 3. Después

Espera que arriba diga **Saved**.

**No conectes líneas manualmente todavía. No le des Publish.**

Cuando hayas insertado los tres `@`, mándame captura. El siguiente paso será **renombrar `Generate` → `Generate Social Ideas` y probar solamente nuestro bloque nuevo**.

### Marlon

[User attached 1 image; image contents were not included]

### Asistente

Perfecto, el prompt **sí quedó pegado** y arriba dice `Saved`. Pero falta justo lo importante: **las 3 variables no se insertaron**. Por eso nuestro bloque `Generate` todavía está solito, sin líneas punteadas conectándolo a los otros bloques.

Haz esto directamente:

1. Ve al **final del Prompt**, después de `Output only the 3 advertising ideas.`
2. Presiona **Enter** dos veces.
3. Escribe:
   `Product Name:`
4. Presiona Enter y escribe solamente **`@`**.
5. Te debería salir un menú. Selecciona **Product Name**. Debe aparecer como una pastillita/etiqueta amarilla, no como texto normal.
6. Debajo haz lo mismo con **Target Audience:** → `@` → selecciona **Target Audience / Describe Target Audience**.
7. Finalmente **Product Research:** → `@` → selecciona **Research Product**.

Te debería quedar visualmente parecido a:

```text
Product Name:
[🟨 Product Name]

Target Audience:
[🟨 Target Audience]

Product Research:
[🟦 Research Product]
```

En cuanto insertes esas etiquetas, fíjate en el mapa de la izquierda: deberían aparecer **nuevas líneas punteadas hacia nuestro bloque `Generate`**.

Eso es precisamente lo que quiero que aprendas aquí: **`@` = traer información de otro bloque.**

Haz los tres `@` y me mandas captura. Después **renombramos el bloque, lo conectamos a una salida y lo probamos**. Vamos rápido. 🚀

### Marlon

[User attached 1 image; image contents were not included]

### Asistente

Vas bien, pero en esta captura hay un detalle: **los `@Product Name`, `@Target Audience` y `@Research Product` quedaron como texto normal**, no como variables reales. Por eso el bloque nuevo `Generar` sigue sin líneas punteadas conectadas.

Haz esto, rápido:

1. En el panel derecho, borra solo estas tres líneas:
   - `@Product Name`
   - `@Target Audience`
   - `@Research Product`

2. Debajo de `Product Name:` escribe solamente `@`.
3. Espera a que aparezca el menú y **haz clic en “Nombre del producto / Product Name”**. Tiene que quedar como una pastillita/etiqueta, no texto simple.
4. Repite:
   - `Target Audience:` → `@` → selecciona **Describa el público objetivo**
   - `Product Research:` → `@` → selecciona **Producto de investigación / Research Product**

Cuando esté correcto, deberías ver algo visualmente parecido a:

`Product Name:`  
🟨 **Nombre del producto**

`Target Audience:`  
🟨 **Describa el público objetivo**

`Product Research:`  
🟦 **Producto de investigación**

Y además aparecerán **3 líneas punteadas entrando al bloque nuevo `Generar`**.

No cambies nada más. Cuando veas esas líneas conectadas, ya aprendiste una de las cosas más importantes de Opal:

**`@` + seleccionar un bloque = usar la información de ese bloque.**

Después de eso hacemos de una vez: **renombrar → crear Output → conectar → probar**, sin frenarnos a cada paso.

### Marlon

[User attached 1 image; image contents were not included]

### Asistente

Sí, sigue igual: esos `@Product Name`, `@Target Audience` y `@Research Product` siguen siendo texto plano. Por eso el bloque nuevo `Generar` no tiene conexiones.

Haz exactamente esto:

1. En el panel derecho, borra las tres líneas que empiezan con `@`.
2. Debajo de `Product Name:` escribe solo `@`.
3. Espera a que aparezca una lista y selecciona **Nombre del producto**.
4. Debajo de `Target Audience:` escribe `@` y selecciona **Describa el público objetivo**.
5. Debajo de `Product Research:` escribe `@` y selecciona **Producto de investigación**.
6. Verifica que las referencias se vean como **etiquetas/pastillas**, no como texto.
7. Mira el diagrama: deben aparecer líneas punteadas entrando al bloque `Generar`.

Cuando veas esas tres conexiones, ya quedó bien.

Después seguimos de una: **renombrar el bloque → crear un Output → conectarlo → probarlo**.

### Marlon

deja de esperar tanto siento que no me estas explicando bien es mejor decirme ve a nombre de producto en amarillo y coloca el nombre dle producto

[User attached 1 image; image contents were not included]

### Asistente

Sí, tienes razón. Desde ahora te lo voy a decir **exactamente como se ve en tu pantalla**, sin tanta vuelta.

Ahora mismo estás en **Nombre del producto** — el bloque amarillo de arriba a la izquierda está seleccionado y a la derecha ves el campo que dice:

**Enter the name of product**

Ahí escribe:

**Botella térmica deportiva**

Luego haz clic en el otro bloque amarillo de abajo:

**Describa el público objetivo**

Y escribe:

**Personas de 18 a 35 años que entrenan en gimnasio y quieren mantener su agua fría durante varias horas.**

Después me mandas captura y seguimos con el siguiente bloque. No vamos a tocar el bloque nuevo `Generar` todavía.

### Marlon

listo

### Asistente

Bien. Ahora ve al bloque azul de arriba que dice **Producto de investigación...**.

Haz clic ahí y, en el panel derecho, busca el prompt.

No cambies nada todavía. Solo ábrelo y dime qué te aparece, o mándame captura.

### Marlon

cual se claro

[User attached 1 image; image contents were not included]

### Asistente

Claro. **No toques el panel derecho todavía.**

Haz exactamente esto:

1. En el centro, busca el bloque azul que dice **`Generar`**.  
   Está **debajo de “Generar texto publicitario”** y arriba de “Generar descripción del...”.

2. Haz clic en ese bloque azul **`Generar`**.

3. Cuando se abra a la derecha, ahí sí vamos a configurar **nuestro bloque nuevo**.

Ese es el bloque que queremos editar ahora, no `Research Product`.

### Marlon

ok ya abrio cual es el promt

### Asistente

Pega este prompt completo en el bloque **Generar**:

:::writing{variant="document" id="54821" title="Prompt para bloque Generar"}
You are a creative social media marketing expert.

Using the information provided, create exactly 3 different advertising ideas for social media.

Requirements:
- Write entirely in Spanish.
- Create exactly 3 ideas.
- Each idea must include:
  1. A short and catchy hook.
  2. The main product benefit.
  3. A short call to action.
- Keep the ideas concise, clear, and energetic.
- Adapt the message to the target audience.
- Do not invent product characteristics that are not supported by the product research.
- Output only the 3 advertising ideas.

Product Name:

Target Audience:

Product Research:
:::

Después, debajo de cada uno de esos tres títulos, vamos a insertar la variable correcta con `@`.

Primero pega el prompt y dime cuando ya esté.

### Marlon

[User attached 1 image; image contents were not included]

### Asistente

Perfecto. **Ahora sí quedó bien.** 👌

Mira a la derecha: ya aparecen como etiquetas reales:

- 🟨 `Product Name`
- 🟨 `Describe Target Aud...`
- 🟦 `Research Product`

Eso significa que **el bloque nuevo ya está conectado a esos 3 datos**. Bien.

Ahora haz esto:

1. En el bloque nuevo azul que dice **`Generar`**, haz clic en el nombre.
2. Cámbialo por:
   **`Generar ideas para redes`**
3. Espera que arriba diga **Guardado**.
4. Luego arriba, en la barra, haz clic en **`Producción`**.
5. Se creará un bloque de salida nuevo.
6. Haz clic en ese bloque nuevo.
7. En su contenido, inserta con `@` el bloque **`Generar ideas para redes`**.

La lógica quedará así:

**Nombre del producto**  
+ **Público objetivo**  
+ **Investigación**  
↓  
**Generar ideas para redes**  
↓  
**Producción / Output**

Cuando crees el bloque de **Producción**, mándame captura y te digo exactamente qué pegar ahí.

### Marlon

&#x20;lo tuve que volver a colocar no se si esta guardando

[User attached 1 image; image contents were not included]

### Asistente

Sí, **ahora sí está guardado**. En tu captura, arriba se ve claramente **`Saved`**. ✅

Además veo que quedó bien:
- nombre del bloque: **Generar ideas en redes**
- prompt completo pegado
- variables conectadas como etiquetas:
  - `Product Name`
  - `Describe Target Aud...`
  - `Research Product`

Así que **no vuelvas a pegar nada**.

Opal guarda automáticamente. Solo revisa que arriba diga **Saved** antes de cambiar de bloque.

Ahora el siguiente paso es este: **arriba haz clic en `Producción`** para crear la salida donde vamos a mostrar las 3 ideas generadas.

### Marlon

no me sale

[User attached 1 image; image contents were not included]

### Asistente

Ya veo qué pasa. No es que esté fallando: **en ese buscador solo te aparecen pasos que Opal reconoce como disponibles para ese Output**, y tu bloque nuevo **`Generar ideas en redes` todavía no está entrando como paso seleccionable**.

Vamos directo:

1. Cierra ese buscador de `@`.
2. Vuelve al diagrama.
3. Haz clic en tu bloque azul **`Generar ideas en redes`**.
4. Mira si ese bloque tiene una **salida/conector en el lado derecho** y si aparece bien guardado.
5. Luego crea o abre otra vez **Output 1**.
6. En el prompt del Output escribe solo `@`.
7. Busca el nombre exacto **`Generar ideas en redes`**.

Si **no aparece**, entonces Opal no registró ese bloque como una salida utilizable todavía. En ese caso, lo más rápido es:

- cambia el tipo del bloque nuevo desde **Agent** a un bloque de generación normal/modelo de texto, parecido a `Generate Ad Text`, o
- duplica `Generate Ad Text` y reemplaza su prompt por el nuestro.

Para aprender sin perder tiempo, te recomiendo lo segundo: **duplicamos `Generate Ad Text`, lo renombramos `Generar ideas en redes`, pegamos nuestro prompt y listo**. Ese sí seguro aparecerá en `@` del Output porque Opal ya lo reconoce como paso de texto.

### Marlon

&#x20;esta en blanco de nuevo

[User attached 1 image; image contents were not included]

### Asistente

Sí, en esta captura **el bloque `Generar` volvió a quedar vacío**. No sigamos perdiendo tiempo pegando lo mismo.

Haz esto exacto:

1. Haz clic en el bloque azul **`Generar`** del centro.
2. A la derecha, arriba donde dice **`Agent`**, haz clic en la flechita.
3. Busca una opción de **modelo de texto / Gemini**, idealmente **Gemini 3.1 Flash Lite**, como el bloque `Generar texto publicitario`.
4. Selecciónala.

La razón: tu bloque nuevo está creado como **Agent**, mientras el bloque de texto original usa un modelo de generación. Para esta práctica solo necesitamos **texto**, no un agente.

**No pegues todavía el prompt.** Primero cambia `Agent` y mándame qué opciones te salen si no ves Gemini.

Además, Google indica que estas mini-apps de Labs/Opal siguen siendo experimentales, así que pueden aparecer comportamientos raros del editor. citeturn989907search0

### Marlon

[User attached 1 image; image contents were not included]

### Asistente

Perfecto. **Elige `Gemini 3 Flash`**.

Ese es el que te conviene para este bloque porque:
- es rápido,
- sirve bien para generar texto,
- y no necesitamos `Pro` para una tarea tan simple.

Haz clic en **Gemini 3 Flash**.

Después, en el campo del prompt, pega otra vez el prompt de las 3 ideas.

Cuando lo pegues, verifica que abajo queden las 3 referencias como etiquetas:
`Product Name`
`Describe Target Audience`
`Research Product`

Y recién ahí debería dejar de verse `(Empty)` en el bloque `Generar`.

Haz eso y dime si ya desapareció `(Empty)`.

### Marlon

[User attached 1 image; image contents were not included]

### Asistente

Perfecto, ya cambiaste el modelo a **Gemini 3 Flash**. ✅

Ahora veo que el bloque `Generar` sigue mostrando **(Empty)** porque todavía no tiene texto de instrucción, solo las 3 variables.

Haz esto exacto en el panel derecho:

1. Haz clic debajo de las tres etiquetas.
2. Pega este prompt:

:::writing{variant="document" id="57231" title="Prompt para Generar ideas"}
You are a creative social media marketing expert.

Using the Product Name, Target Audience, and Product Research provided above, create exactly 3 different advertising ideas for social media.

Requirements:
- Write entirely in Spanish.
- Create exactly 3 ideas.
- Each idea must include:
  1. A short and catchy hook.
  2. The main product benefit.
  3. A short call to action.
- Keep the ideas concise, clear, and energetic.
- Adapt the message to the target audience.
- Do not invent product characteristics that are not supported by the product research.
- Output only the 3 advertising ideas.
:::

3. Espera a que arriba diga **Saved**.
4. Mira el bloque `Generar`: debería dejar de decir **(Empty)**.

No toques `Output 1` todavía. Primero confirmemos que `Generar` ya dejó de estar vacío.

### Marlon

&#x20;no se si ves pero hay una opcion de voz y chat quizas alli tambien podamos darle las intrucciones mejor&#x20;

[User attached 1 image; image contents were not included]

### Asistente

Sí, **eso que ves abajo probablemente te conviene mucho más para aprender y editar rápido**.

La caja negra que dice **“Edita estos pasos”** es justamente para darle instrucciones a Opal en lenguaje natural. Google explica que estas mini-apps pueden **crearse y editarse describiendo lo que quieres con lenguaje natural**, sin tener que tocar manualmente cada bloque. citeturn827756search1

Y el **micrófono 🎤** te permite dictar esa instrucción en lugar de escribirla. Para ti puede ser más cómodo: le explicas lo que quieres y Opal intenta modificar el flujo.

Por ejemplo, en vez de todo lo que acabamos de hacer manualmente, en esa caja podrías escribir o dictar:

> “Crea un nuevo paso llamado Generar ideas en redes. Debe usar el nombre del producto, el público objetivo y la investigación del producto. Usa Gemini 3 Flash y genera exactamente 3 ideas publicitarias en español. Cada idea debe tener un gancho, beneficio principal y llamado a la acción. Después crea una salida que muestre esas tres ideas.”

Luego presionas la **flecha de enviar** a la derecha.

Ese método te enseña otra parte importante de Opal:

**Modo manual:** tú construyes y conectas bloques.  
**Modo conversación:** le describes el cambio a Opal y él intenta modificar el diagrama.

Yo haría ambos: aprendemos primero **qué significan los bloques**, pero para construir rápido usamos bastante esa caja de **“Edita estos pasos”**. Así no te hago sufrir pegando veinte cosas 😂.

Y sí: **en tu captura actual el bloque `Generar` todavía dice `(Empty)`**, así que en lugar de volver a pelear con él, podemos probar ahora mismo el cuadro de abajo y pedirle que **arregle ese bloque automáticamente**.

### Marlon

se quedo cargando ahora  creo que es empezar de nuevo

### Asistente

Sí, en este punto yo también prefiero **empezar limpio**. Ya quedó demasiado manoseado el remix y Opal se está poniendo inestable.

Hazlo así, rápido:

1. Vuelve atrás a la galería o a la app original.
2. Haz **Remix** otra vez.
3. En el nuevo remix, **no toques los bloques manualmente al inicio**.
4. Usa directamente la caja de abajo **“Edita estos pasos”** y pega o dicta esto:

> Crea una versión simple de esta app. Mantén solo tres entradas: nombre del producto, público objetivo e investigación del producto. Luego agrega un paso llamado “Generar ideas en redes” usando Gemini 3 Flash. Ese paso debe crear exactamente 3 ideas publicitarias en español, cada una con un gancho, un beneficio principal y una llamada a la acción. Finalmente crea una salida que muestre esas 3 ideas. Elimina los pasos de video y campaña final para que la app sea rápida.

5. Espera a que termine de reorganizar el flujo.

Eso te va a dejar una app mucho más simple y rápida para aprender:
**Entrada → Investigación → Ideas → Salida**

Y desde ahí sí avanzamos sin pelear con bloques vacíos.

### Marlon

&#x20;creo que sera de paso  a paso

[User attached 1 image; image contents were not included]

### Asistente

Sí, mejor **paso a paso**. Y la captura confirma algo importante: Opal te está diciendo:

**“Edits applied to steps. Please restart app to see new changes.”**

O sea: **los cambios sí se aplicaron**, pero tienes que reiniciar la app para verlos.

Haz esto:

1. En la parte derecha, donde ves la vista previa, pulsa **Start** o reinicia la app.
2. No edites nada todavía.
3. Mira si ahora aparece el flujo nuevo que le pedimos.
4. Si aparece, probamos solo una cosa a la vez.

La idea desde ahora será:

**Paso 1:** confirmar que el flujo cambió.  
**Paso 2:** probar entrada.  
**Paso 3:** probar investigación.  
**Paso 4:** probar “ideas en redes”.  
**Paso 5:** probar salida.

Así sí aprendes sin que Opal nos vuelva locos 😅.

### Marlon

&#x20;esta cargando

[User attached 1 image; image contents were not included]

### Asistente

Sí, ahora **sí está cargando la app nueva**. Y esta vez el flujo quedó mucho más limpio. 👍

Veo 3 entradas amarillas:
- `Nombre Del Producto`
- `Público Objetivo`
- `Investigación Del Produ...`

Luego un bloque azul:
- `Generate Advertising Id...`

Y al final uno verde:
- `Render Advertising Page`

Eso significa que la simplificación **sí funcionó**.

Ahora no toques el editor. Ve a la derecha, donde dice:

**Enter the name of your product**

y escribe:

**Botella térmica deportiva**

Después dale a la flecha azul de enviar.

Cuando pase a la siguiente pregunta, me dices qué te aparece y seguimos una por una.

### Marlon

[User attached 1 image; image contents were not included]

### Asistente

Perfecto. Ahora te está pidiendo el **público objetivo**.

En esa caja de abajo escribe exactamente esto:

**Personas de 18 a 35 años que entrenan en gimnasio, hacen deporte o llevan un estilo de vida activo y quieren mantener sus bebidas frías durante varias horas.**

Luego dale a la **flecha azul de enviar**.

Después te va a pedir la tercera entrada, la investigación del producto. Cuando aparezca, mándame captura o dime qué texto sale y te digo exactamente qué poner.

### Marlon

[User attached 1 image; image contents were not included]

### Asistente

Perfecto. Ahora te pide **“Provide key research points or benefits”**, o sea:

**“Dame los puntos clave de investigación o beneficios del producto.”**

Pega esto:

**Botella térmica deportiva de 1 litro. Mantiene las bebidas frías durante varias horas, es resistente, reutilizable, fácil de transportar y adecuada para gimnasio, deporte y actividades al aire libre. Ayuda a reducir el uso de botellas plásticas desechables.**

Luego dale a la flecha azul de enviar.

Después debería pasar al bloque que genera las **3 ideas publicitarias**. Ahí vemos si ya funciona todo el flujo.

### Marlon

[User attached 1 image; image contents were not included]

### Asistente

Sí, **funcionó**. ✅

Ya estás viendo la salida final de la app con las ideas publicitarias. En la captura aparecen, por ejemplo:

- **“El Guerrero del Gimnasio”**
- **“Estilo de Vida Consciente”**

Cada una tiene:
- un gancho,
- un beneficio,
- y un llamado a la acción.

O sea que el flujo completo quedó funcionando:

**Nombre del producto**  
→ **Público objetivo**  
→ **Beneficios / investigación**  
→ **Generar ideas**  
→ **Mostrar resultado**

Ahora ya aprendiste lo esencial de Opal: **entradas → bloque de IA → salida**.

El siguiente paso útil sería volver al **Editor** y revisar exactamente **qué bloque generó estas tarjetas** y cómo cambiar el diseño o el contenido. Ahí ya empezamos a personalizar de verdad.

### Marlon

eso seria todo no hay resultado algo o una pagina o ese pequeño texto es como la pagina ? o el video?

### Asistente

Sí: **eso que ves ya es la “página” de salida de esta versión de la app**.

No es solo un pequeño texto suelto. En tu captura, el bloque final `Render Advertising Page` tomó las ideas generadas y las convirtió en una **página HTML simple**, con tarjetas, títulos, etiquetas como `GIMNASIO` y `SOSTENIBILIDAD`, texto y botones.

En este remix que hicimos, **quitamos el video a propósito** para que cargara rápido y fuera fácil de aprender.

La versión original tenía algo más completo:

**Producto + público**  
→ investigación  
→ texto publicitario  
→ descripción del video  
→ **generación de video**  
→ página/campaña final

La versión que acabas de probar quedó así:

**Producto + público + beneficios**  
→ genera 3 ideas  
→ **crea una página con esas ideas**

Por eso **no vas a ver video en esta versión**.

Si quieres, ahora podemos hacer una de estas dos cosas:

1. **Mejorar esta página**: poner logo, colores, imágenes, botones, diseño más bonito, etc.
2. **Agregar video otra vez**, pero de forma más controlada: primero generamos la idea, luego un prompt de video y después usamos `Veo` para crear el video.

Para aprender, yo haría primero **la página bonita** y después agregamos video. Así entiendes cada capa sin mezclar todo de golpe.

### Marlon

y en edita paso le mandaria el promt?

### Asistente

Sí. **“Edita estos pasos”** es justo donde le puedes mandar una instrucción en lenguaje natural para que Opal modifique el flujo por ti.

Por ejemplo, podrías escribir ahí algo como:

> Mejora la página final para que tenga un diseño moderno y deportivo, con fondo oscuro, tarjetas limpias, títulos grandes, botones llamativos y mejor jerarquía visual. Mantén las 3 ideas publicitarias y no agregues información inventada.

Y Opal intentará cambiar los pasos necesarios para lograrlo.

Si quieres **agregar video**, podrías poner algo como:

> Agrega un nuevo paso después de generar las ideas publicitarias. Ese paso debe crear una descripción breve de video para cada idea. Luego usa Veo para generar un video corto basado en una de las ideas y muéstralo en la página final.

La diferencia importante es:

**Editar manualmente bloques** = más control.  
**“Edita estos pasos”** = más rápido, Opal decide cómo modificar el flujo.

Para aprender sin frustrarte, podemos usar bastante **“Edita estos pasos”** y luego revisar qué cambió en el diagrama. Ese método te conviene más.

### Marlon

claro me gusto editar pasos pero me frustraste un poco cuando podiamos simplificar}

### Asistente

Sí, te entiendo. Ahí la compliqué de más cuando **Opal ya tenía una forma mucho más simple de trabajar: “Edita estos pasos”**.

Para ti, la ruta más cómoda debería ser:

**1. Dices qué quieres en “Edita estos pasos”.**  
**2. Opal modifica el flujo.**  
**3. Revisamos qué bloques creó o cambió.**  
**4. Solo entramos manualmente a un bloque si algo salió mal o quieres afinarlo.**

Eso te deja aprender la lógica sin pelearte con cada variable y conexión.

De hecho, hoy ya te quedó una idea clave: **no necesitas construir todo bloque por bloque para usar Opal bien**. Puedes describir el resultado que quieres y luego revisar cómo lo armó. Ahí es donde realmente empiezas a aprender el sistema.

Desde ahora, con Opal voy a ir más así: **“ve aquí → pega esto → mira qué cambió”**, y solo te explico la parte técnica cuando haga falta.

### Marlon

osea puedo editar los paso y unir pero necesito que seas claro necesito ser agil&#x20;

### Asistente

Sí. Desde ahora voy a ser **mucho más directo y ágil** con Opal.

Tu forma ideal de aprender será esta:

1. **Primero usa “Edita estos pasos”** para pedir el cambio completo en lenguaje natural.
2. **Luego revisamos el diagrama** para ver qué creó, qué unió y qué dejó mal.
3. **Solo si hace falta**, entramos a un bloque específico y lo corregimos manualmente.
4. Si tienes que conectar algo tú mismo, te diré exactamente: **“haz clic en este bloque → luego en este → usa @ → selecciona esto”**.
5. Si existe una ruta más rápida, te la doy primero. La ruta técnica la dejamos como segunda opción.

Para que se te grabe, piensa Opal así:

**Entradas amarillas** = lo que escribe el usuario.  
**Bloques azules** = lo que hace la IA.  
**Bloques verdes** = lo que muestra la app.  
**Líneas** = quién le pasa información a quién.  
**Edita estos pasos** = “hazme los cambios automáticamente”.

Y sí: puedes **editar pasos, crear nuevos, borrar, unir, cambiar modelos, generar video, imágenes, audio y páginas**. Pero no tienes que hacerlo todo manualmente.

Desde ahora mi formato contigo será:

**“Ve a X → pega Y → dale a Z → revisa esto.”**

Sin rodeos.

### Marlon

ok y recuerda que no se ingle

### Asistente

Sí. Lo voy a tener presente siempre: **todo en español**, y si la app muestra algo en inglés, te digo exactamente qué significa y qué debes tocar.

Con Opal voy a guiarte así:

**Ve a → “Edita estos pasos” → pega este texto → dale a la flecha → espera → revisa este bloque.**

Sin hacerte traducir nada ni dejarte adivinando botones.

### Marlon

ok ahora estamos aqui a donde vamos , antes de las 3:50 debemos tener algo chvere para ver&#x20;

[User attached 1 image; image contents were not included]

### Asistente

Vamos por algo **rápido, visual y que se vea pro antes de las 3:50**. No metamos video todavía porque Veo puede demorarnos y arruinar el tiempo.

Haz esto:

**Ve abajo a `Edita estos pasos` → pega este prompt completo → envía.**

:::writing{variant="document" id="61742" title="Prompt para mejorar la app visualmente"}
Mejora esta miniaplicación manteniendo la lógica actual y sin eliminar lo que ya funciona.

Quiero que el resultado final se vea como una landing page publicitaria premium para una marca deportiva.

Realiza estos cambios:

1. Mantén las tres entradas actuales:
- Nombre del producto
- Público objetivo
- Investigación o beneficios del producto

2. Mantén el paso que genera las tres ideas publicitarias.

3. Mejora completamente la página final con este estilo:
- Diseño moderno y deportivo.
- Fondo oscuro elegante.
- Colores azul eléctrico, blanco y tonos oscuros.
- Apariencia premium.
- Diseño adaptable a celular.
- Tipografía grande y clara.
- Buen espacio entre elementos.

4. En la parte superior crea una sección HERO con:
- Un título impactante basado en el producto.
- Un subtítulo comercial.
- Una frase corta que resuma la propuesta de valor.
- Un botón principal con llamado a la acción.

5. Después muestra las 3 ideas publicitarias como tarjetas separadas.

Cada tarjeta debe mostrar:
- Categoría.
- Título.
- Gancho publicitario.
- Beneficio principal.
- Llamado a la acción.
- Botón.

6. Agrega al final una sección llamada:
"¿Por qué elegir este producto?"

Debe resumir automáticamente 3 beneficios obtenidos de la información proporcionada por el usuario.

7. Agrega una última llamada a la acción grande al final de la página.

8. Todo el contenido visible para el usuario debe estar en español.

9. No inventes características que no estén incluidas en la información proporcionada.

10. No agregues generación de video todavía.

Mantén la app rápida y funcional.
:::

Después de enviarlo:

**espera a que Opal termine → si te aparece “reiniciar para ver los cambios”, reinicia → ve a `Aplicación` y ejecútala otra vez.**

### Qué buscamos tener a las 3:50

Algo parecido a:

**HIDRATACIÓN REDEFINIDA**  
*Entrena más. Mantente fresco.*

[ BOTÓN ]

🏋️ **GIMNASIO**  
Idea 1...

🌱 **SOSTENIBILIDAD**  
Idea 2...

🏃 **VIDA ACTIVA**  
Idea 3...

**¿Por qué elegirla?**  
✓ Mantiene frío  
✓ Reutilizable  
✓ Fácil de transportar

[ **QUIERO LA MÍA** ]

Eso ya se va a sentir como **una mini página publicitaria real**, no solo como una respuesta de Gemini.

Después, si esto sale bien y todavía tenemos tiempo, hacemos el segundo golpe visual: **agregar una imagen generada del producto al HERO con Nano Banana**. Eso sí haría que se vea mucho más brutal.

### Marlon

[User attached 1 image; image contents were not included]

### Asistente

Va bien. Ya **aplicó el prompt** y volvió a la primera entrada, así que ahora toca **probar la versión nueva**.

Haz esto, sin tocar el editor:

1. A la derecha, donde dice **“Enter the name of your product”** = “Ingresa el nombre de tu producto”.
2. Escribe: **Botella térmica deportiva**
3. Dale a la flecha azul.
4. En **Público objetivo**, pega:
   **Personas de 18 a 35 años que entrenan en gimnasio, hacen deporte o llevan un estilo de vida activo.**
5. En **Investigación/beneficios**, pega:
   **Botella térmica de 1 litro, resistente, reutilizable, fácil de transportar y diseñada para mantener las bebidas frías durante varias horas.**
6. Deja que genere la página final.

Si sale bien, **antes de las 3:50** le damos un último toque visual: imagen grande arriba + diseño tipo anuncio premium.

### Marlon

[User attached 2 images; image contents were not included]

### Asistente

Sí, ya estás en el **tercer paso**.

Eso que dice **“Provide key research points or benefits”** significa:

**“Escribe los beneficios o puntos clave del producto.”**

## Haz esto ahora

### 1) En la caja de abajo pega esto:
**Botella térmica de 1 litro, resistente, reutilizable, fácil de transportar y diseñada para mantener las bebidas frías durante varias horas. Ideal para gimnasio, deporte y actividades al aire libre. Ayuda a reducir el uso de botellas plásticas desechables.**

### 2) Dale a la **flecha azul** de enviar.

### 3) Espera a que cargue la página final.

---

## Qué debería pasar después
Te debería mostrar una página mejorada con:
- un **título grande arriba**
- tarjetas con ideas publicitarias
- botones
- una parte final tipo **“por qué elegir este producto”**

---

## Si carga bien
Me mandas captura y yo te digo el **último prompt** para que se vea todavía más chévere antes de las **3:50**.

## Si se queda pegado
Me dices **“se pegó”** y te doy el siguiente paso corto:
**reiniciar → volver a probar → o simplificar el render final**.

### Marlon

[User attached 1 image; image contents were not included]

### Asistente

Sí, **ahora sí se ve chévere**. 🔥  
Ya tienes **algo presentable**:

- título fuerte: **Hidratación Redefinida**
- diseño oscuro/premium
- tarjetas publicitarias
- botones
- estilo más pro

## Si ya quieres mostrar algo
Haz esto:

### Opción rápida
- abajo a la derecha en la vista final:
  - **Share output** = compartir resultado
  - **Download file** = descargar la página

Eso ya te deja **algo para enseñar**.

---

## Si quieres darle **un último toque** antes de las 3:50
Ve a:

**`Edita estos pasos` → pega esto → envía**

```text
Mejora la página final sin cambiar la estructura general.

Haz estos ajustes:

1. Mantén el diseño premium actual.
2. Haz el título principal más corto y más fuerte.
3. Agrega un botón principal en la parte superior que diga:
"Quiero la mía"
4. Debajo del título principal agrega una frase corta:
"Mantén tu bebida fría. Mantén tu rendimiento arriba."
5. Asegúrate de que las 3 tarjetas tengan:
- categoría
- título
- gancho
- beneficio principal
- botón
6. Agrega al final una sección llamada:
"¿Por qué elegir esta botella?"
con 3 beneficios resumidos.
7. Agrega una última llamada a la acción al final que diga:
"Elige rendimiento. Elige frescura."
8. Todo debe seguir en español.
9. No agregues video.
10. Mantén la app rápida y visualmente atractiva.
```

---

## Mi recomendación
Para no arriesgar lo que ya funciona:

### Haz esto ya:
1. **Descarga o comparte este resultado**
2. Si te sobra tiempo, aplica el prompt de arriba

---

## En resumen
**Sí, ya tienes una página real.**  
**No es solo texto.**  
Ya puedes mostrarla.

Si quieres, el siguiente paso te lo doy en formato ultra corto:

**ve a X → pega Y → dale a Z**

y hacemos el **último upgrade**.

### Marlon

ya me rendi con esa app mas tarde quiero seguir aprendiendo }

### Asistente

Dale, déjalo por ahora. Ya avanzaste bastante y cuando volvamos no empezamos desde cero.

Te queda lo esencial: **entrada → bloque de IA → salida**, y también que **“Edita estos pasos”** puede hacerte ahorrar muchísimo tiempo.

Cuando retomemos, lo hacemos más ordenado y rápido: primero una miniapp muy simple, después una con imagen, y recién al final una con video.

Puedo recordártelo más tarde para que retomemos Opal.  


::chatgpt-content-reference{index="0"}

### Marlon

quieroi creear una play list para jericka de canciones que me gustan y que  me hacen pensar ej ella&#x20;

[User attached 1 image; image contents were not included]

### Asistente

Sí. Para eso esta app te sirve bastante bien.

Hazlo así, directo:

**Ve a `Start` → dale clic.**

Cuando te pregunte por el estado de ánimo o estilo musical, escribe algo como:

**Romántica, íntima, tranquila y especial. Quiero canciones que me hagan pensar en Jericka, en nuestra relación, en momentos bonitos juntos y en lo mucho que la quiero.**

Luego, si te deja poner preferencias musicales, escribe los artistas, géneros o canciones que te gustan.

Por ejemplo:
**Pop latino, baladas, R&B suave, canciones románticas en español e inglés.**

Y si quieres que se parezca más a ti, puedes poner también nombres de canciones que ya te hacen pensar en ella.

Si quieres, dime **5 a 10 canciones que te gustan** y yo te preparo exactamente el texto para pegar ahí, para que la playlist salga mucho más personal.

### Marlon

y no puedo decirle que canciones?

### Asistente

Sí, claro. **Puedes decirle exactamente qué canciones quieres**; de hecho, para que la playlist sea realmente tuya, eso es mejor.

Haz esto:

**Dale a `Start` → cuando te pida el mood o preferencias → escribe algo así:**

> Quiero una playlist para Jericka con canciones que ya me gustan y que me hacen pensar en ella. Usa principalmente estas canciones como base: [pon aquí tus canciones]. Mantén un ambiente romántico, íntimo y especial. Completa la playlist con canciones parecidas en estilo y sentimiento.

Y debajo pegas tus canciones, por ejemplo:

- canción 1 — artista  
- canción 2 — artista  
- canción 3 — artista  
- canción 4 — artista  
- canción 5 — artista

Si quieres **solo esas canciones y ninguna más**, dile:

> Crea la playlist únicamente con estas canciones. No agregues canciones nuevas.

Si quieres que **parta de tus canciones y te recomiende otras**, dile:

> Usa estas canciones como referencia y agrega otras que tengan un sentimiento y estilo parecido.

Pásame tus canciones y te dejo el texto exacto para pegar en Opal.

### Marlon

pero debo subir las canciones o el las busca o yo le comparto el link de la cancion en youtube

### Asistente

No necesitas subir los archivos de audio. Para esa app, lo más práctico es **darle los nombres de las canciones y artistas**.

También puedes pegar **links de YouTube**, pero normalmente con **nombre + artista** ya debería bastar para buscar o reconocer la canción si el flujo tiene acceso web.

Hazlo así:

**Opción más simple:**  
`Canción — Artista`

Ejemplo:  
`Perfect — Ed Sheeran`  
`Die With A Smile — Lady Gaga & Bruno Mars`

Si quieres asegurarte de que sea la versión exacta, entonces sí pega el **link de YouTube** junto al nombre.

No te recomiendo subir archivos MP3 salvo que la app específicamente te pida un archivo de audio.

Si quieres, pásame ahora tus canciones y te preparo el texto exacto para pegar en `Start`.
