---
title: "Mejorar banner del gym"
conversation_id: "6a95e307-7900-83e9-9fb2-6032d14dea26"
type: "chatgpt"
project_id: "g-p-6a03602663008191b5d8ab97a83e1d56"
area: "02 - Personal/Otros"
updated_at: 1788213427.57
archived: false
export_complete: true
tags: [conversacion-ai, jarvis-import]
---

# Mejorar banner del gym

- ID: `6a95e307-7900-83e9-9fb2-6032d14dea26`
- Tipo: `chatgpt`
- Proyecto: `g-p-6a03602663008191b5d8ab97a83e1d56`
- Estado: `activa`

## Conversación

### Marlon

Queremos mejora nuestro logo en el gym queremos cambiar la foto del banner donde sale. Dos personas entrenando desconocida y colocar nuestras fotografías obviamente mejora un poco nuestras foto sin perder detalles , colocas de forma que se vea bien en banner que se vea estético y no forzado

[User attached 3 images; image contents were not included]

### Marlon

Ahora realizaré uno  igual pero sin la palabra de cupos disponibles

### Marlon

Jericka me dice que  si nos puedes poner co. Ropa negra para no desentonar y que las ponga a ella haciendo una sentadilla y que la hagas un poco más delgada en la foto

### Marlon

Está súper todo, a jericka le pusiste mucho glúteo que no se vea tan irreal , y me cambiaste mucho el rostro ( varón) no cambies mucho mi rostro hazlo  hiperrrealista

### Marlon

Me gusta, pero tú tienes fotos de mi físico. Te voy a pasar mi físico nuevamente para que lo veas mucho mejor, para ver qué te parece. El de Jerry está creo que perfecto. y la carita de mi yeri que tiene que ser un poquito más parecida a ella pues.

[User attached 2 images; image contents were not included]
