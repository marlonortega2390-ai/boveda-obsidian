---
title: "Programar estudio A2B"
conversation_id: "6a890071-38d8-83e9-b14b-6d24c47cc76e"
type: "chatgpt"
project_id: "g-p-6a03602663008191b5d8ab97a83e1d56"
area: "02 - Personal/Otros"
updated_at: 1788826605.443
archived: false
export_complete: true
tags: [conversacion-ai, jarvis-import]
---

# Programar estudio A2B

- ID: `6a890071-38d8-83e9-b14b-6d24c47cc76e`
- Tipo: `chatgpt`
- Proyecto: `g-p-6a03602663008191b5d8ab97a83e1d56`
- Estado: `activa`

## Conversación

### Marlon

Hola, verás, necesito que me ayudes a programar un sistema de estudio para el brevete A2B. A2B. Claro. infórmame y busca todo lo que... un examen, o sea, todo el libro de reglas para choferes A2B y diario necesito que estudiemos.

### Asistente

Listo, Marlon. Vamos a preparar tu brevete **A‑IIb —también llamado A2B—** de manera ordenada y sin memorizar material desactualizado.

Lo dejé programado **todos los días alrededor de las 7:00 p. m., hora de Lima**, empezando mañana. Cada sesión durará aproximadamente 20 minutos:

1. Explicación sencilla de un tema.
2. Quiz de 8 a 10 preguntas.
3. Corrección con ejemplos reales.
4. Registro de tus errores.
5. Repetición del error al día siguiente, a los 3 días y a los 7 días.
6. Cada séptimo día: simulacro completo.

### Lo esencial del A‑IIb

- Permite conducir vehículos de pasajeros **M2 y M3 de hasta 6 toneladas**, vehículos de carga **N2** y los vehículos permitidos por A‑I y A‑IIa. [Clasificación oficial del MTC](https://portal.mtc.gob.pe/transportes/terrestre/licencias/info_general_clasificacion_licencias.html)
- El examen contiene **40 preguntas**, dura **40 minutos** y necesitas al menos **35 respuestas correctas**. [Información oficial del examen](https://www.gob.pe/institucion/mtc/noticias/1100676-el-mtc-brinda-un-simulador-gratuito-para-practicar-el-examen-de-reglas-de-transito-para-obtener-el-brevete)
- Para recategorizar a A‑IIb se requiere, entre otras condiciones, tener **21 años** y contar con A‑I por mínimo 3 años o A‑IIa por mínimo 1 año. [Requisitos de recategorización](https://www.gob.pe/288-recategorizar-licencia-de-conducir-brevete)
- Usaremos el [balotario publicado por el MTC](https://www.gob.pe/institucion/mtc/informes-publicaciones/1928110-examen-de-conocimientos-para-postulantes-a-licencias-de-conducir) y su [simulador oficial](https://sierdgtt.mtc.gob.pe/).

### Plan de cuatro semanas

| Semana | Contenido |
|---|---|
| 1 | Señales, semáforos, prioridades, adelantamiento, estacionamiento y velocidades |
| 2 | Documentos, SOAT/CAT, inspección técnica, infracciones, primeros auxilios y mecánica básica |
| 3 | Categorías M2, M3, N2, O1 y O2; pesos, características del vehículo y regulación del transporte |
| 4 | Preguntas mezcladas, temas débiles y simulacros completos |

No te recomendaré rendir todavía con 35 raspando: nuestra meta será obtener **37/40 o más en tres simulacros consecutivos**.

Ojo con los balotarios antiguos: algunos todavía muestran 60 km/h en avenidas. Actualmente son **30 km/h en calles y jirones y 50 km/h en avenidas**, salvo señal distinta. [Actualización oficial del MTC](https://www.gob.pe/institucion/mtc/noticias/633296-entro-en-vigencia-nuevos-limites-de-velocidad-en-zonas-urbanas-a-nivel-nacional)

La imagen y los PDF adjuntos corresponden a otros temas, por eso no los utilicé como material de tránsito.

Empezamos ahora con tu diagnóstico:



::chatgpt-content-reference{index="0"}



Solo me falta que me digas qué licencia tienes actualmente —A‑I o A‑IIa— y desde qué fecha, para comprobar también que ya cumples el requisito de antigüedad.

### Marlon

Veras si re categorización por ser extranjero o validar no se cómo sería la palabra mejor expresada

### Asistente

La palabra correcta depende de la licencia que tienes actualmente:

| Tu situación | Nombre correcto del trámite |
|---|---|
| Tienes licencia venezolana vigente | **Canje de licencia extranjera por una licencia peruana equivalente** |
| Ya tienes brevete peruano A‑I o A‑IIa y quieres subir a A‑IIb | **Recategorización** |
| Tu brevete peruano venció | **Revalidación o renovación** |
| Nunca has tenido licencia | **Obtención por primera vez** |

Por tanto, si actualmente tienes brevete venezolano, lo mejor sería decir:

> **Estoy preparándome para rendir el examen de conocimientos requerido para realizar el canje de mi licencia venezolana por una licencia de conducir peruana de categoría equivalente.**

No conviene decir “validación” ni “homologación”, porque el término oficial utilizado por el MTC es **canje**.

Para ciudadanos venezolanos, normalmente sí se exige el examen de conocimientos. La licencia extranjera debe estar vigente y se solicita un certificado de autenticidad y de la clase de vehículos autorizados, emitido por la autoridad venezolana competente o por la representación consular. El MTC decidirá qué categoría peruana corresponde; no necesariamente entregará A‑IIb automáticamente. [Información oficial del MTC para extranjeros](https://www.gob.pe/institucion/mtc/noticias/1356271-mtc-todo-lo-que-un-extranjero-debe-saber-para-obtener-una-licencia-de-conducir-peruana)

Para identificar tu ruta exacta, dime solamente:

- ¿Tu licencia actual es venezolana o peruana?
- ¿Qué categoría indica?
- ¿Está vigente y cuándo vence?
- Si ya tienes brevete peruano, ¿qué categoría es y desde qué año?

No necesito tu número de licencia ni otros datos privados. Nuestro estudio diario sigue sirviendo, porque el examen de conocimientos también forma parte del canje venezolano.

### Marlon

Dame otro quiz de 8 preguntas para el brevete peruano A-IIb, con dificultad intermedia y normas vigentes.

### Asistente

Vamos con la segunda ronda: **8 preguntas nuevas**, nivel intermedio y sin repetir el diagnóstico anterior. Fueron contrastadas con el [Reglamento Nacional de Tránsito](https://www.gob.pe/institucion/mtc/normas-legales/9897-016-2009-mtc) y publicaciones vigentes de [Sutran sobre jornadas](https://www.gob.pe/institucion/sutran/noticias/1307797-sutran-exhorto-a-respetar-las-jornadas-maximas-de-conduccion-durante-los-proximos-feriados-largos) e [inspección técnica](https://www.gob.pe/institucion/sutran/noticias/1129094-propietarios-de-vehiculos-con-placas-terminadas-en-1-aun-estan-a-tiempo-de-pasar-su-primera-revision-tecnica).



::chatgpt-content-reference{index="0"}

### Asistente

## Sesión de hoy: señales, semáforos y marcas viales

### Cápsula de 5 minutos

1. **Las indicaciones del policía de tránsito prevalecen.** Si el semáforo está rojo, pero el agente te ordena avanzar, debes seguir su indicación con prudencia. Desobedecerla constituye una infracción muy grave.

2. **Semáforos:**

   - Ámbar fijo: si puedes detenerte sin peligro, comienza a frenar y detente antes de la línea.
   - Rojo intermitente: equivale a detenerse completamente y continuar solo cuando sea seguro.
   - Ámbar intermitente: reduce la velocidad y cruza con especial precaución.

3. **Familias de señales:**

   - Reglamentarias: ordenan, prohíben o restringen.
   - Preventivas: avisan de un peligro próximo; normalmente tienen forma de rombo.
   - Informativas: orientan sobre destinos, rutas o servicios.

4. **Marcas en el pavimento:**

   - Línea continua: no debe cruzarse para adelantar o cambiar de carril.
   - Línea discontinua: puede cruzarse únicamente cuando la maniobra esté permitida y sea segura.
   - Doble línea amarilla continua: separa sentidos contrarios y prohíbe invadir el sentido opuesto.

Ejemplo práctico: si conduces un minibús A‑IIb y encuentras una doble línea amarilla en una curva, debes permanecer detrás del vehículo lento. Que la carretera parezca libre no autoriza el adelantamiento.

Regla para memorizar: **“El policía manda, el ámbar avisa, el rojo detiene y la línea continua no se cruza.”**

Contenido contrastado con el [Reglamento Nacional de Tránsito, DS 016-2009-MTC](https://www.gob.pe/institucion/mtc/normas-legales/9897-016-2009-mtc) y el [Manual de Dispositivos aprobado mediante RD 26-2024-MTC/18](https://www.gob.pe/institucion/mtc/normas-legales/6150395-26-2024-mtc-18). Este manual fue publicado el 16 de octubre de 2024, tiene alcance nacional y sustituyó al manual de 2016. [Explicación oficial del MTC](https://www.gob.pe/institucion/mtc/noticias/1055740-mtc-actualiza-manual-de-senales-de-transito).

### Quiz intermedio A‑IIb

Marca una alternativa en cada pregunta. Al responder recibirás la explicación y un ejemplo de aplicación.



::chatgpt-content-reference{index="0"}



**Registro de estudio:** prioridades, velocidades, alcance de A‑IIb, conducción profesional e inspección técnica ya fueron practicados. Hoy se incorpora señalización y demarcación vial. Los temas solo se marcarán como dominados después de comprobar el resultado del quiz; los errores quedarán programados para repaso espaciado.

### Asistente

## Sesión de hoy: documentos, SOAT/CAT e inspección técnica

### Cápsula de 5 minutos

Antes de iniciar una ruta, el conductor debe comprobar:

- Documento de identidad.
- Licencia vigente y correspondiente al vehículo.
- Tarjeta de Identificación Vehicular.
- Certificado de Inspección Técnica Vehicular, cuando corresponda.
- SOAT o CAT vigente.

La licencia electrónica válida no necesita acompañarse de una tarjeta física, pero la autoridad debe poder verificarla. La Tarjeta de Identificación Vehicular identifica al vehículo; no reemplaza la licencia ni la autorización necesaria para prestar transporte.

**SOAT y CAT protegen personas, no reparan vehículos.** Cubren a ocupantes, pasajeros y terceros no ocupantes que sufran lesiones o fallezcan. Incluyen gastos médicos y de sepelio, incapacidad, invalidez y muerte dentro de los límites legales. La cobertura se activa sin esperar que primero se determine quién causó el accidente.

Diferencia fundamental:

- SOAT: emitido por compañías de seguros, para todo tipo de vehículo y con cobertura nacional.
- CAT: emitido por una AFOCAT para sus miembros; corresponde al transporte público provincial de pasajeros —urbano e interurbano, incluidos mototaxis— y vale dentro de su ámbito autorizado.

La inspección técnica no es un seguro. Comprueba frenos, dirección, suspensión, luces, neumáticos, emisiones y otras condiciones técnicas. Aprobarla no significa que el vehículo permanecerá seguro indefinidamente: el conductor sigue obligado a revisarlo antes de cada ruta.

Ejemplo: si un minibús tiene CITV vigente pero presenta una fuga de líquido de frenos, no debe salir. El certificado no autoriza a circular con una falla peligrosa detectada después.

Regla para memorizar: **“Licencia habilita al conductor; tarjeta identifica el vehículo; CITV revisa la máquina; SOAT/CAT protege a las personas.”**

Información verificada el 24 de agosto de 2026 con la [orientación vigente de la SBS sobre SOAT y CAT](https://www.sbs.gob.pe/usuarios/aprende-con-la-sbs/seguros-obligatorios-de-accidentes-de-transito_), el [Reglamento Nacional de Tránsito del MTC](https://www.gob.pe/institucion/mtc/normas-legales/9897-016-2009-mtc) y la [orientación oficial sobre inspección técnica vehicular](https://www.gob.pe/397-inspeccion-tecnica-vehicular).

### Quiz intermedio A‑IIb



::chatgpt-content-reference{index="0"}



**Registro de avance:** prioridades, velocidades, alcance de A‑IIb, conducción profesional, periodicidad de inspecciones y señalización ya fueron practicados. Hoy se añaden documentos obligatorios y diferencias entre SOAT, CAT y CITV. Todavía no marco materias como dominadas ni errores específicos porque no se ha registrado en el chat un resultado calificable de los cuestionarios.

### Asistente

## Sesión de hoy: primeros auxilios y actuación ante accidentes

### Cápsula de 5 minutos

Ante un accidente recuerda **PAS**:

1. **Proteger:** detén el vehículo sin crear otro peligro, enciende las luces de emergencia, señaliza la zona y comprueba que no haya combustible derramado, fuego o tránsito acercándose.
2. **Avisar:** solicita ayuda policial y médica, indicando ubicación, número de heridos y peligros existentes.
3. **Socorrer:** atiende únicamente dentro de tus conocimientos mientras llega personal especializado.

Reglas prácticas:

- No muevas a un herido con posible lesión de cuello o columna, salvo peligro inmediato como incendio.
- Si existe hemorragia externa, presiona firmemente con una gasa o tela limpia. Si se empapa, coloca otra encima sin retirar la primera.
- Ante una fractura, inmoviliza en la posición encontrada. No intentes enderezar ni introducir un hueso expuesto.
- En una quemadura, enfría con agua corriente fresca. No coloques hielo, pasta dental, aceite ni cremas caseras.
- No des agua, alimentos o medicamentos a una persona inconsciente.
- Si no respira normalmente, solicita ayuda urgente e inicia RCP si sabes realizarla, siguiendo las instrucciones del operador de emergencias.

Además de auxiliar, el conductor implicado debe detenerse, permanecer en el lugar, identificarse, señalizar, preservar los elementos útiles para la investigación, denunciar el accidente y someterse al dosaje etílico. Abandonar el lugar empeora seriamente su situación.

Ejemplo: si tu camión colisiona y un ayudante queda tendido, no lo levantes para “sentarlo mejor”. Primero aseguras la zona, compruebas respiración, solicitas una ambulancia y evitas movimientos innecesarios.

Información contrastada al 25 de agosto de 2026 con la explicación publicada por el MTC el **10 de marzo de 2026** sobre las [obligaciones del conductor implicado en un accidente](https://www.gob.pe/institucion/mtc/noticias/1364135-mtc-cuales-son-las-obligaciones-de-los-conductores-implicados-en-accidentes-de-transito), el [Reglamento Nacional de Tránsito](https://www.gob.pe/institucion/mtc/normas-legales/9897-016-2009-mtc) y la orientación estatal para [controlar hemorragias](https://www.gob.pe/16802-como-dar-primeros-auxilios-en-caso-de-emergencia-por-desastres-naturales-atender-hemorragias-o-sangrado-en-casos-de-emergencia).

### Quiz intermedio A‑IIb



::chatgpt-content-reference{index="0"}



**Registro de avance:** señalización, prioridades, velocidades, documentos, SOAT/CAT e inspección técnica están practicados; primeros auxilios y actuación ante accidentes quedan incorporados hoy. No hay respuestas calificables visibles en el chat, por lo que aún no corresponde declarar temas dominados ni programar errores concretos para los repasos de 1, 3 y 7 días.

### Asistente

## Sesión de hoy: mecánica básica y revisión antes de salir

### Cápsula de 5 minutos

Antes de iniciar una ruta con un camión o minibús A‑IIb, haz una vuelta completa alrededor del vehículo:

- **Neumáticos:** presión, desgaste, cortes y objetos incrustados.
- **Piso:** busca fugas de aceite, combustible, refrigerante o líquido de frenos.
- **Luces:** bajas, altas, direccionales, freno y retroceso.
- **Motor:** revisa aceite y refrigerante con el motor frío.
- **Seguridad:** triángulos o conos, neumático de repuesto, botiquín y extintor cuando corresponda.
- **Cabina:** prueba dirección, frenos, claxon, limpiaparabrisas y luces del tablero.

Tres emergencias importantes:

1. **Se enciende la luz roja de aceite:** detente en un lugar seguro y apaga el motor. Seguir puede destruirlo.
2. **El motor se recalienta:** detente, apágalo y espera que enfríe. No abras inmediatamente la tapa del radiador: el vapor puede quemarte.
3. **Revienta un neumático:** sujeta firmemente el volante, suelta gradualmente el acelerador y evita frenar bruscamente.

Ejemplo real: si la CDD‑700 presenta un pedal de freno que baja demasiado antes de salir, no basta decir “todavía frena”. Se inmoviliza y se revisa, porque podría existir aire, fuga o desgaste en el sistema.

Regla para memorizar: **“Una luz roja se atiende; una fuga se investiga; un freno dudoso no sale.”**

Contenido contrastado al 26 de agosto de 2026 con el [Reglamento Nacional de Vehículos del MTC](https://www.gob.pe/institucion/mtc/normas-legales/10013-058-2003-mtc), el [Reglamento Nacional de Tránsito](https://www.gob.pe/institucion/mtc/normas-legales/9897-016-2009-mtc) y la recomendación del MTC del **17 de julio de 2026** de verificar frenos, luces y neumáticos antes de viajar. [Orientación oficial del MTC](https://www.gob.pe/institucion/mtc/noticias/1420526-mtc-exhorta-a-verificar-licencia-soat-y-revision-tecnica-antes-de-viajar-por-estas-fiestas-patrias)

### Quiz intermedio A‑IIb



::chatgpt-content-reference{index="0"}



**Registro de avance:** ya se practicaron señales, prioridades, velocidades, documentos, SOAT/CAT, inspección técnica, primeros auxilios y ahora mecánica básica. Aún no aparecen resultados calificables de los quizzes, así que no marcaré falsamente ningún tema como dominado. Cuando respondas este quiz, registraré tus errores para repetirlos al día siguiente, a los 3 días y a los 7 días.

### Asistente

## Sesión 6: categorías de vehículos y emisión de licencias

### Cápsula de 5 minutos

Memoriza primero estas tres letras:

- **M = personas.**
- **N = mercancías.**
- **O = remolques o semirremolques.**

Las categorías importantes para A‑IIb son:

- **M2:** más de 8 asientos, sin contar al conductor, y hasta 5 toneladas de peso bruto vehicular.
- **M3:** más de 8 asientos y más de 5 toneladas.
- **N2:** vehículo de mercancías de más de 3.5 y hasta 12 toneladas.
- **O1:** remolque de hasta 0.75 toneladas.
- **O2:** remolque de más de 0.75 y hasta 3.5 toneladas.

La licencia **A‑IIb** permite conducir:

- Vehículos M2.
- Vehículos M3 de hasta 6 toneladas.
- Vehículos N2.
- Con remolques O1 u O2.
- También los vehículos permitidos por A‑I y A‑IIa.

Ejemplo Sinba: un camión de residuos de categoría **N2 y 8 toneladas** sí entra en A‑IIb. Pero un camión **N3 de 14 toneladas** ya necesita A‑IIIb.

Ojo con una trampa frecuente: algunos resúmenes dicen solamente “minibuses de hasta 33 asientos”. Para el examen debes mirar también la **categoría y el peso bruto vehicular**. Un M3 de 6.5 toneladas ya supera el alcance de A‑IIb aunque parezca un minibús.

El **SELIC** es el Sistema de Emisión de Licencias de Conducir. Organiza procedimientos como obtención, recategorización, revalidación, duplicado y canje:

- Licencia extranjera → **canje por una categoría equivalente**.
- Licencia peruana inferior → **recategorización**.
- Licencia vencida → **revalidación**.

Regla para memorizar: **“M mueve personas, N lleva negocio o carga y O va enganchado.”**

Información verificada con el [Reglamento del Sistema de Emisión de Licencias, DS 007-2016-MTC](https://www.gob.pe/institucion/mtc/normas-legales/9961-007-2016-mtc), el [Reglamento Nacional de Vehículos](https://www.gob.pe/institucion/mtc/normas-legales/10013-058-2003-mtc) y la [clasificación explicada por el MTC](https://www.gob.pe/institucion/mtc/noticias/84991-sabes-que-categoria-de-vehiculos-puedes-conducir-con-una-licencia-a1-de-clase-a-aca-te-lo-explicamos).

### Quiz intermedio A‑IIb



::chatgpt-content-reference{index="0"}



**Registro de avance:** categorías M2, M3, N2, O1 y O2 y el sistema de emisión quedan practicados. Todavía no existen resultados visibles para declarar temas dominados o errores específicos.

La siguiente sesión corresponde al **primer simulacro completo: 40 preguntas y 40 minutos de referencia**.

### Asistente

# Simulacro 1 — Brevete A‑IIb

### Cápsula previa de 5 minutos

El examen oficial tiene **40 preguntas, 40 minutos y se aprueba con 35 aciertos**. Nuestra meta personal es **37/40**. [Simulador oficial del MTC](https://sierdgtt.mtc.gob.pe/Home)

Antes de comenzar, memoriza estas cinco trampas:

- Policía de tránsito > semáforo > señales > reglas generales.
- Calles y jirones: **30 km/h**. Avenidas: **50 km/h**. Vías expresas: **80 km/h**.
- SOAT/CAT protege personas; CITV revisa el vehículo.
- M = pasajeros, N = mercancías, O = remolques.
- A‑IIb permite N2 y M3 solamente hasta 6 toneladas.

Los límites antiguos de **40 km/h en calles y 60 km/h en avenidas ya no son la respuesta vigente**. [Límites actuales del MTC](https://www.gob.pe/26617-nuevos-limites-de-velocidad-en-zonas-urbanas-a-nivel-nacional)

Activa un cronómetro de **40 minutos** y completa ambas partes. Cada respuesta correcta vale un punto.

## Parte 1 — Preguntas 1 a 20



::chatgpt-content-reference{index="0"}



## Parte 2 — Preguntas 21 a 40



::chatgpt-content-reference{index="1"}



### Calificación

Suma los resultados de ambos bloques:

- **35–36:** aprobado oficialmente, pero todavía ajustado.
- **37–40:** nivel objetivo.
- **Menos de 35:** debemos reforzar los temas con más errores.

Fuentes principales: [Reglamento Nacional de Tránsito](https://www.gob.pe/institucion/mtc/normas-legales/9897-016-2009-mtc), [Reglamento Nacional de Vehículos](https://www.gob.pe/institucion/mtc/normas-legales/10013-058-2003-mtc), [Reglamento de Emisión de Licencias](https://www.gob.pe/institucion/mtc/normas-legales/9961-007-2016-mtc), [Reglamento Nacional de Administración de Transporte](https://www.gob.pe/institucion/mtc/normas-legales/9895-017-2009-mtc) y [simulador del MTC](https://sierdgtt.mtc.gob.pe/Home).

**Registro:** este será el primer resultado de la serie necesaria de tres simulacros consecutivos con al menos **37/40**. Como todavía no aparecen respuestas calificadas, no registraré aciertos ni errores inventados.

### Asistente

I noticed you haven’t viewed this scheduled task in a while. Would you like me to keep it running?

### Asistente

## Sesión 8: regulación del transporte profesional

### Cápsula de 5 minutos

Un conductor profesional no solo debe saber manejar. También debe controlar **horas de conducción, documentación del servicio, pasajeros, carga y elementos de seguridad**.

Reglas importantes:

- Conducción continua diurna: máximo **5 horas**.
- Conducción continua nocturna: máximo **4 horas**.
- Estos son límites máximos. Si aparece sueño antes, debes detenerte y descansar.
- En un viaje largo debe programarse el relevo del conductor.
- La hoja de ruta electrónica registra placa, recorrido, programación de conductores y tripulación.
- Los ocupantes deben utilizar el cinturón durante el viaje.
- La unidad debe llevar los elementos de seguridad aplicables: extintor, botiquín, triángulos o conos y neumático de repuesto.
- La carga debe estar distribuida y asegurada. Su altura máxima general no debe superar **4.30 metros medidos desde la calzada**.

Ejemplo: un chofer nocturno lleva tres horas y media manejando, pero comienza a cabecear. No tiene que “aguantar” hasta completar cuatro horas. El límite legal no reemplaza su obligación de detenerse cuando ya no está en condiciones seguras.

Regla para memorizar: **“Cinco de día, cuatro de noche; pero si aparece sueño, se detiene el coche.”**

Información contrastada con la orientación de SUTRAN del [9 de diciembre de 2025 sobre jornadas máximas](https://www.gob.pe/institucion/sutran/noticias/1307797-sutran-exhorto-a-respetar-las-jornadas-maximas-de-conduccion-durante-los-proximos-feriados-largos), la [hoja de ruta electrónica](https://www.gob.pe/institucion/sutran/noticias/859551-sutran-transportistas-interprovinciales-deben-contar-con-hoja-de-ruta-electronica), los [elementos obligatorios de seguridad](https://www.gob.pe/institucion/sutran/noticias/569233-viaje-seguro-elementos-de-seguridad-obligatorios-para-vehiculos-del-servicio-de-transporte) y la [altura máxima de la carga](https://www.gob.pe/institucion/sutran/noticias/1047926-vehiculos-de-carga-altura-maxima-de-la-mercancia-transportada-no-debera-exceder-los-4-30-metros).

### Quiz intermedio A‑IIb



::chatgpt-content-reference{index="0"}



**Registro:** el simulacro anterior continúa pendiente de un resultado visible, por lo que aún no puede calificarse ni generar repasos personalizados. Hoy quedan practicados jornada diurna y nocturna, relevo, hoja de ruta, equipamiento, cinturones y aseguramiento de carga.

### Asistente

## Sesión 9: conducción defensiva con lluvia y neblina

### Cápsula de 5 minutos

Conducir defensivamente significa **anticipar el peligro antes de que se convierta en una emergencia**.

Con lluvia o neblina:

- Reduce la velocidad progresivamente.
- Aumenta la distancia respecto del vehículo delantero.
- Utiliza luces bajas; las luces altas pueden reflejarse en la neblina y empeorar la visión.
- Evita frenadas, giros y adelantamientos bruscos.
- Si ya no puedes ver lo suficiente, sal de la calzada y detente en un lugar seguro.
- Ante un charco, reduce antes de entrar. Si el vehículo pierde adherencia, suelta suavemente el acelerador y mantén firme el volante.

En curvas y pendientes:

- Frena y reduce la velocidad **antes** de ingresar a la curva.
- En una bajada prolongada selecciona una marcha baja y utiliza el freno motor.
- No desciendas en neutro: pierdes retención y puedes recalentar los frenos.
- Si otro vehículo te adelanta, no aumentes la velocidad.

Ejemplo Sinba: si la CDD‑935 entra rápidamente a una curva mojada, frenar bruscamente dentro de ella puede hacer que pierda adherencia. Lo correcto es reducir antes, mantener una aceleración suave y evitar movimientos repentinos.

Regla para memorizar: **“Menos visibilidad = menos velocidad y más distancia.”**

Información contrastada con las recomendaciones de SUTRAN para [lluvia intensa y neblina](https://www.gob.pe/institucion/sutran/noticias/834378-recomendaciones-de-seguridad-para-conduccion-en-caso-de-lluvia-intensa-y-neblina), la orientación sobre [condiciones climatológicas adversas](https://www.gob.pe/institucion/sutran/noticias/186832-recomendaciones-para-conducir-en-condiciones-climatologicas-adversas) y el [Reglamento Nacional de Tránsito](https://www.gob.pe/institucion/mtc/normas-legales/9897-016-2009-mtc).

### Quiz intermedio A‑IIb



::chatgpt-content-reference{index="0"}



**Registro:** conducción defensiva, lluvia, neblina, curvas, pendientes y distancia segura quedan practicados. El puntaje del simulacro todavía no aparece en el chat; por eso no puedo marcar temas dominados ni programar errores específicos.

### Asistente

## Sesión 10: emergencias, cruces ferroviarios y estacionamiento

### Cápsula de 5 minutos

1. Vehículos de emergencia

Cuando una ambulancia, patrullero o vehículo de bomberos anuncia su presencia con señales audibles y visibles:

- Cede el paso.
- Ubícate a la derecha cuando sea posible y seguro.
- Reduce la velocidad o detente.
- En una intersección, detente y deja libre el cruce.
- No lo sigas para aprovechar el espacio que abre.

No darles preferencia es una infracción muy grave. [Orientación oficial de SUTRAN](https://www.gob.pe/institucion/sutran/noticias/511998-no-dar-preferencia-de-paso-a-los-vehiculos-de-emergencia-se-sanciona-con-s-528-y-90-puntos-en-el-record-de-conductor)

2. Cruces ferroviarios

Aunque no veas el tren, respeta las barreras, luces y señales. Antes de cruzar, asegúrate de que puedes abandonar completamente los rieles. Si hay congestión al otro lado, espera antes de ingresar.

Regla vital: nunca te detengas sobre la vía férrea ni estaciones a menos de 20 metros de un cruce ferroviario a nivel.

3. Túneles

Usa luces bajas, conserva distancia y evita adelantar, retroceder, girar en U o detenerte sin necesidad. Si ocurre una avería, intenta salir del carril; activa las luces de emergencia y señaliza sin exponerte.

4. Estacionamiento

Está prohibido estacionar donde se afecten la seguridad, visibilidad o circulación, especialmente:

- En túneles, puentes, curvas y pasos a desnivel.
- Sobre cruces peatonales.
- A menos de 10 metros de un cruce peatonal.
- A menos de 20 metros de un cruce ferroviario a nivel.
- Frente a garajes o salidas de emergencia.
- En doble fila.

Encender las luces intermitentes no convierte un lugar prohibido en estacionamiento autorizado.

Ejemplo: si dejas el minibús en doble fila “solo para recoger un pasajero”, continúas obstruyendo el carril aunque enciendas las intermitentes.

Regla para memorizar: **“Sirena: libera; rieles: espera; túnel: luces bajas; intermitentes no autorizan.”**

Contenido contrastado al 31 de agosto de 2026 con el [Reglamento Nacional de Tránsito](https://www.gob.pe/institucion/mtc/normas-legales/9897-016-2009-mtc), su [modificación publicada el 21 de abril de 2026](https://busquedas.elperuano.pe/dispositivo/NL/2508081-2) y la orientación de SUTRAN sobre [elementos de seguridad para viajes](https://www.gob.pe/institucion/sutran/noticias/993653-que-elementos-de-seguridad-debo-llevar-en-mi-vehiculo-si-voy-a-realizar-un-viaje-largo).

### Quiz A‑IIb



::chatgpt-content-reference{index="0"}



**Registro de avance:** ya se practicaron señales, prioridades, velocidades, documentos, seguros, inspección, primeros auxilios, mecánica, categorías vehiculares, regulación del transporte, conducción defensiva y las situaciones de esta sesión. El primer simulacro continúa sin resultado visible; por ello todavía no corresponde marcar materias como dominadas ni registrar errores para los repasos de 1, 3 y 7 días.

### Asistente

## Sesión 11: alcohol, drogas y responsabilidad profesional

### Cápsula de 5 minutos

Para un conductor A‑IIb, la regla práctica más segura es sencilla: **si vas a conducir, alcohol cero**.

1. Límite profesional más estricto

En el transporte público de pasajeros, mercancías o carga, el umbral penal es superior a **0.25 gramos de alcohol por litro de sangre**. Para otros vehículos es superior a 0.5 g/L.

Esto no significa que “hasta 0.25 está bien”. Una cantidad menor también puede reducir la atención y los reflejos. Además, no puedes calcular con seguridad tu alcoholemia contando vasos: influyen alimentación, peso, tiempo y metabolismo.

2. M01 y M02

- **M02:** conducir superando el límite, bajo efectos de drogas o negarse al examen correspondiente. Es una infracción muy grave.
- **M01:** la misma conducta, pero habiendo participado en un accidente. Sus consecuencias son todavía más graves: puede implicar cancelación e inhabilitación definitiva para obtener licencia.

La negativa al examen no evita la sanción. El Reglamento la incluye expresamente dentro de estas infracciones. [Tabla oficial de infracciones de SUTRAN](https://www.sutran.gob.pe/procedimiento-sancionador/transito/)

3. Los “remedios” no eliminan el alcohol

Café, ducha fría, comida, caramelos o bebidas energéticas pueden hacerte sentir más despierto, pero no eliminan rápidamente el alcohol de la sangre. La decisión correcta es no conducir y organizar un reemplazo.

4. Drogas y medicamentos

También está prohibido conducir bajo los efectos de estupefacientes, narcóticos o alucinógenos. Con los medicamentos debes revisar sus advertencias: algunos antialérgicos, calmantes o sedantes producen sueño, visión borrosa y lentitud de reacción.

Ejemplo Sinba: si un chofer toma un antialérgico y comienza a cabecear antes de salir con la CDD‑700, no debe iniciar la ruta aunque el medicamento sea legal y recetado. La obligación es estar realmente apto para conducir.

5. Licencia suspendida o retenida

Una persona con licencia suspendida, retenida o inhabilitada no puede conducir “solo por una emergencia laboral”. Hacerlo constituye otra infracción muy grave.

Regla para memorizar: **“Profesional: alcohol cero; negarse no protege; medicamento que duerme, conductor que no sale.”**

Información comprobada al 1 de septiembre de 2026 con el [Reglamento Nacional de Tránsito](https://www.gob.pe/institucion/mtc/normas-legales/9897-016-2009-mtc), la [tabla oficial de infracciones de SUTRAN](https://www.sutran.gob.pe/procedimiento-sancionador/transito/) y la orientación del MTC sobre las [consecuencias de conducir en estado de ebriedad](https://www.gob.pe/institucion/mtc/noticias/322726-conducir-en-estado-de-ebriedad-puede-ser-sancionado-con-la-cancelacion-del-brevete-y-una-multa-de-s-4300/). Los montos de notas antiguas pueden estar desactualizados porque dependen de la UIT; para el examen importa distinguir la conducta y la sanción principal vigente.

### Quiz A‑IIb



::chatgpt-content-reference{index="0"}



**Registro de avance:** alcohol, drogas, negativa al examen, diferencias M01–M02, medicamentos y licencia suspendida quedan practicados. Continúan sin aparecer resultados calificables de los cuestionarios o del primer simulacro; por eso todavía no registraré temas como dominados ni errores inventados para los repasos espaciados.

### Asistente

## Sesión 12: neumáticos, frenos, dirección y suspensión

### Cápsula de 5 minutos

En mecánica para conducción no necesitas reparar el vehículo: necesitas **reconocer cuándo no debe salir**.

### 1. Neumáticos

Revisa presión en frío, desgaste, cortes, objetos incrustados y deformaciones.

- Desgaste en el centro: suele relacionarse con presión excesiva.
- Desgaste en ambos bordes: suele indicar presión insuficiente.
- Desgaste irregular de un solo lado: puede señalar desalineación o problemas de suspensión.
- Bulto en el costado: existe daño estructural y riesgo de reventón. No se “soluciona” agregando aire.

Utiliza la presión indicada por el fabricante considerando carga y tipo de operación; no la presión máxima escrita en el neumático como valor automático.

### 2. Frenos

Señales de peligro:

- Pedal esponjoso o que baja demasiado.
- Vehículo que se desvía al frenar.
- Vibración fuerte al pisar el pedal.
- Ruido metálico.
- Olor a freno quemado.
- Testigo rojo de frenos encendido.

Si el nivel de líquido está bajo, no basta con rellenarlo: podría existir una fuga o desgaste que debe investigarse.

### 3. Dirección

Un volante con juego excesivo, vibraciones anormales o dificultad para mantener una trayectoria recta puede indicar problemas de terminales, alineación, neumáticos o componentes de dirección.

Ejemplo: si la CDD‑935 necesita corregirse constantemente hacia la izquierda en una recta, no debes acostumbrarte ni compensar sujetando más fuerte el volante. Se reporta y revisa antes de continuar operando.

### 4. Suspensión

La suspensión mantiene los neumáticos en contacto con la vía. Si el vehículo rebota varias veces después de un desnivel, se inclina demasiado en curvas o presenta desgaste irregular, pueden existir amortiguadores o componentes deteriorados.

Regla para memorizar: **“Bulto no se infla; freno que desvía se revisa; dirección con juego no sale; vehículo que rebota pierde contacto.”**

La inspección técnica comprueba frenos, dirección, suspensión, neumáticos y otros sistemas, pero su certificado no reemplaza la revisión diaria. Información contrastada al 2 de septiembre de 2026 con el [Reglamento Nacional de Vehículos](https://www.gob.pe/institucion/mtc/normas-legales/10013-058-2003-mtc), la orientación estatal sobre [Inspección Técnica Vehicular](https://www.gob.pe/397-inspeccion-tecnica-vehicular) y la recomendación del MTC del **17 de julio de 2026** de revisar frenos, luces y neumáticos antes de viajar. [Orientación oficial del MTC](https://www.gob.pe/institucion/mtc/noticias/1420526-mtc-exhorta-a-verificar-licencia-soat-y-revision-tecnica-antes-de-viajar-por-estas-fiestas-patrias)

### Quiz A‑IIb



::chatgpt-content-reference{index="0"}



**Registro de avance:** quedan practicados los síntomas de sobreinflado, subinflado, daño estructural del neumático, frenado desigual, holgura de dirección y amortiguadores deteriorados. Todavía no hay resultados visibles que permitan declarar estos temas dominados o programar errores personales para los repasos de 1, 3 y 7 días.

### Asistente

## Sesión 13: peso, dimensiones y aseguramiento de carga

### Cápsula de 5 minutos

Para resolver preguntas de carga, separa estos conceptos:

- **Tara:** peso del vehículo listo para circular, pero sin mercancía ni pasajeros.
- **Carga útil:** cantidad máxima que puede transportar.
- **Peso bruto vehicular —PBV—:** tara más carga útil.
- **Peso por eje:** parte del peso que cada eje transmite a la vía.

Ejemplo: si un camión tiene una tara de 4 toneladas y un PBV autorizado de 9 toneladas, su carga útil máxima es:

**9 − 4 = 5 toneladas.**

El límite general del Reglamento puede ser mayor, pero siempre debes respetar el límite menor entre:

- Lo permitido para la configuración vehicular.
- Lo indicado por el fabricante.
- Lo registrado para la unidad.

Por eso, que el Reglamento contemple combinaciones de hasta 48 toneladas no convierte a un N2 en un vehículo de 48 toneladas. **N2 continúa siendo superior a 3.5 y hasta 12 toneladas de PBV.**

### Distribución

No basta con que el peso total sea correcto. Una carga concentrada atrás o en un solo costado puede:

- Sobrecargar un eje.
- Levantar parcialmente el eje delantero y reducir la dirección.
- Aumentar la posibilidad de volcadura.
- Alargar la distancia de frenado.

Una unidad puede estar debajo de su PBV total y, aun así, exceder el peso permitido en uno de sus ejes.

### Sujeción

La mercancía debe estar correctamente estibada, atada y protegida. Debes comprobar la sujeción antes de salir y durante las paradas, especialmente después de frenadas o vías irregulares. SUTRAN informó recientemente que estas condiciones son verificadas durante la fiscalización. [Orientación oficial de SUTRAN](https://www.gob.pe/institucion/sutran/noticias/1435607-transporte-de-carga-conoce-la-documentacion-y-condiciones-tecnicas-que-verifica-la-sutran-en-acciones-de-fiscalizacion)

### Dimensiones

Como reglas generales del RNV:

- Ancho máximo: **2.60 metros**, sin incluir espejos.
- Altura técnica general: **4.10 metros**.
- En el control de altura se admite una tolerancia de 5%, que llega aproximadamente a **4.30 metros**.

Ojo con la diferencia: los 4.30 metros son el resultado de la tolerancia de control, no una autorización para seguir colocando carga hasta superar ese valor. [Precisión oficial de SUTRAN del 17 de octubre de 2024](https://www.gob.pe/institucion/sutran/noticias/1041626-sutran-precisa-la-altura-maxima-permitida-para-vehiculos-de-cargas-y-mercancias)

Regla para memorizar: **“PBV = tara + carga; total correcto no salva un eje sobrecargado; carga alta o suelta termina en multa o volcadura.”**

Información comprobada al 3 de septiembre de 2026 con el [Reglamento Nacional de Vehículos](https://www.gob.pe/institucion/mtc/normas-legales/10013-058-2003-mtc) y las orientaciones oficiales de SUTRAN enlazadas arriba.

### Quiz A‑IIb



::chatgpt-content-reference{index="0"}



**Registro de avance:** quedan practicados PBV, tara, carga útil, límites por eje, distribución y dimensiones. No existen respuestas calificables visibles, por lo que aún no se marcan como dominados. La próxima sesión será el **simulacro 2 de 40 preguntas**, con meta de **37/40**.

### Asistente

I noticed you haven’t viewed this scheduled task in a while. Would you like me to keep it running?

### Asistente

## Simulacro 2 — Licencia A‑IIb

### Cápsula previa de 5 minutos

Dispones de **40 minutos para 40 preguntas**. El examen oficial se aprueba con al menos **35 respuestas correctas**; nuestra meta de preparación es **37/40**.

Antes de comenzar, recuerda dos actualizaciones importantes:

- En zona urbana, salvo señal distinta, el límite general es **30 km/h en calles y jirones** y **50 km/h en avenidas**. Los antiguos valores de 40 y 60 km/h ya no son la regla vigente.
- La altura técnica general de los vehículos de carga es **4.10 m**. La fiscalización contempla una tolerancia del 5%, aproximadamente hasta **4.30 m**; esa tolerancia no es capacidad adicional para cargar deliberadamente.

Responde sin consultar la cápsula. Si dudas, descarta primero las alternativas que aumenten el riesgo o pretendan reemplazar documentos, mantenimiento o descanso.

### Parte 1 — Preguntas 1 a 20



::chatgpt-content-reference{index="0"}



### Parte 2 — Preguntas 21 a 40



::chatgpt-content-reference{index="1"}



### Calificación y avance

Suma los aciertos de ambos bloques:

- **37–40:** nivel objetivo.
- **35–36:** aprobación oficial, pero todavía con poco margen.
- **Menos de 35:** requiere refuerzo dirigido.

Distribución temática:

- 1–10: tránsito, señales, prioridades y conducción defensiva.
- 11–15: documentos, seguros, inspección y habilitaciones.
- 16–20: primeros auxilios.
- 21–25: mecánica.
- 26–30: categorías, pesos y carga.
- 31–40: regulación profesional, dimensiones y seguridad.

El simulacro utiliza como base el [simulador del MTC](https://sierdgtt.mtc.gob.pe/Home), el [Reglamento Nacional de Tránsito](https://www.gob.pe/institucion/mtc/normas-legales/9897-016-2009-mtc), el [Reglamento Nacional de Vehículos](https://www.gob.pe/institucion/mtc/normas-legales/10013-058-2003-mtc), el [Reglamento de Licencias](https://www.gob.pe/institucion/mtc/normas-legales/9961-007-2016-mtc) y el [Reglamento Nacional de Administración de Transporte](https://www.gob.pe/institucion/mtc/normas-legales/9895-017-2009-mtc).

**Registro:** simulacro 2 pendiente de resultado. Hasta que aparezca la calificación no lo contaré dentro de la serie de tres resultados consecutivos de 37/40 ni registraré errores inventados.

### Asistente

## Sesión 15: sistema de puntos y sanciones de la licencia

### Cápsula de 5 minutos

Las papeletas no son solamente multas. Cuando una sanción queda **firme en la vía administrativa**, puede registrar puntos contra la licencia. No basta que te hayan intervenido: el puntaje se incorpora cuando existe una resolución firme o que agotó la vía administrativa.

### La regla de los 100 puntos

Si acumulas 100 puntos firmes:

- Primera vez: suspensión de la licencia por **6 meses**.
- Segunda vez: suspensión por **12 meses**.
- Tercera vez: **cancelación definitiva e inhabilitación permanente** para conducir.

Atención con los balotarios antiguos: algunos señalan una inhabilitación de tres años en la tercera acumulación. La orientación oficial vigente indica cancelación definitiva; esa es la regla que debes aprender. [Sistema de licencias por puntos del Estado](https://www.gob.pe/343-como-funciona-el-sistema-de-licencias-de-conducir-por-puntos)

Los puntos de cada infracción dejan de tener efecto después de **dos años**, contados desde que la sanción quedó firme. No se cuentan simplemente desde el día de la intervención.

### Curso de Seguridad Vial: cambio de 2026

Desde el Decreto Supremo 001-2026-MTC, aprobar el curso permite descontar:

- Modalidad virtual: **40 puntos**.
- Modalidad presencial: **50 puntos**.
- Si tienes menos puntos que el descuento, quedas en cero; no obtienes saldo a favor.

Por ejemplo, si tienes 35 puntos y apruebas el curso presencial, quedas en cero, no en −15. [Modificación oficial del 11 de enero de 2026](https://www.gob.pe/institucion/mtc/normas-legales/7608802-001-2026-mtc)

Para licencias profesionales, como A‑IIb, este incentivo puede obtenerse una vez cada **seis meses**, computados desde el último otorgamiento. En condiciones ordinarias, no se accede al curso después de acumular 100 puntos firmes. [Decreto Supremo 012-2025-MTC](https://www.gob.pe/institucion/mtc/normas-legales/7044060-012-2025-mtc)

Ejemplo real: si un conductor de la CDD‑935 acumula 60 puntos, aprobar presencialmente no le da permiso para cometer nuevas infracciones. Solo reduce el registro existente en 50 puntos y queda con 10.

Regla para memorizar: **“Primera 6, segunda 12, tercera nunca más; virtual 40, presencial 50.”**

### Quiz A‑IIb



::chatgpt-content-reference{index="0"}



**Registro de avance:** sistema de puntos, firmeza de sanciones, consecuencias por acumular 100 puntos y descuentos vigentes quedan practicados. El simulacro 2 continúa pendiente de una calificación visible; por eso todavía no se incorpora a la serie de 37/40 ni existen errores personales confirmados para repasar.

### Asistente

## Sesión 16: documentos, habilitación y fiscalización

### Cápsula de 5 minutos

En una fiscalización profesional debes distinguir cuatro niveles:

1. **Conductor:** documento de identidad y licencia vigente cuya clase y categoría correspondan al vehículo.
2. **Vehículo:** Tarjeta de Identificación Vehicular, SOAT o CAT vigente y Certificado de Inspección Técnica Vehicular cuando corresponda.
3. **Servicio de transporte:** autorización del transportista y habilitación de la unidad, acreditada mediante la Tarjeta Única de Circulación —TUC— física o electrónica.
4. **Viaje concreto:** documentos relacionados con los pasajeros, ruta o mercancía transportada.

No son intercambiables:

- La licencia autoriza al conductor, pero no habilita a la empresa.
- La Tarjeta de Identificación Vehicular identifica la unidad y sus características, pero no autoriza el servicio público.
- La TUC acredita que el vehículo está habilitado para el servicio correspondiente.
- El SOAT o CAT cubre daños personales; no certifica el estado mecánico.
- El CITV acredita la evaluación técnica y ambiental, pero no reemplaza el mantenimiento diario.

En transporte de personas deben existir, según la modalidad, la **hoja de ruta electrónica** y el **manifiesto de usuarios**. La primera registra la operación, el recorrido y los conductores; el segundo identifica a los pasajeros.

En transporte de mercancías deben acompañar a la carga los documentos que sustenten su traslado, incluidas las guías de remisión aplicables. La carga también debe estar distribuida y asegurada.

Ejemplo Sinba: que la CDD‑700 tenga SOAT, revisión técnica y tarjeta vehicular vigentes no basta si se pretende prestar un servicio sujeto a autorización con una unidad no habilitada. Los documentos del vehículo no reemplazan la autorización del servicio.

Regla para memorizar: **“Licencia: conductor; tarjeta: vehículo; TUC: habilitación; hoja: viaje; manifiesto: pasajeros; guía: carga.”**

Contenido comprobado con el [Reglamento Nacional de Administración de Transporte](https://www.gob.pe/institucion/mtc/normas-legales/9895-017-2009-mtc), la orientación de SUTRAN sobre [documentos obligatorios para transporte de personas y mercancías](https://www.gob.pe/institucion/sutran/noticias/1006673-sutran-conoce-los-documentos-de-porte-obligatorio-y-otras-condiciones-exigidas-en-el-servicio-de-transporte-de-personas-y-de-mercancias) y su información sobre [fiscalización del transporte de carga](https://www.gob.pe/institucion/sutran/noticias/1435607-transporte-de-carga-conoce-la-documentacion-y-condiciones-tecnicas-que-verifica-la-sutran-en-acciones-de-fiscalizacion).

### Quiz A‑IIb



::chatgpt-content-reference{index="0"}



**Registro de avance:** quedan practicados licencia, Tarjeta de Identificación Vehicular, TUC, CITV, hoja de ruta, manifiesto de usuarios y guías de remisión. El simulacro 2 continúa sin calificación visible; por ello aún no se registra en la serie de 37/40 ni existen errores personales confirmados para el repaso espaciado.

### Asistente

## Sesión 17: marcas viales, semáforos y obras

### Cápsula de 5 minutos

Los dispositivos de tránsito se leen como un solo sistema: señales verticales, marcas en la calzada, semáforos y señalización temporal. Si una autoridad dirige el tránsito, sus indicaciones prevalecen.

### Marcas longitudinales

- **Línea amarilla:** normalmente separa corrientes que circulan en sentidos contrarios.
- **Amarilla continua:** no debes cruzarla para adelantar.
- **Amarilla discontinua:** puedes cruzarla únicamente si el adelantamiento está permitido, existe visibilidad y es seguro.
- **Línea blanca:** normalmente separa carriles que circulan en el mismo sentido.
- **Línea blanca continua:** restringe el cambio de carril en ese tramo.
- **Línea de parada:** señala dónde debes detenerte ante PARE, semáforo rojo u otra obligación.
- **Cruce peatonal:** debe permanecer libre; no avances si la congestión te dejará encima.

### Semáforo amarillo

La luz amarilla no significa “acelera”. Debes detenerte antes de entrar a la intersección si puedes hacerlo con seguridad. Si ya estás demasiado cerca para frenar sin riesgo, continúa con precaución y despeja el cruce.

### Luces intermitentes del semáforo

- **Rojo intermitente:** detención completa y continuación solo cuando resulte seguro.
- **Amarillo intermitente:** reduce la velocidad y continúa con máxima precaución.

### Luces del vehículo

En la red vial nacional y departamental se utilizan las **luces bajas durante las 24 horas**. También deben emplearse en túneles y cuando la lluvia, neblina o polvo reduzcan la visibilidad.

### Obras viales

La señalización temporal suele emplear color **naranja**. Debes reducir la velocidad, seguir los conos, barreras, señales y las indicaciones del personal autorizado. No ingreses al carril cerrado aunque parezca vacío.

Ejemplo Sinba: si la CDD‑935 llega a un tramo en mantenimiento donde un controlador muestra PARE, debe detenerse aunque el semáforo ubicado más adelante esté verde.

Importante: algunos balotarios todavía citan el manual de 2016. Este fue derogado y reemplazado por la actualización aprobada en octubre de 2024; para cualquier diferencia manda la norma actual. [Resolución Directoral 26-2024-MTC/18](https://www.gob.pe/institucion/mtc/normas-legales/6150395-26-2024-mtc-18)

Regla para memorizar: **“Amarillo central separa sentidos; blanco separa carriles; ámbar no invita a acelerar; naranja anuncia obras.”**

Fuentes: [Manual actualizado de señales de tránsito](https://www.gob.pe/institucion/mtc/noticias/1055740-mtc-actualiza-manual-de-senales-de-transito) y [Reglamento Nacional de Tránsito](https://www.gob.pe/institucion/mtc/normas-legales/9897-016-2009-mtc).

### Quiz A‑IIb



::chatgpt-content-reference{index="0"}



**Registro de avance:** quedan practicadas líneas amarillas y blancas, línea de parada, luces amarilla y roja intermitentes, luces bajas y control temporal de obras. El simulacro 2 continúa pendiente de resultado; no se registran todavía errores personales ni avances en la serie de tres calificaciones de 37/40.

### Asistente

I've paused this task because updates haven't been viewed in a while. You can resume it in the Scheduled tab or by asking ChatGPT.
