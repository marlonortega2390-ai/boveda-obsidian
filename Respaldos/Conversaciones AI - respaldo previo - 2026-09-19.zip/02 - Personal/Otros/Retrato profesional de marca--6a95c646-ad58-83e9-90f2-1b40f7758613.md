---
title: "Retrato profesional de marca"
conversation_id: "6a95c646-ad58-83e9-90f2-1b40f7758613"
type: "chatgpt"
project_id: "g-p-6a03602663008191b5d8ab97a83e1d56"
area: "02 - Personal/Otros"
updated_at: 1788200683.634
archived: false
export_complete: true
tags: [conversacion-ai, jarvis-import]
---

# Retrato profesional de marca

- ID: `6a95c646-ad58-83e9-90f2-1b40f7758613`
- Tipo: `chatgpt`
- Proyecto: `g-p-6a03602663008191b5d8ab97a83e1d56`
- Estado: `activa`

## Conversación

### Marlon

/image @Francisco González: pront//// /imagen Retrato de marca personal de
gama alta, del tipo que usana en Linkedln O en wveb de empresa. Encuadre del pecho a un poco por encima de la cabeza, sujeto centro y mirando a cámara, expresión serena con una sonrisa mínima de seguridad Foco nítido en los ojos con brillos suaves. Luz principal blanda entrando desde el frente-izquierdo. Fondo: interior moderno muy desenfocado en tonos cálidos oscuros, sin logotipos ni texto. Kopa: jersey negro hiso de punto fino. Optica de 85 mm a diagrama abierto, gradacion de color natural con altas luces calidas|y contraste suave.

[User attached 1 image; image contents were not included]
