---
tags: [indice, conversaciones-ai, importacion]
---

# General — bandeja de importación

Esta carpeta conserva conversaciones que llegaron sin proyecto. Para encontrarlas por contexto, usa estos mapas:

- [[../02 - Personal/00 - Personal|Personal]] — salud, familia, relaciones, aprendizaje, rutinas y creatividad.
- [[../03 - Tecnología e IA/00 - Índice|Tecnología e IA]] — herramientas, ChatGPT y Codex.
- [[../00 - Índice de conversaciones|Inicio]] — vista completa de la bóveda.

## Contenido original

- [[Dosis de Gaseovet--6a9e5305-fb98-83e9-8f59-9ba3e5721239|Dosis de Gaseovet]]
- [[Simulacro de manejo--6a9e385e-2e88-83e9-b6ee-bacf0a9b6b54|Simulacro de manejo]]
- [[Rutina de llamadas semanales--6a57efdf-d3c4-83e9-93ef-02fa6af099ff|Rutina de llamadas semanales]]
- [[Cuidado del prepucio infantil--6a93af9d-be9c-83e9-ab2a-ccc0ab04827e|Cuidado del prepucio infantil]]
- [[Funciones avanzadas Plus--6a93ae15-52e0-83e9-90dd-36e881c320bf|Funciones avanzadas Plus]]
- [[Retrato submarino etéreo--6a9249ae-0af4-83e9-88af-12ad4766f322|Retrato submarino etéreo]]
- [[Analizar compatibilidad de pareja--6a8d197b-1c54-83e9-a173-6f97116af606|Analizar compatibilidad de pareja]]
