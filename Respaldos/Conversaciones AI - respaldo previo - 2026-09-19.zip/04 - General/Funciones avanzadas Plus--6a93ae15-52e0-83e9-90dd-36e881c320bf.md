---
title: "Funciones avanzadas Plus"
conversation_id: "6a93ae15-52e0-83e9-90dd-36e881c320bf"
type: "chatgpt"
project_id: null
area: "04 - General"
updated_at: 1788063312.131
archived: false
export_complete: true
tags: [conversacion-ai, jarvis-import]
---

# Funciones avanzadas Plus

- ID: `6a93ae15-52e0-83e9-90dd-36e881c320bf`
- Tipo: `chatgpt`
- Proyecto: `sin proyecto`
- Estado: `activa`

## Conversación

### Marlon

¿Cómo puedo usar las funciones avanzadas de mi plan ChatGPT Plus?

### Asistente

Sí. Tu **ChatGPT Plus tiene bastante más potencia de la que normalmente se usa solo chateando**. A fecha de hoy, Plus incluye límites más altos, acceso a razonamiento avanzado y herramientas como voz, imágenes, archivos e investigación profunda. citeturn485252search2turn485252search5

Para sacarle provecho de verdad, yo lo dividiría así:

1. **🧠 Razonamiento avanzado**  
   Úsalo cuando el problema requiera pensar, comparar, calcular o revisar muchas variables. En el selector de modelos puedes ver las opciones disponibles actualmente en tu cuenta. citeturn485252search2  
   Ejemplo: *“Analiza estos 4 reportes de rutas, cruza responsabilidades, detecta duplicidades y dame una propuesta de reorganización.”*

2. **🔎 Investigación profunda — Deep Research**  
   En el botón **+ / Herramientas → Investigación profunda**. Puede investigar muchas fuentes, trabajar con tus archivos y entregarte un informe con citas. También puedes indicarle qué páginas web debe priorizar. citeturn485252search5  
   Para ti sería ideal para cosas como normativa de transporte peruana, brevete A-IIb, especificaciones de vehículos o comparaciones técnicas.

3. **🖥️ ChatGPT Trabajo (Work)**  
   Es la función más interesante para trabajos largos de varios pasos. Puede combinar investigación, archivos, apps y, cuando esté disponible, un **navegador en la nube** capaz de navegar páginas, hacer clic y completar acciones compatibles. citeturn635472search4  
   Por ejemplo: *“Investiga tres alternativas de vehículos, compara ficha técnica, capacidad, combustible y prepara un informe final.”*

4. **📁 Proyectos**  
   En vez de tener 50 chats separados, crea un Proyecto. Ahí puedes guardar chats, instrucciones y archivos relacionados. Plus admite actualmente **hasta 25 archivos por proyecto**, cargando hasta 10 a la vez. citeturn485252search1  
   En tu caso yo separaría, por ejemplo: **Logística SINBA**, **Brevete A-IIb**, **Center Fitt** y **proyectos de programación**. Así no tienes que volver a explicarme todo cada vez.

5. **🔌 Apps y plugins: Drive, Gmail, Calendar, etc.**  
   ChatGPT ahora usa principalmente el **Directorio de plugins** para descubrir integraciones. Las apps pueden conectar servicios externos para buscar información e incluso realizar acciones compatibles. citeturn868297search0  
   Con Google Drive, por ejemplo, puedes decir: *“Busca mi último plan de mantenimiento y compáralo con esta factura.”* Según permisos, también existen acciones sobre Docs, Sheets y Slides. citeturn868297search6

6. **⏰ Tareas programadas y monitoreo**  
   Plus puede tener actualmente **hasta 5 tareas activas**. Pueden ejecutarse a una hora exacta, repetirse o revisar periódicamente si algo cambió y avisarte. citeturn635472search0turn635472search1  
   Ejemplos: *“Todos los lunes a las 8 a. m. recuérdame revisar mantenimiento”* o *“Revisa cada día si cambió esta normativa y avísame solo si hay novedades.”*

7. **🗣️ Voz avanzada**  
   Puedes hablar conmigo prácticamente como una conversación. Actualmente existen modos **En vivo, Avanzada y Estándar**, dependiendo de lo que aparezca habilitado en tu aplicación. citeturn485252search11  
   Te serviría especialmente cuando estás ocupado y quieres explicarme un problema rápidamente sin escribir todo.

8. **📊 Archivos + Excel/PDF/Word + fotografías**  
   Puedes simplemente adjuntar los archivos y pedirme que los analice, compare, encuentre errores, genere tablas o prepare documentos. La carga y análisis de archivos forma parte de las funciones ampliadas de Plus. citeturn485252search2

9. **🎨 Generación y edición de imágenes**  
   Puedes pedirme crear imágenes nuevas o subir una foto y decirme qué quieres cambiar: estilo, iluminación, objetos, composición, etc. También está incluida entre las capacidades ampliadas de Plus. citeturn485252search2

10. **💻 Codex**  
    Codex está incluido con los planes de ChatGPT y sirve específicamente para **programar, revisar código y trabajar sobre proyectos de software**. Se puede usar desde la app, web, CLI o como extensión del IDE. citeturn868297search7  
    Para tus proyectos de VS Code, esta es una de las herramientas que más vale la pena aprender.

Hay una distinción importante: **ChatGPT Plus no incluye créditos de la API de OpenAI**. La API se factura aparte. citeturn485252search2

### Lo que yo haría contigo

No intentaría aprender las diez funciones de golpe. Empezaría por estas **5**:

**Proyectos → Apps/Drive → Investigación profunda → Tareas → Work.**

Y dejaríamos **Codex** como nuestra parte de programación.

De hecho, podemos hacerlo de la forma que te resulta más cómoda: **“ve aquí → toca esto → pega esto → mira qué sucede”**, directamente desde tu iPhone. Si quieres empezar ahora, podemos revisar **tu pantalla actual de ChatGPT Plus y te voy enseñando función por función**.
