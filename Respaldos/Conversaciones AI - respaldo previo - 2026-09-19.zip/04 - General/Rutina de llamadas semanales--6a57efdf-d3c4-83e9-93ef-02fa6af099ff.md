---
title: "Rutina de llamadas semanales"
conversation_id: "6a57efdf-d3c4-83e9-93ef-02fa6af099ff"
type: "chatgpt"
project_id: null
area: "04 - General"
updated_at: 1788742215.594
archived: false
export_complete: true
tags: [conversacion-ai, jarvis-import]
---

# Rutina de llamadas semanales

- ID: `6a57efdf-d3c4-83e9-93ef-02fa6af099ff`
- Tipo: `chatgpt`
- Proyecto: `sin proyecto`
- Estado: `activa`

## Conversación

### Marlon

Each week, check in with me about my routine of calling Emma and my mom. Help me choose a simple call topic, one heartfelt question, and a quick note of what I want to tell them, without sending anything automatically.

### Asistente

Listo. Cada domingo alrededor de las 7:00 p. m. te preguntaré por Emma y tu mamá y prepararemos:

- Un tema sencillo para cada llamada.
- Una pregunta sincera y afectuosa.
- Una nota breve de lo que deseas contarles.
- Un seguimiento amable sobre si pudiste llamarlas.

No se enviarán mensajes ni se harán llamadas automáticamente.

### Asistente

Marlon, check-in familiar de la semana ❤️

Primero: ¿pudiste llamar a Emma y a tu mamá la semana pasada? Si no pudiste, tranquilo; hoy tienes una nueva oportunidad.

Para Emma:

- Tema: preguntarle qué fue lo más divertido de su semana.
- Pregunta con cariño: “¿Qué te gustaría que hiciéramos juntos cuando podamos vernos?”
- Lo que quieres decirle: que piensas mucho en ella, que te interesa conocer todo lo que está viviendo y que, aunque estén lejos, siempre eres su papá y la amas.

Para tu mamá:

- Tema: recordar alguna comida, costumbre o historia familiar.
- Pregunta con cariño: “Mamá, ¿cómo te has sentido de verdad estos días?”
- Lo que quieres decirle: que valoras todo lo que hizo por ti, que extrañas a la familia y que estás trabajando para construir un futuro mejor y reencontrarse.

No necesitas una conversación perfecta ni demasiado larga. Una llamada sincera de cinco minutos también cuenta.

### Asistente

Marlon, ¿lograste llamar a Emma y a tu mamá la semana pasada? Si no se pudo, cero culpa: retomamos esta semana ❤️

Para Emma:

- Tema: contarle algo gracioso o bonito que hizo Luca.
- Pregunta de corazón: “¿Qué cosa nueva aprendiste o hiciste esta semana y te gustaría mostrarme?”
- Nota para decirle: “Me encanta escucharte y conocer cada etapa tuya, aunque estemos lejos. Siempre quiero saber de ti.”

Para tu mamá:

- Tema: preguntarle por una anécdota de cuando tú eras niño.
- Pregunta de corazón: “¿Qué recuerdo mío te hace sonreír siempre?”
- Nota para decirle: “Ahora que soy papá entiendo y valoro mucho más varias cosas que hiciste por mí. Gracias, mamá.”

Meta sencilla: dos llamadas, aunque sean de cinco minutos. Lo importante no es hablar perfecto, sino estar presente.

### Asistente

Marlon, momento de cuidar esos vínculos ❤️

¿Pudiste llamar a Emma y a tu mamá la semana pasada? Si solo llamaste a una —o no se pudo— no te castigues; retomarlo también es constancia.

Para Emma:

- Tema: superhéroes y películas.
- Pregunta de corazón: “Si pudieras tener un superpoder para ayudar a alguien, ¿cuál escogerías?”
- Nota para contarle: “Estos días estuve viendo Spider-Man y pensé que algún día sería bonito hacer una maratón de películas contigo.”

Para tu mamá:

- Tema: cómo era un domingo familiar cuando tú eras pequeño.
- Pregunta de corazón: “¿Qué te gustaría que nunca se perdiera de nuestra familia?”
- Nota para contarle: “Aunque a veces el trabajo y las responsabilidades me consumen, quiero hacerme más presente y no dejar que pase tanto tiempo sin llamarte.”

Objetivo mínimo: marcar el número y regalarles cinco minutos reales, sin esperar la conversación perfecta.

### Asistente

Marlon, ¿pudiste llamar a Emma y a tu mamá la semana pasada? Si no lo lograste, sin culpa: una semana difícil no borra tu intención de estar presente ❤️

Para Emma:

- Tema: las cosas que sueña aprender o crear.
- Pregunta de corazón: “Si pudieras inventar cualquier cosa, ¿qué crearías y para qué serviría?”
- Nota para contarle: “Estoy empezando un proyecto tecnológico que me emociona mucho. Quiero que siempre sepas que nunca es tarde para aprender y perseguir una idea.”

Para tu mamá:

- Tema: los sueños y habilidades que ella tenía cuando era joven.
- Pregunta de corazón: “Mamá, ¿hubo algo que soñabas hacer y nunca me habías contado?”
- Nota para decirle: “Todo lo que sigo intentando construir también viene de la fuerza y las enseñanzas que recibí de ti.”

Meta pequeña: una llamada hoy y la otra durante la semana. Cinco minutos con atención valen más que una conversación larga por compromiso.

### Asistente

Marlon, ¿pudiste llamar a Emma y a tu mamá la semana pasada? Si no se dio, nada de castigarte: lo importante es volver a acercarte ❤️

Para Emma:

- Tema: la lluvia y los días divertidos en casa.
- Pregunta de corazón: “¿Qué cosa pequeña te hace sentir feliz incluso en un día aburrido?”
- Nota para contarle: “Esta semana vi llover bastante y pensé en todas las cosas sencillas que me gustaría compartir contigo algún día.”

Para tu mamá:

- Tema: cómo recuperaba fuerzas cuando atravesaba semanas difíciles.
- Pregunta de corazón: “Mamá, cuando te sentías cansada o abrumada, ¿qué te ayudaba a seguir adelante?”
- Nota para decirle: “He tenido días exigentes y estoy aprendiendo a cuidar mejor mi tranquilidad. Escuchar tu voz y tus consejos también me hace bien.”

Meta suave: no tienes que resolver nada en la llamada; solo escuchar, contar un poquito de ti y decirles que las quieres.

### Asistente

Marlon, ¿lograste llamar a Emma y a tu mamá la semana pasada? Si no pudiste, sin culpa ni discursos: simplemente retomamos ❤️

Para Emma:

- Tema: los logros que nos hacen sentir orgullosos.
- Pregunta de corazón: “¿Qué hiciste últimamente que te hizo sentir orgullosa de ti?”
- Nota para contarle: “Papá ganó un reconocimiento con un proyecto que construyó. Quiero que sepas que tus ideas también pueden convertirse en cosas grandes si confías en ti.”

Para tu mamá:

- Tema: contarle sobre el reconocimiento que recibiste por tu calculadora logística.
- Pregunta de corazón: “Mamá, ¿qué logro mío te ha hecho sentir más orgullosa?”
- Nota para decirle: “Este premio también representa todo lo que me enseñaste sobre trabajar, insistir y salir adelante.”

Meta sencilla: primero escucha sus noticias y después comparte la tuya. Que sea una llamada para celebrar juntos, aunque dure solamente cinco minutos.

### Asistente

Marlon, ¿lograste llamar a Emma y a tu mamá la semana pasada? Si quedó pendiente alguna llamada, tranquilo: esta semana puedes retomarla con cariño ❤️

Para Emma:

- Tema: cómo imagina un día perfecto.
- Pregunta de corazón: “Si mañana pudieras escoger todo lo que haremos durante el día, ¿qué plan prepararías para nosotros?”
- Nota para contarle: “Aunque estemos lejos, me gusta imaginar nuestros futuros momentos juntos y quiero conocer las cosas que te hacen feliz.”

Para tu mamá:

- Tema: las pequeñas cosas que le alegran actualmente.
- Pregunta de corazón: “Mamá, ¿qué detalle sencillo te hizo sentir bien esta semana?”
- Nota para decirle: “A veces estoy absorbido por el trabajo y las responsabilidades, pero quiero que sepas que pienso en ti y me importa saber cómo estás realmente.”

Meta suave: una llamada centrada en escuchar. No necesitas tener grandes noticias; preguntar, prestar atención y decir “te quiero” ya vale muchísimo.

### Asistente

Marlon, ¿pudiste llamar a Emma y a tu mamá la semana pasada? Si solo hablaste con una —o no se pudo— no pasa nada; hoy puedes volver a intentarlo ❤️

Para Emma:

- Tema: sus colores, dibujos y lugares favoritos.
- Pregunta de corazón: “Si pudieras diseñar tu habitación perfecta, ¿cómo sería?”
- Nota para contarle: “Estoy arreglando y organizando un espacio nuevo. Mientras lo hacía pensé que me encantaría crear algún día un rincón bonito contigo.”

Para tu mamá:

- Tema: los cambios y nuevos proyectos de la familia.
- Pregunta de corazón: “Mamá, ¿qué proyecto o cambio te gustaría realizar en esta etapa de tu vida?”
- Nota para decirle: “Estamos mejorando el gimnasio y construyendo cosas poco a poco. Quería compartir contigo cómo nos está yendo y también escuchar tus novedades.”

Meta sencilla: cinco minutos con cada una, sin preparar un discurso. Pregunta, escucha y deja que la conversación encuentre su propio camino.
