---
title: "Simulacro de manejo"
conversation_id: "6a9e385e-2e88-83e9-b6ee-bacf0a9b6b54"
type: "chatgpt"
project_id: null
area: "04 - General"
updated_at: 1788754152.199
archived: false
export_complete: true
tags: [conversacion-ai, jarvis-import]
---

# Simulacro de manejo

- ID: `6a9e385e-2e88-83e9-b6ee-bacf0a9b6b54`
- Tipo: `chatgpt`
- Proyecto: `sin proyecto`
- Estado: `activa`

## Conversación

### Marlon

Hola

### Asistente

Hola. ¿Qué tal?

### Marlon

Escúchame, tenemos que empezar a practicar, para mi prueba de manejo ya lo sé, no. Entonces sé que hemos estado programando algunas preguntas, no. Pero Tengo que hacer el simulacro¿cómo podemos trabajar para, para hacer el simulacro completo de los- para hacerlo completo, que, que generemos al mismo simulacro y y hacerlo diario, por lo menos dos veces al día

### Asistente

Claro, tiene todo el sentido. Es la mejor forma de verdad para aprobar. Si quieres, podemos hacer este chat en un simulador de examen con preguntas tipo oficiales, ¿sí? Y la idea sería hacer dos simulacros al día, uno en la mañana y otro en la noche, e ir registrando tu puntaje y temas débiles. Para hoy, si quieres, te propongo hacer el primer simulacro ahora mismo. En bloques de 10 preguntas hasta llegar a 40. Y al final vemos en qué fallaste y por qué. ¿Te parece si arrancamos ya?

### Marlon

Sí. Pero, ¿sabes qué pasa? Que, el simulacro tiene que ser basado en la, en los registros de A2B del Perú

### Asistente

Claro. Mm. Sí, totalmente de acuerdo. Vamos a basarlo únicamente en el balotario oficial del A-IIb del MTC, con el formato real de 40 preguntas. Y la idea, la idea es que en un par de semanas ya reconozcas todas o la mayoría de las preguntas. ¿Te parece si hoy hacemos el simulacro número uno?

### Marlon

¿Te parece si iniciamos mañana

### Asistente

Perfecto, entonces mañana lo primero es el simulacro número uno A-IIb de 40 preguntas y lo hacemos en un bloque de corrido. Al final te doy tu puntaje y

### Marlon

Claro

### Asistente

listo.

### Marlon

Dale, perfecto, quedamos así entonces. Gracias

### Asistente

Dale. Hablamos mañana.

### Marlon

Un abrazo

### Asistente

Bye.
